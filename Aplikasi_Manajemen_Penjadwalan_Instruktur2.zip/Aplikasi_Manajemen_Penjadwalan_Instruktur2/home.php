<?php
// Halaman landing diperbarui: desain premium, tetap dengan palet hijau/teal khas.
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>BBPVP Bekasi — Manajemen Penjadwalan</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet" />
  <style>
    /* Palet warna tetap dipertahankan */
    :root {
      --primary: #059669;
      --accent: #0d9488;
      --text: #1f2937;
      --white: #ffffff;
      --bg: #f0fdf4;
      --radius: 14px;
      --ring: #bbf7d0;
      --ring-strong: #86efac;
      --muted: rgba(31,41,55,0.72);
      --shadow-1: 0 10px 30px rgba(5,150,105,0.12);
      --shadow-2: 0 16px 40px rgba(13,148,136,0.14);
    }

    * { box-sizing: border-box; }
    html, body {
      margin: 0;
      padding: 0;
      width: 100%;
      max-width: 100%;
      overflow-x: hidden;
    }
    body {
      font-family: 'Inter', system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, 'Helvetica Neue', Arial, 'Noto Sans', 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol';
      color: var(--text);
      background: radial-gradient(1000px 600px at 20% -10%, #bbf7d0 0%, transparent 45%),
                  radial-gradient(800px 500px at 110% 10%, #a7f3d0 0%, transparent 50%),
                  var(--bg);
      line-height: 1.55;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      width: 100%;
      min-width: 100%;
    }

    .muted { color: var(--muted); }

    /* Animations */
    .reveal { opacity: 0; transform: translateY(12px); transition: opacity .6s ease, transform .6s ease; }
    .reveal.is-visible { opacity: 1; transform: translateY(0); }
    .float { animation: floatY 6s ease-in-out infinite; will-change: transform; }
    @keyframes floatY { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-6px); } }

    /* Prefers reduced motion */
    @media (prefers-reduced-motion: reduce) {
      .reveal { opacity: 1 !important; transform: none !important; transition: none !important; }
      .float { animation: none !important; }
    }

    /* Glass Navbar */
    header {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 1000;
      width: 100%;
    }
    .nav-shell {
      width: 100%;
      background: rgba(255,255,255,0.78);
      backdrop-filter: saturate(140%) blur(10px);
      border-bottom: 1px solid #d1fae5;
      transition: background-color .2s ease, box-shadow .2s ease, border-color .2s ease;
    }
    .nav-shell.header--scrolled { background: rgba(255,255,255,0.9); box-shadow: 0 8px 22px rgba(0,0,0,0.06); border-color: var(--ring); }
    .nav {
      max-width: 1200px;
      margin: 0 auto;
      padding: 14px 24px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      width: 100%;
      box-sizing: border-box;
    }
    .brand {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
      color: var(--text);
    }
    .brand-logo-img { width: 40px; height: 40px; border-radius: 10px; box-shadow: 0 8px 18px rgba(5,150,105,0.25); }
    .brand-text { display: grid; }
    .brand-text strong { font-size: 14px; font-weight: 800; letter-spacing: .2px; }
    .brand-text span { font-size: 12px; color: rgba(31,41,55,0.72); }

    .login-btn {
      appearance: none;
      border: 1px solid var(--primary);
      background: var(--primary);
      color: var(--white);
      font-weight: 800;
      font-size: 14px;
      padding: 10px 14px;
      border-radius: 10px;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      box-shadow: 0 10px 24px rgba(5,150,105,.18);
      transition: transform .15s ease, box-shadow .15s ease, background-color .15s ease;
    }
    .login-btn:hover { background: #047857; transform: translateY(-1px); box-shadow: 0 12px 30px rgba(4,120,87,.24); }

    /* Main */
    main {
      width: 100%;
      max-width: 100%;
      overflow-x: hidden;
      padding-top: 70px;
    }

    /* Hero */
    .hero {
      width: 100%;
      max-width: 1200px;
      margin: 0 auto;
      padding: 46px 24px 28px;
      display: grid;
      grid-template-columns: 1.25fr 1fr;
      gap: 28px;
      align-items: start;
      box-sizing: border-box;
    }
    .hero h1 { font-size: clamp(32px, 4.2vw, 48px); line-height: 1.12; font-weight: 900; letter-spacing: 0.2px; margin: 10px 0 12px; }
    .hero p { margin: 0 0 14px; }
    .hero p.muted { max-width: 62ch; }
    .hero-badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      font-weight: 800;
      color: var(--accent);
      background: #e6fffa; /* turunan teal ringan, tetap solid */
      border: 1px solid #ccfbf1;
      padding: 6px 10px;
      border-radius: 999px;
    }
    .hero-cta {
      display: flex;
      align-items: center;
      gap: 10px;
      flex-wrap: wrap;
      margin-top: 14px;
    }
    .cta-outline {
      text-decoration: none;
      color: var(--primary);
      font-weight: 800;
      border: 1.5px solid var(--primary);
      border-radius: 10px;
      padding: 10px 14px;
      background: var(--white);
      transition: transform .15s ease, background-color .15s ease, color .15s ease;
    }
    .cta-outline:hover {
      transform: translateY(-1px);
      background: #ecfdf5;
      color: #065f46;
    }
    .hero-media { position: relative; background: var(--white); border: 1.5px solid var(--ring); border-radius: var(--radius); padding: 10px; box-shadow: var(--shadow-1); overflow: hidden; display: grid; gap: 8px; align-content: start; }
    .hero-media .media { position: relative; border-radius: calc(var(--radius) - 6px); overflow: hidden; aspect-ratio: 16 / 10; background: #ecfdf5; }
    .hero-media video { width: 100%; height: 100%; object-fit: cover; display: block; transform: scale(1.002); transition: transform .45s ease; }
    .hero-media:hover video { transform: scale(1.015); }
    .hero-media .badge { position: absolute; left: 10px; bottom: 10px; background: rgba(255,255,255,0.9); color: var(--primary); border: 1px solid var(--ring); border-radius: 999px; padding: 6px 10px; font-size: 12px; font-weight: 800; letter-spacing: .2px; backdrop-filter: saturate(140%) blur(6px); }

    /* Section + Cards */
    .section {
      width: 100%;
      max-width: 1200px;
      margin: 0 auto;
      padding: 24px 24px 12px;
      box-sizing: border-box;
    }
    .section h2 { font-size: 24px; font-weight: 900; letter-spacing: .2px; margin: 0 0 12px; }
    .grid { display: grid; grid-template-columns: repeat(12, 1fr); gap: 16px; }
    .card {
      grid-column: span 6;
      background: var(--white);
      border: 1.5px solid var(--ring);
      border-radius: var(--radius);
      padding: 18px;
      display: grid;
      gap: 8px;
      box-shadow: var(--shadow-1);
      transition: transform .2s ease, box-shadow .2s ease, border-color .2s ease;
    }
    .card:hover { transform: translateY(-4px); box-shadow: var(--shadow-2); border-color: var(--ring-strong); }
    .card h3 { margin: 0; font-weight: 800; font-size: 16px; color: var(--text); }
    .card p { margin: 0; color: var(--muted); font-size: 14px; }

    /* About-like Showcase & Extras */
    .about { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; align-items: start; margin-top: 4px; }
    .about-box { background: var(--white); border: 1.5px solid var(--ring); border-radius: var(--radius); padding: 16px; display: grid; gap: 8px; box-shadow: var(--shadow-1); transition: transform .2s ease, box-shadow .2s ease, border-color .2s ease; }
    .about-box:hover { transform: translateY(-3px); box-shadow: 0 10px 20px rgba(5,150,105,0.10); border-color: #86efac; }
    .about-box h3 { margin: 0; font-size: 16px; font-weight: 800; }
    .about-box p, .about-box li { color: var(--muted); font-size: 14px; line-height: 1.6; }
    .about-box ul { margin: 6px 0 0 18px; }
    .about-box-full { grid-column: 1 / -1; }
    .about-box-full p { margin: 0 0 12px; }
    .about-box-full p:last-child { margin-bottom: 0; }

    /* Struktur Organisasi */
    .struktur-box { background: var(--white); border: 1.5px solid var(--ring); border-radius: var(--radius); padding: 20px; box-shadow: var(--shadow-1); transition: transform .2s ease, box-shadow .2s ease, border-color .2s ease; }
    .struktur-box:hover { transform: translateY(-3px); box-shadow: 0 10px 20px rgba(5,150,105,0.10); border-color: #86efac; }
    .struktur-img-container { width: 100%; border-radius: calc(var(--radius) - 4px); overflow: hidden; background: #ecfdf5; display: flex; align-items: center; justify-content: center; min-height: 400px; }
    .struktur-img-container img { width: 100%; height: auto; display: block; object-fit: contain; }
    .struktur-placeholder { padding: 60px 20px; text-align: center; color: var(--muted); }
    .struktur-placeholder::before { content: "📊"; font-size: 48px; display: block; margin-bottom: 12px; }

    /* Jurusan Pelatihan */
    .jurusan-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 18px; margin-top: 4px; }
    .jurusan-card {
      background: var(--white);
      border: 1.5px solid var(--ring);
      border-radius: var(--radius);
      padding: 20px;
      display: grid;
      gap: 12px;
      box-shadow: var(--shadow-1);
      transition: transform .25s ease, box-shadow .25s ease, border-color .25s ease;
      position: relative;
      overflow: hidden;
    }
    .jurusan-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 4px;
      background: linear-gradient(90deg, var(--primary), var(--accent));
      transform: scaleX(0);
      transition: transform .3s ease;
    }
    .jurusan-card:hover::before { transform: scaleX(1); }
    .jurusan-card:hover {
      transform: translateY(-5px);
      box-shadow: var(--shadow-2);
      border-color: var(--ring-strong);
    }
    .jurusan-icon {
      width: 56px;
      height: 56px;
      border-radius: 12px;
      background: linear-gradient(135deg, #ecfdf5, #d1fae5);
      border: 1.5px solid var(--ring);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 28px;
      margin-bottom: 4px;
      transition: transform .2s ease, background .2s ease;
    }
    .jurusan-card:hover .jurusan-icon {
      transform: scale(1.08);
      background: linear-gradient(135deg, #d1fae5, #a7f3d0);
    }
    .jurusan-card h3 {
      margin: 0;
      font-weight: 800;
      font-size: 18px;
      color: var(--text);
      line-height: 1.3;
    }
    .jurusan-card p {
      margin: 0;
      color: var(--muted);
      font-size: 14px;
      line-height: 1.6;
    }
    .jurusan-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-size: 12px;
      font-weight: 700;
      color: var(--accent);
      background: #e6fffa;
      border: 1px solid #ccfbf1;
      padding: 4px 10px;
      border-radius: 6px;
      margin-top: 4px;
      width: fit-content;
    }

    /* Maps & Kontak */
    .maps-container { width: 100%; border-radius: calc(var(--radius) - 4px); overflow: hidden; background: #ecfdf5; min-height: 400px; border: 1px solid var(--ring); }
    .maps-container iframe { width: 100%; height: 400px; border: none; display: block; }
    .kontak-info { display: grid; gap: 12px; }
    .kontak-item { display: flex; align-items: center; gap: 10px; color: var(--muted); font-size: 14px; }
    .kontak-item strong { color: var(--text); font-weight: 700; }
    .kontak-item a { color: var(--primary); text-decoration: none; transition: color .15s ease; }
    .kontak-item a:hover { color: #047857; text-decoration: underline; }

    /* Footer */
    footer {
      width: 100%;
      max-width: 100%;
      margin-top: 20px;
      background: var(--white);
      border-top: 2px solid var(--ring);
      color: rgba(31,41,55,0.72);
    }
    .footer-inner {
      width: 100%;
      max-width: 1200px;
      margin: 0 auto;
      padding: 14px 24px;
      font-size: 13px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      flex-wrap: wrap;
      box-sizing: border-box;
    }

    /* Responsive */
    @media (max-width: 960px) {
      .hero { grid-template-columns: 1fr; padding: 46px 16px 28px; }
      .section { padding: 24px 16px 12px; }
      .card { grid-column: span 12; }
      .about { grid-template-columns: 1fr; }
      .jurusan-grid { grid-template-columns: 1fr; }
      .brand-text strong { font-size: 13px; }
      .brand-text span { font-size: 11px; }
      .maps-container iframe { height: 300px; }
      .struktur-img-container { min-height: 300px; }
      .nav { padding: 14px 16px; }
      .footer-inner { padding: 14px 16px; }
    }
    @media (min-width: 961px) and (max-width: 1200px) {
      .jurusan-grid { grid-template-columns: repeat(3, 1fr); }
    }

    /* Decorative gradients */
    .grad-a{position:absolute;inset:-120px auto auto -120px;width:360px;height:360px;background:radial-gradient(closest-side,rgba(5,150,105,.16),transparent);filter:blur(6px);border-radius:50%;pointer-events:none}
    .grad-b{position:absolute;inset:-100px -140px auto auto;width:320px;height:320px;background:radial-gradient(closest-side,rgba(13,148,136,.18),transparent);filter:blur(8px);border-radius:50%;pointer-events:none}
  </style>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
      const shell = document.querySelector('.nav-shell');
      function onScroll(){ if (window.scrollY > 8) shell.classList.add('header--scrolled'); else shell.classList.remove('header--scrolled'); }
      onScroll(); window.addEventListener('scroll', onScroll, { passive: true });

      const els = document.querySelectorAll('.reveal');
      if ('IntersectionObserver' in window) {
        const io = new IntersectionObserver((entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              const el = entry.target; const delay = parseInt(el.dataset.delay || '0', 10);
              el.style.transitionDelay = delay ? `${delay}ms` : '0ms'; el.classList.add('is-visible'); io.unobserve(el);
            }
          });
        }, { threshold: 0.12 });
        els.forEach((el) => io.observe(el));
      } else { els.forEach((el) => el.classList.add('is-visible')); }
    });
  </script>
</head>
<body>
  <header>
    <div class="nav-shell">
    <nav class="nav" aria-label="Navigasi utama">
      <a href="#" class="brand reveal" data-delay="0">
        <!-- Replace text logo "BB" with actual logo image -->
        <img src="assets/images/logo-bbpvp.png" alt="Logo BBPVP" class="brand-logo-img float" />
        <div class="brand-text">
          <strong>Balai Besar Pelatihan Vokasi dan Produktivitas Bekasi</strong>
          <span>Kementerian Ketenagakerjaan Republik Indonesia</span>
        </div>
      </a>
      <a class="login-btn reveal" data-delay="80" href="login.php" aria-label="Masuk ke sistem">Masuk Sekarang</a>
    </nav>
    </div>
  </header>

  <main>
    <section class="hero" style="position:relative;">
      <div class="grad-a"></div>
      <div class="grad-b"></div>
      <div>
        <span class="hero-badge reveal" data-delay="40">Sistem Manajemen Penjadwalan Instruktur dan Kelas Pelatihan </span>
        <h1 class="reveal" data-delay="80">Penjadwalan Instruktur & Kelas yang Modern, Rapi, dan Efisien</h1>
        <p class="muted reveal" data-delay="120">
          Pengelolaan Jadwal Pelatihan, Kelas Pelatihan, dan Absensi untuk Instruktur TIK dan Admin sebagai Badan Kepegawaian / SDM dalam satu portal terpadu — modern, cepat, dan mudah digunakan.
        </p>
        <div class="hero-cta reveal" data-delay="160">
          <a class="login-btn" href="login.php">Masuk Sekarang</a>
          <a class="cta-outline" href="#fitur">Lihat Fitur</a>
        </div>
      </div>

      <figure class="hero-media reveal float" data-delay="120" aria-label="Video company profile BBPVP Bekasi">
        <div class="media">
          <!-- Replace image with video tag for company profile -->
          <video width="100%" height="100%" controls autoplay muted loop style="border-radius: calc(var(--radius) - 6px); object-fit: cover; display: block;">
            <source src="assets/videos/Profil BBPVP BEKASI.mp4" type="video/mp4">
            Browser Anda tidak mendukung video HTML5
          </video>
         
        </div>
        <figcaption>Company Profile - BBPVP Bekasi Kemnaker RI</figcaption>
      </figure>
    </section>

    <section id="fitur" class="section" aria-labelledby="fitur-title">
      <h2 id="fitur-title" class="reveal" data-delay="0">Fitur Unggulan</h2>
      <div class="grid">
        <article class="card reveal" data-delay="40">
          <h3>Jadwal Transparan</h3>
          <p>Atur dan tinjau jadwal instruktur serta kelas dengan tampilan yang jelas.</p>
        </article>
        <article class="card reveal" data-delay="80">
          <h3>Manajemen Instruktur</h3>
          <p>Kelola data instruktur secara terpusat sehingga penugasan dan evaluasi lebih efektif.</p>
        </article>
        <article class="card reveal" data-delay="120">
          <h3>Absensi Terintegrasi</h3>
          <p>Pencatatan absensi lengkap dengan pengajuan izin/sakit yang terhubung dengan panel admin.</p>
        </article>
        <article class="card reveal" data-delay="160">
          <h3>Laporan Komprehensif</h3>
          <p>Ekspor laporan jadwal dan kehadiran untuk kebutuhan administrasi dan audit.</p>
        </article>
      </div>
    </section>

    <section id="pelatihan" class="section" aria-labelledby="pelatihan-title">
      <h2 id="pelatihan-title" class="reveal" data-delay="0">Program Pelatihan Berbasis Kompetensi</h2>
      <p class="muted reveal" data-delay="20" style="margin: 0 0 20px; max-width: 65ch;">
        BBPVP Bekasi menyelenggarakan 5 program pelatihan vokasi dan produktivitas berbasis kompetensi untuk meningkatkan kompetensi sumber daya manusia Indonesia.
      </p>
      <div class="jurusan-grid">
        <article class="jurusan-card reveal" data-delay="40">
          <div class="jurusan-icon">💻</div>
          <h3>Teknologi Informasi dan Komunikasi</h3>
          <p>Animator Muda (Junior Animator), Content Creator, Junior Web Developer, Desainer Grafis Muda, Computer Technical Support, Pemasangan Jaringan Komputer, Digital Marketing</p>
          <span class="jurusan-badge">✓ Tersedia</span>
        </article>
        <article class="jurusan-card reveal" data-delay="60">
          <div class="jurusan-icon">⚡</div>
          <h3>Teknik Elektronika</h3>
          <p>Pelatihan pengoperasian industrial manufacturing system, instalasi fiber optik, teknisi instalasi satelit (VSAT), teknisi telepon seluler, pemrograman embedded system berbasis IoT, pengoperasian instrumen dan kontrol, serta instrumentasi elektronika industri.</p>
          <span class="jurusan-badge">✓ Tersedia</span>
        </article>
        <article class="jurusan-card reveal" data-delay="80">
          <div class="jurusan-icon">🔥</div>
          <h3>Teknik Las</h3>
          <p>Plate Welder SMAW 1G/PA, Plate Welder SMAW 1G/PA</p>
          <span class="jurusan-badge">✓ Tersedia</span>
        </article>
        <article class="jurusan-card reveal" data-delay="100">
          <div class="jurusan-icon">❄️</div>
          <h3>Teknisi Pendingin dan Tata Udara</h3>
          <p>Teknisi AC Residential, Teknisi Rerigrasi Domestik, Teknisi Refrigrasi Komersial dan Industrial Refrigeran F GAS, Perawatan AC Residential</p>
          <span class="jurusan-badge">✓ Tersedia</span>
        </article>
        <article class="jurusan-card reveal" data-delay="120">
          <div class="jurusan-icon">🏖️</div>
          <h3>Pariwisata</h3>
          <p>Peracikan Minuman Kopi, Menyediakan Layanan Front Office, Menyiapkan Produk Roti, Mengolah Makanan Komersial, Restaurant Service, Menyediakan Layanan Kebersihan Kamar</p>
          <span class="jurusan-badge">✓ Tersedia</span>
        </article>
      </div>
    </section>

    <section class="section" aria-labelledby="tentang-title">
      <h2 id="tentang-title" class="reveal" data-delay="0">Tentang BBPVP Bekasi</h2>
      <div class="about">
        <div class="about-box about-box-full reveal" data-delay="40">
          <h3>Sejarah BBPVP Bekasi - Kemnaker RI</h3>
          <p>
            Bertempat di Jl. Guntur Raya No.1, Kayuringin Jaya, Bekasi Selatan, BBPVP Bekasi memiliki lokasi yang sangat strategis. Posisinya persis di belakang Gelanggang Olah Raga (GOR) Patriot Candrabhaga Kota Bekasi. Hanya butuh 15 menit dari Gerbang Tol Bekasi Barat dan 10 menit dari stasiun kereta terdekat.
          </p>
          <p>
            Pada awal pendiriannya di tahun 1985, namanya adalah CEVEST, yang merupakan singkatan dari Centre for Vocational and Extention Service Training. CEVEST didirikan dengan bantuan dari pemerintah Jepang sebagai bentuk kerjasama dalam rangka pengembangan Sumber Daya Manusia (SDM) di kawasan ASEAN. CEVEST diresmikan oleh Perdana Menteri Jepang, Zenko Suzuki, sementara dari Indonesia diwakili oleh Sudomo selaku Menteri Tenaga Kerja dan Hartanto sebagai Menteri Perindustrian.
          </p>
          <p>
            Lembaga pengembangan pelatihan kerja ini beberapa kali mengalami perubahan nama. Tahun 1986 menjadi Diklat Instruktur CEVEST. Tahun 1990 menjadi Balai Latihan Instruktur dan Pengembangan (BLIP). Tahun 2001 berubah nama lagi menjadi Pusat Pengembangan Pelatihan Tenaga Kerja Industri Jasa (P3TKIJ).
          </p>
          <p>
            Pada 2002, dengan ditambahnya tugas dan fungsi CEVEST untuk melaksanakan pelatihan kerja ke luar negeri, yang awalnya unit kerja Eselon III berubah menjadi unit kerja Eselon II dengan nama Pusat Pelatihan Kerja Tenaga Kerja Luar Negeri (Puslatker TKLN). Pada 2006, CEVEST berubah nama lagi menjadi Balai Besar Pengembangan Latihan Kerja Luar Negeri (BBPLKLN). Pada 2017, berubah nama lagi menjadi Balai Besar Pengembangan Latihan Kerja (BBPLK) Bekasi. Dan sejak 2021 berubah menjadi Balai Besar Pelatihan Vokasi dan Produktivitas (BBPVP) Bekasi.
          </p>
          <p>
            Sejarah panjang perubahan nama ini disertai dengan perubahan atau penambahan tugas dan fungsi BBPVP Bekasi dalam melayani masyarakat terutama di bidang pelatihan. Hingga kini, sebutan CEVEST sudah sangatlah melekat. Telebih saat awal pendiriannya, bisa dibilang CEVEST adalah bangunan megah pertama di Bekasi.
          </p>
          <p>
            Dari 21 Unit Pelaksana Teknis (UPT) Bidang Pelatihan Vokasi dan Produktivitas Kementerian Ketenagakerjaan yang tersebar di seluruh Indonesia, hanya 6 yang merupakan Balai Besar Pelatihan Vokasi dan Produktivitas (BBPVP), dan BBPVP Bekasi adalah salah satunya. Sedang 15 lainnya adalah Balai Pelatihan Vokasi dan Produktivitas (BPVP).
          </p>
        </div>
        <div class="about-box reveal" data-delay="80">
          <h3>Layanan Utama</h3>
          <ul>
            <li>Pengelolaan jadwal pelatihan</li>
            <li>Manajemen instruktur dan kelas</li>
            <li>Rekap absensi dan materi pelatihan</li>
            <li>Penyusunan laporan berkala</li>
          </ul>
        </div>
      </div>
    </section>

    <section class="section" aria-labelledby="struktur-title">
      <h2 id="struktur-title" class="reveal" data-delay="0">Struktur Organisasi</h2>
      <div class="struktur-box reveal" data-delay="40">
        <div class="struktur-img-container">
          
          <!-- Uncomment dan ganti src dengan path gambar struktur organisasi saat sudah tersedia -->
          <img src="assets/images/struktur bppvp.jpg" alt="Struktur Organisasi BBPVP Bekasi" /> 
        </div>
      </div>
    </section>

    <section class="section" aria-labelledby="kontak-title">
      <h2 id="kontak-title" class="reveal" data-delay="0">Kontak & Lokasi</h2>
      <div class="about">
        <div class="about-box reveal" data-delay="80">
          <h3>Informasi Kontak</h3>
          <div class="kontak-info">
            <div class="kontak-item">
              <strong>Email:</strong>
              <a href="mailto:cevest.bekasi@gmail.com">cevest.bekasi@gmail.com</a>
            </div>
            <div class="kontak-item">
              <strong>WhatsApp:</strong>
              <a href="https://wa.me/6281319648363" target="_blank" rel="noopener noreferrer">+62 813-1964-8363</a>
            </div>
            <div class="kontak-item">
              <strong>Alamat:</strong>
              <span>Jl. Guntur Raya No.1, Kayuringin Jaya, Bekasi Selatan, Kota Bekasi</span>
            </div>
          </div>
        </div>
        <div class="about-box reveal" data-delay="80">
          <h3>Peta Lokasi</h3>
          <div class="maps-container">
            <iframe 
              src="https://www.google.com/maps?q=Jl.+Guntur+Raya+No.1,+Kayuringin+Jaya,+Bekasi+Selatan,+Kota+Bekasi&output=embed" 
              allowfullscreen="" 
              loading="lazy" 
              referrerpolicy="no-referrer-when-downgrade"
              title="Lokasi BBPVP Bekasi - Jl. Guntur Raya No.1, Kayuringin Jaya, Bekasi Selatan">
            </iframe>
          </div>
          <p style="margin-top: 12px; font-size: 12px; color: var(--muted); text-align: center;">
            <a href="https://maps.app.goo.gl/mmU83nr9ZJ1P1yib8" target="_blank" rel="noopener noreferrer" style="color: var(--primary); text-decoration: none; font-weight: 600; display: inline-flex; align-items: center; gap: 6px;">
              <span>📍</span> <span>Buka di Google Maps</span>
            </a>
          </p>
        </div>
      </div>
      
      <!-- Contact Form Section -->
      <div class="about" style="margin-top: 24px;">
        <div class="about-box about-box-full reveal" data-delay="40">
          <br><h3>Formulir Saran & Kontak</h3>
          <p class="muted">Kirimi kami pesan untuk saran, pertanyaan, atau masukan Anda.</p>
          
          <div id="formMessage" style="display: none; padding: 12px; border-radius: 8px; margin-top: 16px; margin-bottom: 16px;"></div>
          
          <form id="contactForm" style="margin-top: 24px;">
            <div style="display: grid; gap: 24px;">
              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                <div>
                  <label for="name" style="display: block; font-weight: 600; margin-bottom: 6px;">Nama Lengkap <span style="color: #ef4444;">*</span></label>
                  <input type="text" id="name" name="name" required minlength="2" style="width: 100%; padding: 12px; border: 1.5px solid var(--ring); border-radius: 8px; font-family: inherit; font-size: 14px; box-sizing: border-box;">
                </div>
                <div>
                  <label for="email" style="display: block; font-weight: 600; margin-bottom: 6px;">Email <span style="color: #ef4444;">*</span></label>
                  <input type="email" id="email" name="email" required style="width: 100%; padding: 12px; border: 1.5px solid var(--ring); border-radius: 8px; font-family: inherit; font-size: 14px; box-sizing: border-box;">
                </div>
              </div>
              <div>
                <label for="subject" style="display: block; font-weight: 600; margin-bottom: 6px;">Subjek <span style="color: #ef4444;">*</span></label>
                <input type="text" id="subject" name="subject" required minlength="3" style="width: 100%; padding: 12px; border: 1.5px solid var(--ring); border-radius: 8px; font-family: inherit; font-size: 14px; box-sizing: border-box;">
              </div>
              <div>
                <label for="message" style="display: block; font-weight: 600; margin-bottom: 6px;">Pesan <span style="color: #ef4444;">*</span></label>
                <textarea id="message" name="message" rows="5" required minlength="10" style="width: 100%; padding: 12px; border: 1.5px solid var(--ring); border-radius: 8px; font-family: inherit; font-size: 14px; resize: vertical; box-sizing: border-box;"></textarea>
              </div>
              <div>
                <button type="submit" id="submitBtn" class="login-btn" style="border: none; cursor: pointer; width: 100%;">Kirim Pesan</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </section>

    <section class="section" aria-label="Ajak Masuk">
      <div class="about-box reveal" data-delay="0" style="display: grid; place-items: start;">
        <h3>Siap Mulai Mengelola?</h3>
        <p class="muted">Masuk untuk mulai mengelola jadwal, absensi, dan laporan.</p>
        <a class="login-btn" href="login.php">Masuk ke Sistem</a>
      </div>
    </section>
  </main>
  <footer>
    <div class="footer-inner">
      <div>© <?php echo date('Y'); ?> BBPVP Bekasi — Manajemen Penjadwalan</div>
      <div>Dapat digunakan bersama oleh instruktur dan admin untuk kolaborasi yang rapi.</div>
    </div>
  </footer>

  <!-- EmailJS Script - Sederhana, langsung kirim ke Gmail -->
  <!-- 
    CARA SETUP EMAILJS (SANGAT MUDAH, GRATIS):
    1. Daftar di https://www.emailjs.com (gratis, tidak perlu kartu kredit)
    2. Setelah login, buat Email Service:
       - Klik "Add New Service"
       - Pilih "Gmail"
       - Login dengan Gmail sastiodwipangestu@gmail.com
       - Simpan Service ID (contoh: service_xxxxx)
    3. Buat Email Template:
       - Klik "Create New Template"
       - Subject: {{subject}}
       - Content: 
         Dari: {{from_name}} ({{from_email}})
         Subjek: {{subject}}
         Pesan: {{message}}
         Tanggal: {{date}}
       - To Email: sastiodwipangestu@gmail.com
       - From Name: {{from_name}}
       - Reply To: {{from_email}}
       - Simpan Template ID (contoh: template_xxxxx)
    4. Ambil Public Key:
       - Klik "Account" > "General"
       - Copy "Public Key"
    5. Ganti di bawah ini:
       - YOUR_PUBLIC_KEY -> Public Key Anda
       - YOUR_SERVICE_ID -> Service ID Anda
       - YOUR_TEMPLATE_ID -> Template ID Anda
  -->
  <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js"></script>
  <script>
    // ===== KONFIGURASI EMAILJS =====
    // GANTI 3 NILAI DI BAWAH INI dengan data dari EmailJS
    const EMAILJS_PUBLIC_KEY = "AmPFmRBaHrp2zudMJ"; // Public Key dari EmailJS Account
    const EMAILJS_SERVICE_ID = "service_a7ntsy5"; // Service ID dari Email Service yang dibuat
    const EMAILJS_TEMPLATE_ID = "template_heaj3rb"; // Template ID dari Email Template yang dibuat
    // =================================
    
    // Inisialisasi EmailJS
    (function(){
      if (EMAILJS_PUBLIC_KEY !== "YOUR_PUBLIC_KEY") {
        emailjs.init(EMAILJS_PUBLIC_KEY);
      } else {
        console.warn('EmailJS belum dikonfigurasi. Silakan isi EMAILJS_PUBLIC_KEY, EMAILJS_SERVICE_ID, dan EMAILJS_TEMPLATE_ID di kode.');
      }
    })();

    // Handle form submit
    document.getElementById('contactForm').addEventListener('submit', function(e) {
      e.preventDefault();
      
      const submitBtn = document.getElementById('submitBtn');
      const formMessage = document.getElementById('formMessage');
      const originalBtnText = submitBtn.textContent;
      
      // Disable button dan ubah text
      submitBtn.disabled = true;
      submitBtn.textContent = 'Mengirim...';
      formMessage.style.display = 'none';
      
      // Ambil data form (sesuai dengan template EmailJS yang sudah dibuat)
      const templateParams = {
        name: document.getElementById('name').value,
        email: document.getElementById('email').value,
        title: document.getElementById('subject').value,
        message: document.getElementById('message').value,
        time: new Date().toLocaleString('id-ID')
      };
      
      // Cek apakah EmailJS sudah dikonfigurasi
      if (EMAILJS_PUBLIC_KEY === "YOUR_PUBLIC_KEY" || EMAILJS_SERVICE_ID === "YOUR_SERVICE_ID" || EMAILJS_TEMPLATE_ID === "YOUR_TEMPLATE_ID") {
        formMessage.style.display = 'block';
        formMessage.style.background = '#fee2e2';
        formMessage.style.color = '#991b1b';
        formMessage.style.border = '1px solid #ef4444';
        formMessage.textContent = 'EmailJS belum dikonfigurasi. Silakan hubungi admin untuk setup EmailJS.';
        submitBtn.disabled = false;
        submitBtn.textContent = originalBtnText;
        return;
      }
      
      // Kirim email via EmailJS
      emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, templateParams)
        .then(function(response) {
          // Sukses
          formMessage.style.display = 'block';
          formMessage.style.background = '#d1fae5';
          formMessage.style.color = '#065f46';
          formMessage.style.border = '1px solid #10b981';
          formMessage.textContent = 'Terima kasih! Pesan Anda telah berhasil dikirim ke Gmail. Kami akan merespons secepatnya.';
          
          // Reset form
          document.getElementById('contactForm').reset();
          
          // Scroll ke pesan
          formMessage.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }, function(error) {
          // Error
          formMessage.style.display = 'block';
          formMessage.style.background = '#fee2e2';
          formMessage.style.color = '#991b1b';
          formMessage.style.border = '1px solid #ef4444';
          formMessage.textContent = 'Maaf, terjadi kesalahan saat mengirim pesan. Pastikan EmailJS sudah dikonfigurasi dengan benar. Silakan hubungi admin atau coba lagi nanti.';
          console.error('EmailJS Error:', error);
        })
        .finally(function() {
          // Enable button kembali
          submitBtn.disabled = false;
          submitBtn.textContent = originalBtnText;
        });
    });
  </script>

</body>
</html>
