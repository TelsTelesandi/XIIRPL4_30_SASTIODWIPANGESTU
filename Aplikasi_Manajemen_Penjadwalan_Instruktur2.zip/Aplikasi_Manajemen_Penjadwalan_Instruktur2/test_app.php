<?php
// Test file untuk memastikan semua fitur berfungsi
session_start();
include "config/database.php";

echo "<h1>Test Aplikasi Manajemen Penjadwalan Instruktur</h1>";

// Test database connection
if ($conn) {
    echo "<p style='color: green;'>✓ Database connection: OK</p>";
} else {
    echo "<p style='color: red;'>✗ Database connection: FAILED</p>";
}

// Test table existence
$tables = ['instruktur', 'kelas', 'materi', 'absensi', 'jadwal'];
foreach ($tables as $table) {
    $result = mysqli_query($conn, "SHOW TABLES LIKE '$table'");
    if (mysqli_num_rows($result) > 0) {
        echo "<p style='color: green;'>✓ Table '$table': EXISTS</p>";
    } else {
        echo "<p style='color: red;'>✗ Table '$table': NOT FOUND</p>";
    }
}

// Test upload directory
if (is_dir('uploads/materi')) {
    echo "<p style='color: green;'>✓ Upload directory: EXISTS</p>";
    if (is_writable('uploads/materi')) {
        echo "<p style='color: green;'>✓ Upload directory: WRITABLE</p>";
    } else {
        echo "<p style='color: red;'>✗ Upload directory: NOT WRITABLE</p>";
    }
} else {
    echo "<p style='color: red;'>✗ Upload directory: NOT FOUND</p>";
}

// Test file permissions
$test_files = [
    'instruktur/materi/index.php',
    'instruktur/materi/upload.php',
    'instruktur/materi/download.php',
    'instruktur/materi/hapus.php',
    'admin/materi/index.php',
    'admin/materi/hapus.php'
];

foreach ($test_files as $file) {
    if (file_exists($file)) {
        echo "<p style='color: green;'>✓ File '$file': EXISTS</p>";
    } else {
        echo "<p style='color: red;'>✗ File '$file': NOT FOUND</p>";
    }
}

// Test sample data
$instruktur_count = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM instruktur"));
$kelas_count = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM kelas"));
$materi_count = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM materi"));

echo "<h2>Data Summary:</h2>";
echo "<p>Instruktur: $instruktur_count</p>";
echo "<p>Kelas: $kelas_count</p>";
echo "<p>Materi: $materi_count</p>";

echo "<h2>Test Links:</h2>";
echo "<p><a href='login.php'>Login Page</a></p>";
echo "<p><a href='instruktur/dashboard.php'>Instruktur Dashboard</a></p>";
echo "<p><a href='admin/dashboard.php'>Admin Dashboard</a></p>";

echo "<h2>Security Test:</h2>";
echo "<p>Session ID: " . session_id() . "</p>";
echo "<p>Current Time: " . date('Y-m-d H:i:s') . "</p>";
?>
