<?php
// Set timezone ke Asia/Jakarta (WIB) untuk sinkronisasi dengan waktu lokal
date_default_timezone_set('Asia/Jakarta');

session_start();
include "../config/database.php";
include "../config/app.php";

/**
 * Absensi Instruktur - revised, safer & consistent
 */

// --- cek login instruktur --- 
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'instruktur') {
    header('Location: ' . app_url('login.php'));
    exit;
}

$instruktur_id = intval($_SESSION['instruktur_id'] ?? 0);

// --- bootstrap kolom lokasi di tabel absensi (jika belum ada) ---
try {
    $needLat = true;
    $needLng = true;
    $needValid = true;
    $needDist = true;
    if ($c = mysqli_query($conn, "SHOW COLUMNS FROM absensi LIKE 'latitude'")) {
        if (mysqli_num_rows($c) > 0) $needLat = false;
        mysqli_free_result($c);
    }
    if ($c = mysqli_query($conn, "SHOW COLUMNS FROM absensi LIKE 'longitude'")) {
        if (mysqli_num_rows($c) > 0) $needLng = false;
        mysqli_free_result($c);
    }
    if ($c = mysqli_query($conn, "SHOW COLUMNS FROM absensi LIKE 'lokasi_valid'")) {
        if (mysqli_num_rows($c) > 0) $needValid = false;
        mysqli_free_result($c);
    }
    if ($c = mysqli_query($conn, "SHOW COLUMNS FROM absensi LIKE 'jarak_meter'")) {
        if (mysqli_num_rows($c) > 0) $needDist = false;
        mysqli_free_result($c);
    }
    if ($needLat) {
        @mysqli_query($conn, "ALTER TABLE absensi ADD COLUMN latitude DECIMAL(10,7) NULL");
    }
    if ($needLng) {
        @mysqli_query($conn, "ALTER TABLE absensi ADD COLUMN longitude DECIMAL(10,7) NULL");
    }
    if ($needValid) {
        @mysqli_query($conn, "ALTER TABLE absensi ADD COLUMN lokasi_valid TINYINT(1) NOT NULL DEFAULT 0");
    }
    if ($needDist) {
        @mysqli_query($conn, "ALTER TABLE absensi ADD COLUMN jarak_meter INT NULL");
    }
} catch (Throwable $e) {
    // abaikan error alter table, jangan blokir halaman
}

// --- koordinat Sekolah (dari Google Maps link) ---
// Link Google Maps: https://maps.app.goo.gl/VUPkBmV9uUmYKiUy8
// CARA MENDAPATKAN KOORDINAT:
// 1. Buka link Google Maps di atas
// 2. Klik kanan pada pin lokasi sekolah
// 3. Pilih "Koordinat" atau lihat di URL (setelah @ akan ada angka seperti -6.xxxxx,107.xxxxx)
// 4. Copy angka pertama (latitude) dan angka kedua (longitude)
// 5. Paste di bawah ini
$SEKOLAH_LAT = -6.2476; // Latitude sekolah (GANTI dengan koordinat dari Google Maps)
$SEKOLAH_LNG = 107.0000; // Longitude sekolah (GANTI dengan koordinat dari Google Maps)
$SEKOLAH_MAX_RADIUS_M = 10000; // radius maksimal diterima (meter) - diperbesar menjadi 10000m (10 km)
// CATATAN: Radius 10 km sudah cukup besar untuk mencakup seluruh area sekolah termasuk kelas.
// Pastikan koordinat sekolah sudah diupdate dengan benar dari Google Maps link.

// --- bootstrap tabel pengajuan_izin (jika belum ada) --- 
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS pengajuan_izin (
  pengajuan_id INT AUTO_INCREMENT PRIMARY KEY,
  instruktur_id INT NOT NULL,
  tanggal DATE NOT NULL,
  jenis ENUM('Izin','Sakit') NOT NULL,
  alasan TEXT NULL,
  lampiran VARCHAR(255) NULL,
  status ENUM('Diajukan','Disetujui','Ditolak','Dibatalkan') NOT NULL DEFAULT 'Diajukan',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  decided_at DATETIME NULL,
  decided_by INT NULL,
  INDEX (instruktur_id),
  INDEX (tanggal)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// --- helper: nama hari & bulan bahasa Indonesia --- 
$days = [
    'Sunday'    => 'Minggu',
    'Monday'    => 'Senin',
    'Tuesday'   => 'Selasa',
    'Wednesday' => 'Rabu',
    'Thursday'  => 'Kamis',
    'Friday'    => 'Jumat',
    'Saturday'  => 'Sabtu'
];
$months = [
    1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
    5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
    9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
];

// tanggal/hari sekarang
$tgl = date("Y-m-d");
$hari = $days[date("l")] ?? date("l");
$waktu_absen = date("H:i:s");

// --- backfill 'Alfa' for missed attendance untuk hari-hari SEBELUM hari ini --- 
// CATATAN PENTING: Backfill HANYA untuk hari-hari SEBELUM hari ini, BUKAN hari ini
// Hari ini akan di-handle oleh logika AUTO ALFA di bawah (setelah jam 18:00 WIB)
// Backfill ini untuk mengecek hari-hari kemarin yang belum diisi absensinya
try {
    // Hanya backfill untuk hari-hari SEBELUM hari ini (bukan hari ini)
    $end_range = date('Y-m-d', strtotime('-1 day', strtotime($tgl)));
    $start_range = null;

    if ($stmtMin = mysqli_prepare($conn, "SELECT MIN(tanggal) AS min_tgl FROM jadwal WHERE instruktur_id = ?")) {
        mysqli_stmt_bind_param($stmtMin, "i", $instruktur_id);
        mysqli_stmt_execute($stmtMin);
        $resMin = mysqli_stmt_get_result($stmtMin);
        $rowMin = mysqli_fetch_assoc($resMin);
        $start_range = $rowMin['min_tgl'] ?? null;
        mysqli_stmt_close($stmtMin);
    }

    // Pastikan start_range tidak melebihi end_range (hari ini tidak termasuk)
    if ($start_range && $start_range > $end_range) {
        $start_range = null; // Tidak ada yang perlu di-backfill
    }

    // Hanya backfill jika ada range yang valid (hari-hari sebelum hari ini)
    if ($start_range && $start_range <= $end_range && ($stmt = mysqli_prepare($conn, "
        SELECT j.jadwal_id, j.tanggal
        FROM jadwal j
        LEFT JOIN absensi a
            ON a.instruktur_id = j.instruktur_id AND a.tanggal = j.tanggal
        LEFT JOIN pengajuan_izin p
            ON p.instruktur_id = j.instruktur_id AND p.tanggal = j.tanggal AND p.status = 'Disetujui'
        WHERE j.instruktur_id = ?
          AND j.tanggal BETWEEN ? AND ?
          AND a.absensi_id IS NULL
          AND p.pengajuan_id IS NULL
        ORDER BY j.tanggal ASC
    "))) {
        mysqli_stmt_bind_param($stmt, "iss", $instruktur_id, $start_range, $end_range);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        while ($row = mysqli_fetch_assoc($res)) {
            $tgl_row = $row['tanggal'];
            $hari_row = $days[date('l', strtotime($tgl_row))] ?? date('l', strtotime($tgl_row));
            if ($ins = mysqli_prepare($conn, "INSERT INTO absensi (jadwal_id, instruktur_id, tanggal, hari, status, alasan, waktu_absen) VALUES (?, ?, ?, ?, 'Alfa', NULL, '00:00:00')")) {
                mysqli_stmt_bind_param($ins, "iiss", $row['jadwal_id'], $instruktur_id, $tgl_row, $hari_row);
                mysqli_stmt_execute($ins);
                mysqli_stmt_close($ins);
            }
        }
        mysqli_stmt_close($stmt);
    }
} catch (Throwable $e) {
    // ignore backfill errors to not block page usage
}

// --- ambil data instruktur (prepared) --- 
$instruktur_data = null;
if ($stmt = mysqli_prepare($conn, "SELECT * FROM instruktur WHERE instruktur_id = ? LIMIT 1")) {
    mysqli_stmt_bind_param($stmt, "i", $instruktur_id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $instruktur_data = mysqli_fetch_assoc($res);
    mysqli_stmt_close($stmt);
}

// --- cari jadwal instruktur hari ini (dipakai untuk menentukan jadwal_id) --- 
$jadwal_id = null;
$jadwal_info = null;
if ($stmt = mysqli_prepare($conn, "
    SELECT j.jadwal_id, j.tanggal, j.jam_mulai, j.jam_selesai, k.nama_kelas
    FROM jadwal j
    LEFT JOIN kelas k ON k.kelas_id = j.kelas_id
    WHERE j.instruktur_id = ? AND j.tanggal = ? LIMIT 1
")) {
    mysqli_stmt_bind_param($stmt, "is", $instruktur_id, $tgl);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $jadwal_info = mysqli_fetch_assoc($res);
    $jadwal_id = $jadwal_info['jadwal_id'] ?? null;
    mysqli_stmt_close($stmt);
}

// --- cek apakah sudah absen hari ini --- 
// pilih alias: alasan AS keterangan supaya view bisa panggil 'keterangan' kalau mau
$absen = null;
if ($stmt = mysqli_prepare($conn, "SELECT absensi.*, alasan AS keterangan FROM absensi WHERE instruktur_id = ? AND tanggal = ? LIMIT 1")) {
    mysqli_stmt_bind_param($stmt, "is", $instruktur_id, $tgl);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $absen = mysqli_fetch_assoc($res);
    mysqli_stmt_close($stmt);
}

// --- cek apakah ada pengajuan izin/sakit pending untuk hari ini --- 
$pending_pengajuan_today = false;
if ($stmt = mysqli_prepare($conn, "SELECT pengajuan_id FROM pengajuan_izin WHERE instruktur_id = ? AND tanggal = ? AND status = 'Diajukan' LIMIT 1")) {
	mysqli_stmt_bind_param($stmt, "is", $instruktur_id, $tgl);
	mysqli_stmt_execute($stmt);
	$res = mysqli_stmt_get_result($stmt);
	$pending_pengajuan_today = mysqli_fetch_assoc($res) ? true : false;
	mysqli_stmt_close($stmt);
}

// --- Hapus absensi Alfa yang dibuat sebelum jam 18:00 WIB (jika ada) ---
// Ini untuk memastikan user masih bisa absen jika belum lewat jam 18:00
// PENTING: Ini harus jalan SEBELUM logika auto Alfa
$jam_sekarang = (int)date('H'); // Jam dalam format 24 jam (0-23)
$menit_sekarang = (int)date('i'); // Menit (0-59)
// Sudah lewat 18:00 jika jam > 18 ATAU (jam == 18 DAN menit > 0)
$sudah_lewat_18 = ($jam_sekarang > 18) || ($jam_sekarang == 18 && $menit_sekarang > 0);

// Hapus Alfa prematur: jika ada absensi Alfa dan belum lewat jam 18:00, hapus
if ($absen && $absen['status'] === 'Alfa' && !$sudah_lewat_18) {
    // Hapus absensi Alfa yang dibuat sebelum waktunya
    if ($stmt_del = mysqli_prepare($conn, "DELETE FROM absensi WHERE instruktur_id = ? AND tanggal = ? AND status = 'Alfa'")) {
        mysqli_stmt_bind_param($stmt_del, "is", $instruktur_id, $tgl);
        mysqli_stmt_execute($stmt_del);
        mysqli_stmt_close($stmt_del);
        $absen = null; // Reset agar form absensi muncul kembali
        
        // Reload untuk memastikan $absen benar-benar null
        if ($stmt_reload = mysqli_prepare($conn, "SELECT absensi.*, alasan AS keterangan FROM absensi WHERE instruktur_id = ? AND tanggal = ? LIMIT 1")) {
            mysqli_stmt_bind_param($stmt_reload, "is", $instruktur_id, $tgl);
            mysqli_stmt_execute($stmt_reload);
            $res_reload = mysqli_stmt_get_result($stmt_reload);
            $absen = mysqli_fetch_assoc($res_reload);
            mysqli_stmt_close($stmt_reload);
        }
    }
}

// --- AUTO ALFA: Otomatis set Alfa jika ada jadwal hari ini tapi belum absen sampai jam 18:00 WIB ---
// Logika: Jika ada jadwal hari ini, belum absen, dan sudah SETELAH jam 18:00 WIB, otomatis set Alfa
// Durasi absensi: 00:00 - 18:00 WIB. Setelah 18:00 WIB, otomatis Alfa jika belum absen.
// CATATAN: Absensi masih bisa dilakukan dari 00:00 sampai 18:00 WIB. Setelah 18:00 WIB baru otomatis Alfa.
if (!$absen && !$pending_pengajuan_today && $jadwal_id) {
    // Jika sudah SETELAH jam 18:00 WIB (lebih dari 18:00:00)
    // Jam 18:00:00 masih bisa absen, setelah 18:00:01 baru otomatis Alfa
    if ($sudah_lewat_18) {
        // Cek apakah sudah ada pengajuan izin/sakit yang disetujui
        $ada_izin_disetujui = false;
        if ($stmt = mysqli_prepare($conn, "SELECT pengajuan_id FROM pengajuan_izin WHERE instruktur_id = ? AND tanggal = ? AND status = 'Disetujui' LIMIT 1")) {
            mysqli_stmt_bind_param($stmt, "is", $instruktur_id, $tgl);
            mysqli_stmt_execute($stmt);
            $res = mysqli_stmt_get_result($stmt);
            $ada_izin_disetujui = mysqli_fetch_assoc($res) ? true : false;
            mysqli_stmt_close($stmt);
        }
        
        // Jika tidak ada izin yang disetujui, otomatis set Alfa
        if (!$ada_izin_disetujui) {
            // Cek dulu apakah sudah ada absensi Alfa (untuk menghindari duplikat)
            $cek_alfa = null;
            if ($stmt_cek = mysqli_prepare($conn, "SELECT absensi_id FROM absensi WHERE instruktur_id = ? AND tanggal = ? AND status = 'Alfa' LIMIT 1")) {
                mysqli_stmt_bind_param($stmt_cek, "is", $instruktur_id, $tgl);
                mysqli_stmt_execute($stmt_cek);
                $res_cek = mysqli_stmt_get_result($stmt_cek);
                $cek_alfa = mysqli_fetch_assoc($res_cek);
                mysqli_stmt_close($stmt_cek);
            }
            
            // Jika belum ada absensi Alfa, insert baru
            if (!$cek_alfa) {
                if ($stmt = mysqli_prepare($conn, "INSERT INTO absensi (jadwal_id, instruktur_id, tanggal, hari, status, alasan, waktu_absen) VALUES (?, ?, ?, ?, 'Alfa', 'Tidak melakukan absensi hingga pukul 18:00 WIB', '18:00:00')")) {
                    mysqli_stmt_bind_param($stmt, "iiss", $jadwal_id, $instruktur_id, $tgl, $hari);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                    
                    // Reload data absensi setelah insert
                    if ($stmt2 = mysqli_prepare($conn, "SELECT absensi.*, alasan AS keterangan FROM absensi WHERE instruktur_id = ? AND tanggal = ? LIMIT 1")) {
                        mysqli_stmt_bind_param($stmt2, "is", $instruktur_id, $tgl);
                        mysqli_stmt_execute($stmt2);
                        $res2 = mysqli_stmt_get_result($stmt2);
                        $absen = mysqli_fetch_assoc($res2);
                        mysqli_stmt_close($stmt2);
                    }
                }
            }
        }
    }
}

$success_message = "";
$error_message = "";

// --- handle POST (simpan absensi) --- 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$absen && !$pending_pengajuan_today) {
    // validasi & sanitasi input
    $status = trim($_POST['status'] ?? '');
    $alasan = trim($_POST['alasan'] ?? '');

    // lokasi dari browser (untuk status Hadir)
    $post_latitude  = isset($_POST['latitude']) ? trim($_POST['latitude']) : null;
    $post_longitude = isset($_POST['longitude']) ? trim($_POST['longitude']) : null;

    // valid status (Alfa tidak bisa dipilih manual, hanya otomatis)
    $allowed_status = ['Hadir', 'Izin', 'Sakit'];
    if (!in_array($status, $allowed_status, true)) {
        $error_message = "Status tidak valid.";
	} elseif (!$jadwal_id && $status === 'Hadir') {
        $error_message = "Tidak ada jadwal untuk hari ini. Absensi tidak dapat disimpan.";
    } else {
		if ($status === 'Izin' || $status === 'Sakit') {
			// Buat pengajuan izin/sakit instead of langsung absensi
			$lampiranPath = null;
			if (!empty($_FILES['lampiran']['name']) && $_FILES['lampiran']['error'] === UPLOAD_ERR_OK) {
				$uploadDir = __DIR__ . '/../uploads/pengajuan/';
				if (!is_dir($uploadDir)) @mkdir($uploadDir, 0775, true);
				$ext = pathinfo($_FILES['lampiran']['name'], PATHINFO_EXTENSION);
				$base = pathinfo($_FILES['lampiran']['name'], PATHINFO_FILENAME);
				$baseSafe = preg_replace('/[^a-zA-Z0-9-_]/','_', $base);
				$fname = 'lampiran_' . date('Ymd_His') . '_' . $baseSafe . ($ext ? '.' . strtolower($ext) : '');
				$dest = $uploadDir . $fname;
				if (move_uploaded_file($_FILES['lampiran']['tmp_name'], $dest)) {
					$lampiranPath = 'uploads/pengajuan/' . $fname;
				}
			}
			if ($stmt = mysqli_prepare($conn, "INSERT INTO pengajuan_izin (instruktur_id, tanggal, jenis, alasan, lampiran, status) VALUES (?, ?, ?, ?, ?, 'Diajukan')")) {
				mysqli_stmt_bind_param($stmt, "issss", $instruktur_id, $tgl, $status, $alasan, $lampiranPath);
				$exec = mysqli_stmt_execute($stmt);
				mysqli_stmt_close($stmt);
				if ($exec) {
					$success_message = "Pengajuan $status berhasil dikirim. Menunggu persetujuan admin.";
					$pending_pengajuan_today = true;
				} else {
					$error_message = "Gagal mengirim pengajuan. Coba lagi.";
				}
			} else {
				$error_message = "Gagal menyiapkan pengajuan.";
			}
		} else {
			// Simpan absensi (mis. Hadir / Alfa)

            // --- validasi & hitung lokasi untuk status Hadir ---
            $latitude = null;
            $longitude = null;
            $lokasi_valid = 0;
            $jarak_meter = null;

            if ($status === 'Hadir') {
                if ($post_latitude === null || $post_longitude === null || $post_latitude === '' || $post_longitude === '') {
                    $error_message = "Lokasi wajib diambil dari Maps untuk status Hadir.";
                } elseif (!is_numeric($post_latitude) || !is_numeric($post_longitude)) {
                    $error_message = "Data lokasi tidak valid.";
                } else {
                    $latitude = floatval($post_latitude);
                    $longitude = floatval($post_longitude);

                    // hitung jarak menggunakan rumus haversine (meter)
                    $jarak_meter = (int) round(haversine_distance(
                        $latitude,
                        $longitude,
                        $SEKOLAH_LAT,
                        $SEKOLAH_LNG
                    ));

                    if ($jarak_meter <= $SEKOLAH_MAX_RADIUS_M) {
                        $lokasi_valid = 1;
                    } else {
                        $lokasi_valid = 0;
                        $jarak_km = round($jarak_meter / 1000, 2);
                        $radius_km = round($SEKOLAH_MAX_RADIUS_M / 1000, 1);
                        $error_message = "Lokasi Anda berada di luar area sekolah. Jarak Anda: {$jarak_km} km, radius maksimal: {$radius_km} km (± {$SEKOLAH_MAX_RADIUS_M} meter).";
                    }
                }
            }

            if ($error_message) {
                // jika ada error lokasi, jangan simpan absensi
            } else {
                $sql = "INSERT INTO absensi (jadwal_id, instruktur_id, tanggal, hari, status, alasan, waktu_absen, latitude, longitude, lokasi_valid, jarak_meter)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                if ($stmt = mysqli_prepare($conn, $sql)) {
                    mysqli_stmt_bind_param($stmt, "iisssssddii", $jadwal_id, $instruktur_id, $tgl, $hari, $status, $alasan, $waktu_absen, $latitude, $longitude, $lokasi_valid, $jarak_meter);
				$exec = mysqli_stmt_execute($stmt);
				if ($exec) {
					$success_message = "Absensi berhasil disimpan!";
					mysqli_stmt_close($stmt);
					if ($stmt2 = mysqli_prepare($conn, "SELECT absensi.*, alasan AS keterangan FROM absensi WHERE instruktur_id = ? AND tanggal = ? LIMIT 1")) {
						mysqli_stmt_bind_param($stmt2, "is", $instruktur_id, $tgl);
						mysqli_stmt_execute($stmt2);
						$res2 = mysqli_stmt_get_result($stmt2);
						$absen = mysqli_fetch_assoc($res2);
						mysqli_stmt_close($stmt2);
					}
				} else {
					$error_message = "Gagal menyimpan absensi. Coba lagi. (" . htmlspecialchars(mysqli_error($conn)) . ")";
					mysqli_stmt_close($stmt);
				}
                } else {
                    $error_message = "Gagal menyiapkan query. (" . htmlspecialchars(mysqli_error($conn)) . ")";
                }
            }
		}
    }
}

$has_form = (!$absen && !$pending_pengajuan_today && $jadwal_id);

// Helper: format tanggal header "Senin, 01 Januari 2025"
function tgl_indonesia_header($date_str, $days_map, $months_map) {
    $ts = strtotime($date_str);
    if ($ts === false) return htmlspecialchars($date_str);
    $dayname = $days_map[date('l', $ts)] ?? date('l', $ts);
    $d = date('d', $ts);
    $m = (int)date('n', $ts);
    $y = date('Y', $ts);
    $monthname = $months_map[$m] ?? date('F', $ts);
    return "{$dayname}, {$d} {$monthname} {$y}";
}

// Helper: hitung jarak haversine dalam meter
function haversine_distance($lat1, $lon1, $lat2, $lon2) {
    $earth_radius = 6371000; // meter
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);
    $a = sin($dLat/2) * sin($dLat/2) +
         cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
         sin($dLon/2) * sin($dLon/2);
    $c = 2 * atan2(sqrt($a), sqrt(1-$a));
    return $earth_radius * $c;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Absensi - Portal Instruktur BBPVP</title>
    <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .absensi-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 24px;
            align-items: start;
        }

        .absensi-grid.single {
            grid-template-columns: 1fr;
        }

        .card-panel {
            background: #ffffff;
            border: 1px solid #e5f0ed;
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 4px 12px rgba(5, 150, 105, 0.1);
        }

        .status-card {
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .status-card::after {
            content: none;
        }

        .status-icon {
            width: 88px;
            height: 88px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 40px;
            box-shadow: 0 6px 16px rgba(5, 150, 105, 0.15);
        }

        .status-icon.success {
            background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
            color: #065f46;
            border: 2px solid #a7f3d0;
        }

        .status-icon.pending {
            background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
            color: #0f766e;
            border: 2px solid #99f6e4;
        }

        .status-title {
            font-size: 26px;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 10px;
            text-align: center;
        }

        .status-description {
            font-size: 15px;
            color: #6b7280;
            margin-bottom: 20px;
            line-height: 1.7;
            text-align: center;
        }

        .inline-alert {
            border-radius: 14px;
            padding: 16px 18px;
            margin: 14px auto 0;
            font-size: 14px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
            justify-content: center;
            text-align: center;
        }

        .inline-alert.warning {
            background: #fef3c7;
            color: #92400e;
            border: 1px solid #fcd34d;
        }

        .inline-alert.danger {
            background: #fee2e2;
            color: #b91c1c;
            border: 1px solid #fecaca;
        }

        .status-meta {
            margin-top: 24px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
            gap: 14px;
            text-align: center;
            justify-items: center;
        }

        .status-meta .meta-card {
            background: #f9fafb;
            border-radius: 14px;
            padding: 16px;
            border: 1px dashed #d1d5db;
        }

        .status-meta .meta-label {
            font-size: 12px;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: #94a3b8;
            margin-bottom: 6px;
            display: block;
        }

        .status-meta .meta-value {
            font-size: 15px;
            color: #0f172a;
            font-weight: 600;
        }

        .form-card {
            position: relative;
        }

        .form-card h4 {
            font-size: 22px;
            margin-bottom: 8px;
            color: #0f172a;
        }

        .form-card p {
            color: #6b7280;
            font-size: 14px;
            margin-bottom: 26px;
        }

        .absensi-form .form-group {
            margin-bottom: 20px;
        }

        .absensi-form label {
            display: block;
            font-size: 13px;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: #475569;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .absensi-form select,
        .absensi-form textarea,
        .absensi-form input[type="file"] {
            width: 100%;
            border-radius: 14px;
            border: 1px solid #d1d5db;
            padding: 13px 15px;
            font-size: 15px;
            font-family: 'Inter', sans-serif;
            transition: all 0.2s ease;
            background: #fff;
            color: #111827;
        }

        .absensi-form textarea {
            min-height: 110px;
            resize: vertical;
        }

        .absensi-form select:focus,
        .absensi-form textarea:focus,
        .absensi-form input[type="file"]:focus {
            outline: none;
            border-color: #2563eb;
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.12);
        }

        .absensi-form small {
            display: block;
            margin-top: 8px;
            font-size: 12px;
            color: #94a3b8;
        }

        #lampiran-wrapper {
            display: none;
        }

        .btn-submit {
            width: 100%;
            padding: 14px 18px;
            border-radius: 14px;
            border: none;
            background: linear-gradient(135deg, #059669 0%, #0d9488 100%);
            color: #fff;
            font-size: 16px;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            box-shadow: 0 6px 16px rgba(5, 150, 105, 0.25);
        }

        .btn-submit:hover {
            transform: translateY(-1px);
        }

        .btn-submit:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            box-shadow: none;
        }

        .location-helper {
            margin-top: 12px;
            font-size: 13px;
            color: #6b7280;
            line-height: 1.6;
        }

        .location-helper strong {
            color: #111827;
        }

        .location-chip {
            margin-top: 12px;
            padding: 12px 14px;
            background: #f0f9ff;
            border-radius: 12px;
            font-size: 13px;
            color: #0369a1;
            border: 1px solid #bae6fd;
            text-align: center;
        }

        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 15px;
            animation: slideIn 0.3s ease;
        }

        .alert-success {
            background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);
            color: #065f46;
            border-left: 4px solid #10b981;
        }

        .alert-error {
            background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
            color: #7f1d1d;
            border-left: 4px solid #ef4444;
        }

        .alert-warning {
            background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
            color: #78350f;
            border-left: 4px solid #f59e0b;
        }

        .button-group {
            display: flex;
            gap: 12px;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 24px;
            padding: 0 20px;
        }

        .btn-secondary {
            padding: 12px 24px;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease;
            font-size: 14px;
            border: 2px solid #e5e7eb;
            background: white;
            color: #374151;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .btn-secondary:hover {
            border-color: #d1d5db;
            background: #f9fafb;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .btn-secondary.primary {
            background: linear-gradient(135deg, #0d9488 0%, #14b8a6 100%);
            color: white;
            border: none;
            box-shadow: 0 2px 8px rgba(13, 148, 136, 0.2);
        }

        .btn-secondary.primary:hover {
            box-shadow: 0 4px 12px rgba(13, 148, 136, 0.3);
            background: linear-gradient(135deg, #0d9488 0%, #0ea5a3 100%);
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (max-width: 1024px) {
            .absensi-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 640px) {
            .card-panel {
                padding: 24px;
            }

            .status-icon {
                width: 90px;
                height: 90px;
                font-size: 42px;
            }

            .button-group {
                padding: 0 10px;
            }

            .btn-secondary {
                flex: 1;
                min-width: 160px;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-logo">
            <img src="../assets/images/logo-bbpvp.png" alt="BBPVP Bekasi" class="logo-img">
            <div class="header-text">
                <h1>Instruktur Balai Besar Pelatihan Vokasi dan Produktivitas Bekasi</h1>
                <span>Kementerian Ketenagakerjaan Republik Indonesia</span>
            </div>
        </div>
        <div class="header-user">
            <span class="user-info">
                <iconify-icon icon="material-symbols:person-outline" style="margin-right: 6px;"></iconify-icon>
                <?= htmlspecialchars($instruktur_data['nama_instruktur'] ?? 'Instruktur') ?>
            </span>
            <a href="../logout.php" class="logout-btn">
                <iconify-icon icon="material-symbols:logout"></iconify-icon>
                Logout
            </a>    
        </div>
    </header>
    <div class="container">
        <?php include "../includes/instructor_sidebar.php"; ?>

        <div class="content">
            <div class="dashboard-container fade-in">
                <div class="dashboard-header">
                    <h2>
                        <iconify-icon icon="material-symbols:assignment-outline"></iconify-icon>
                        Absensi Harian
                    </h2>
                    <p class="dashboard-subtitle">
                        <span id="tanggal-display"><?= tgl_indonesia_header(date('Y-m-d'), $days, $months) ?></span>
                        <span id="waktu-display" style="margin-left: 12px; font-weight: 600; color: #059669;"><?= date('H:i:s') ?> WIB</span>
                    </p>
                </div>

                <?php if ($success_message): ?>
                    <div class="alert alert-success">
                        <iconify-icon icon="material-symbols:check-circle"></iconify-icon>
                        <?= htmlspecialchars($success_message) ?>
                    </div>
                <?php endif; ?>

                <?php if ($error_message): ?>
                    <div class="alert alert-error">
                        <iconify-icon icon="material-symbols:error"></iconify-icon>
                        <?= htmlspecialchars($error_message) ?>
                    </div>
                <?php endif; ?>

                <div class="content-card">
                    <div class="absensi-grid <?= $has_form ? '' : 'single' ?>">
                        <section class="card-panel status-card">
                            <?php if ($absen): ?>
                                <div class="status-icon success">
                                    <iconify-icon icon="material-symbols:check-circle"></iconify-icon>
                                </div>
                                <br><p class="status-title">Absensi Berhasil</p>
                                <p class="status-description">
                                    Anda tercatat dengan status <strong><?= htmlspecialchars($absen['status'] ?? '') ?></strong> untuk hari ini.
                                </p>
                                <?php 
                                    $keterangan = $absen['keterangan'] ?? $absen['alasan'] ?? '';
                                    $tanggal_absen = !empty($absen['tanggal']) ? tgl_indonesia_header($absen['tanggal'], $days, $months) : tgl_indonesia_header($tgl, $days, $months);
                                    $waktu_absen_display = !empty($absen['waktu_absen']) ? htmlspecialchars(date('H:i', strtotime($absen['waktu_absen']))) . ' WIB' : '-';
                                ?>
                                <div class="location-chip" style="margin-bottom: 16px; background: #f0f9ff; border-color: #bae6fd; color: #0369a1;">
                                    <strong>Tanggal:</strong> <?= $tanggal_absen ?><br>
                                    <strong>Waktu:</strong> <?= $waktu_absen_display ?>
                                </div>
                                <?php if ($keterangan !== ''): ?>
                                    <div class="location-chip">
                                        <strong>Keterangan:</strong> <?= htmlspecialchars($keterangan) ?>
                                    </div>
                                <?php endif; ?>
                                <div class="status-meta">
                                    <div class="meta-card">
                                        <span class="meta-label">Waktu Absen</span>
                                        <span class="meta-value"><?= $waktu_absen_display ?></span>
                                    </div>
                                    <div class="meta-card">
                                        <span class="meta-label">Validasi Lokasi</span>
                                        <span class="meta-value">
                                            <?php
                                                if ($absen['lokasi_valid'] === null) {
                                                    echo 'Tidak tersedia';
                                                } else {
                                                    echo $absen['lokasi_valid'] ? 'Dalam radius sekolah' : 'Di luar area';
                                                }
                                            ?>
                                        </span>
                                    </div>
                                    <div class="meta-card">
                                        <span class="meta-label">Jarak Titik Acuan</span>
                                        <span class="meta-value">
                                            <?= isset($absen['jarak_meter']) ? intval($absen['jarak_meter']) . ' m' : 'Tidak dihitung' ?>
                                        </span>
                                    </div>
                                </div>
                                <?php if (!empty($absen['latitude']) && !empty($absen['longitude'])): ?>
                                    <?php 
                                        $lat_show = number_format((float)$absen['latitude'], 6);
                                        $lng_show = number_format((float)$absen['longitude'], 6);
                                        $maps_url = 'https://www.google.com/maps?q=' . rawurlencode($absen['latitude'] . ',' . $absen['longitude']);
                                    ?>
                                    <div class="location-chip" style="margin-top:18px;">
                                        Koordinat: <?= $lat_show ?>, <?= $lng_show ?> —
                                        <a href="<?= $maps_url ?>" target="_blank" style="color:#2563eb; font-weight:600; text-decoration:none;">Lihat di Maps</a>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="status-icon pending">
                                    <iconify-icon icon="material-symbols:schedule"></iconify-icon>
                                </div>
                                 <p class="status-description">
                                    Belum Absen
                                </p>
                                <p class="status-description">
                                    Sinkronkan data kehadiran Anda melalui form di samping agar tercatat pada sistem BBPVP.
                                </p>
                                <?php if ($pending_pengajuan_today): ?>
                                    <div class="inline-alert warning">
                                        <iconify-icon icon="material-symbols:schedule"></iconify-icon>
                                        Pengajuan izin/sakit hari ini sedang menunggu persetujuan admin.
                                    </div>
                                <?php elseif (!$jadwal_id): ?>
                                    <div class="inline-alert danger">
                                        Tidak ada jadwal mengajar hari ini sehingga absensi tidak tersedia.
                                        <br> Hubungi admin untuk memastikan jadwal Anda, kemudian lakukan absensi kembali.
                                    </div>
                                <?php endif; ?>

                                <?php if ($jadwal_info): ?>
                                    <div class="status-meta" style="margin-top:26px;">
                                        <div class="meta-card">
                                            <span class="meta-label">Tanggal</span>
                                            <span class="meta-value"><?= htmlspecialchars(tgl_indonesia_header($tgl, $days, $months)) ?></span>
                                        </div>
                                        <?php if (!empty($jadwal_info['nama_kelas'])): ?>
                                            <div class="meta-card">
                                                <span class="meta-label">Kelas</span>
                                                <span class="meta-value"><?= htmlspecialchars($jadwal_info['nama_kelas']) ?></span>
                                            </div>
                                        <?php endif; ?>
                                        <?php if (!empty($jadwal_info['jam_mulai']) && !empty($jadwal_info['jam_selesai'])): ?>
                                            <div class="meta-card">
                                                <span class="meta-label">Waktu Mengajar</span>
                                                <span class="meta-value"><?= htmlspecialchars(substr($jadwal_info['jam_mulai'], 0, 5)) ?> - <?= htmlspecialchars(substr($jadwal_info['jam_selesai'], 0, 5)) ?> WIB</span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </section>

                        <?php if ($has_form): ?>
                            <section class="card-panel form-card">
                                <h4>Form Absensi</h4>
                                <p>Pilih status kehadiran, lengkapi keterangan bila diperlukan, dan aktifkan GPS untuk status Hadir.</p>
                                <form method="post" class="absensi-form" novalidate enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label for="status">Status Kehadiran</label>
                                        <select name="status" id="status" required>
                                            <option value="">-- Pilih Status --</option>
                                            <option value="Hadir">Hadir</option>
                                            <option value="Izin">Izin</option>
                                            <option value="Sakit">Sakit</option>
                                        </select>
                                        <small>Catatan: Status "Alfa" akan otomatis diberikan jika tidak melakukan absensi hingga pukul 18:00 WIB.</small>
                                    </div>

                                    <div class="form-group">
                                        <label for="alasan">Keterangan (Opsional)</label>
                                        <textarea 
                                            name="alasan" 
                                            id="alasan" 
                                            placeholder="Contoh: mengikuti rapat dinas / pendampingan ujian..."></textarea>
                                    </div>

                                    <div class="form-group" id="lokasi-wrapper">
                                        <label>Lokasi Kehadiran (GPS)</label>
                                        <button type="button" id="btn-lokasi" class="btn-secondary primary" style="width:auto; border:none; margin-bottom:12px;">
                                            <iconify-icon icon="material-symbols:my-location"></iconify-icon>
                                            Ambil Lokasi Sekarang
                                        </button>
                                        <div id="lokasi-info" class="location-helper">
                                            Untuk status <strong>Hadir</strong>, wajib aktifkan GPS dan tekan tombol ambil lokasi.
                                        </div>
                                        <input type="hidden" name="latitude" id="latitude">
                                        <input type="hidden" name="longitude" id="longitude">
                                    </div>

                                    <div class="form-group" id="lampiran-wrapper">
                                        <label for="lampiran">Lampiran (Opsional)</label>
                                        <input type="file" name="lampiran" id="lampiran" accept=".pdf,.jpg,.jpeg,.png">
                                        <small>Unggah bukti izin/sakit (maks. 5 MB).</small>
                                    </div>

                                    <button type="submit" class="btn-submit">
                                        <iconify-icon icon="material-symbols:save"></iconify-icon>
                                        Simpan Absensi
                                    </button>
                                </form>

                                <script>
                                (function(){
                                    var select = document.getElementById('status');
                                    var wrapLampiran = document.getElementById('lampiran-wrapper');
                                    if (!select || !wrapLampiran) return;

                                    function toggleLampiran(){
                                        var v = select.value;
                                        wrapLampiran.style.display = (v === 'Izin' || v === 'Sakit') ? 'block' : 'none';
                                    }
                                    select.addEventListener('change', toggleLampiran);
                                    toggleLampiran();

                                    var btnLokasi = document.getElementById('btn-lokasi');
                                    var latInput = document.getElementById('latitude');
                                    var lngInput = document.getElementById('longitude');
                                    var lokasiInfo = document.getElementById('lokasi-info');
                                    var submitBtn = document.querySelector('.absensi-form .btn-submit');

                                    function updateSubmitState() {
                                        if (!submitBtn) return;
                                        if (select.value === 'Hadir') {
                                            if (latInput.value && lngInput.value) {
                                                submitBtn.disabled = false;
                                            } else {
                                                submitBtn.disabled = true;
                                            }
                                        } else {
                                            submitBtn.disabled = false;
                                        }
                                    }

                                    if (btnLokasi) {
                                        btnLokasi.addEventListener('click', function () {
                                            if (!navigator.geolocation) {
                                                alert('Browser Anda tidak mendukung GPS/geolokasi.');
                                                return;
                                            }
                                            lokasiInfo.style.color = '#64748b';
                                            lokasiInfo.innerHTML = 'Mengambil lokasi, mohon tunggu...';
                                            navigator.geolocation.getCurrentPosition(function (pos) {
                                                var lat = pos.coords.latitude;
                                                var lng = pos.coords.longitude;
                                                latInput.value = lat;
                                                lngInput.value = lng;
                                                var mapsUrl = 'https://www.google.com/maps?q=' + lat + ',' + lng;
                                                lokasiInfo.style.color = '#059669';
                                                lokasiInfo.innerHTML = 'Lokasi tersimpan:<br>' +
                                                    'Lat: <strong>' + lat.toFixed(6) + '</strong>, ' +
                                                    'Lng: <strong>' + lng.toFixed(6) + '</strong><br>' +
                                                    '<a href="' + mapsUrl + '" target="_blank" style="color:#2563eb; text-decoration:none;">Lihat di Google Maps</a>';
                                                updateSubmitState();
                                            }, function (err) {
                                                lokasiInfo.style.color = '#b91c1c';
                                                lokasiInfo.innerHTML = 'Gagal mengambil lokasi: ' + err.message;
                                                latInput.value = '';
                                                lngInput.value = '';
                                                updateSubmitState();
                                            }, {
                                                enableHighAccuracy: true,
                                                timeout: 15000,
                                                maximumAge: 0
                                            });
                                        });
                                    }

                                    select.addEventListener('change', function () {
                                        if (select.value !== 'Hadir') {
                                            latInput.value = '';
                                            lngInput.value = '';
                                            lokasiInfo.style.color = '#6b7280';
                                            lokasiInfo.innerHTML = 'Untuk status <strong>Hadir</strong>, wajib aktifkan GPS dan tekan tombol ambil lokasi.';
                                        }
                                        updateSubmitState();
                                    });

                                    updateSubmitState();
                                })();
                                </script>
                            </section>
                        <?php endif; ?>
                    </div>
                    <?php if (!$absen): ?>
                        <?php if ($pending_pengajuan_today): ?>
                            <div class="alert alert-warning" style="margin-top:24px;">
                                <iconify-icon icon="material-symbols:hourglass-bottom"></iconify-icon>
                                Form dinonaktifkan sementara karena permohonan izin/sakit sedang diproses.
                            </div>
                        <?php elseif (!$jadwal_id): ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>

                <div class="button-group">
                    <a href="dashboard.php" class="btn-secondary">
                        <iconify-icon icon="material-symbols:arrow-back"></iconify-icon>
                        Kembali ke Dashboard
                    </a>
                    <a href="riwayat.php" class="btn-secondary primary">
                        <iconify-icon icon="material-symbols:history"></iconify-icon>
                        Lihat Riwayat Absensi
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- added footer -->
    <footer>
        <p>© <?= date("Y"); ?> Manajemen Penjadwalan BBPVP - All Rights Reserved</p>
    </footer>

    <script>
    // Update waktu real-time yang sinkron dengan waktu laptop
    function updateWaktu() {
        const now = new Date();
        const options = { 
            timeZone: 'Asia/Jakarta',
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        };
        
        const tanggalDisplay = document.getElementById('tanggal-display');
        const waktuDisplay = document.getElementById('waktu-display');
        
        if (tanggalDisplay && waktuDisplay) {
            // Format tanggal Indonesia
            const hari = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
            const bulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
            
            const hariNama = hari[now.getDay()];
            const tanggal = String(now.getDate()).padStart(2, '0');
            const bulanNama = bulan[now.getMonth()];
            const tahun = now.getFullYear();
            
            const jam = String(now.getHours()).padStart(2, '0');
            const menit = String(now.getMinutes()).padStart(2, '0');
            const detik = String(now.getSeconds()).padStart(2, '0');
            
            tanggalDisplay.textContent = `${hariNama}, ${tanggal} ${bulanNama} ${tahun}`;
            waktuDisplay.textContent = `${jam}:${menit}:${detik} WIB`;
        }
    }
    
    // Update setiap detik
    setInterval(updateWaktu, 1000);
    updateWaktu(); // Panggil sekali saat halaman dimuat
    </script>

</body>
</html>
