<?php
session_start();
include "../config/database.php";

// Check if user is logged in and is instructor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'instruktur') {
    header("Location: ../login.php");
    exit;
}

$instruktur_id = $_SESSION['instruktur_id'] ?? 0;

// Ambil data instruktur
$data = [];
if ($instruktur_id > 0) {
    $sql  = mysqli_query($conn, "SELECT * FROM instruktur WHERE instruktur_id='$instruktur_id'");
    $data = mysqli_fetch_assoc($sql) ?? [];
}

// Jika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_instruktur = mysqli_real_escape_string($conn, $_POST['nama'] ?? '');
    $email = mysqli_real_escape_string($conn, $_POST['email'] ?? '');
    $no_hp = mysqli_real_escape_string($conn, $_POST['telepon'] ?? '');

    if ($instruktur_id > 0) {
        $update = "UPDATE instruktur 
                   SET nama_instruktur='$nama_instruktur', email='$email', no_hp='$no_hp' 
                   WHERE instruktur_id='$instruktur_id'";
        mysqli_query($conn, $update);
    }

    header("Location: profil.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya - Portal Instruktur BBPVP</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="header-logo">
            <img src="../assets/images/logo-bbpvp.png" alt="BBPVP Bekasi" class="logo-img">
            <div class="header-text">
                <h1>Instruktur Balai Besar Pelatihan Vokasi dan Produktivitas Bekasi</h1>
                <span>Kementerian Ketenagakerjaan Republik Indonesia</span>
            </div>
        </div>
        <div class="header-user">
            <span class="user-info">
                <iconify-icon icon="material-symbols:person-outline" style="margin-right: 6px;"></iconify-icon>
                <?= htmlspecialchars($data['nama_instruktur'] ?? 'Instruktur') ?>
            </span>
            <a href="/Aplikasi%20Manajemen%20Penjadwalan%20Instruktur/logout.php" class="logout-btn">
                <iconify-icon icon="material-symbols:logout"></iconify-icon>
                Logout
            </a>
        </div>
    </header>
    <div class="container">
        <?php include "../includes/instructor_sidebar.php"; ?>

        <div class="content">
            <div class="dashboard-container fade-in">
                <div class="dashboard-header">
                    <h2>
                        <iconify-icon icon="material-symbols:person-outline"></iconify-icon>
                        Profil Saya
                    </h2>
                    <p class="dashboard-subtitle">Kelola informasi profil instruktur Anda</p>
                </div>

                <?php if (!empty($data)) : ?>
                    <div class="content-card">
                        <div style="text-align: center; margin-bottom: 30px;">
                            <div style="width: 120px; height: 120px; border-radius: 50%; background: linear-gradient(135deg, #667eea, #764ba2); color: white; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; font-size: 40px; font-weight: 800; box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);">
                                <?= strtoupper(substr($data['nama_instruktur'] ?? 'U', 0, 1)) ?>
                            </div>
                            
                            <div style="display: flex; gap: 12px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap;">
                                <button type="button" onclick="copyEmail('<?= htmlspecialchars($data['email'] ?? '') ?>')" style="background: #f8fafc; color: #0f172a; border: 2px solid #e2e8f0; border-radius: 12px; padding: 12px 16px; font-weight: 600; font-size: 15px; cursor: pointer; transition: all .2s ease; display: flex; align-items: center; gap: 8px;">
                                    <iconify-icon icon="material-symbols:content-copy-outline"></iconify-icon>
                                    Salin Email
                                </button>
                                <a href="ubah_password.php" style="background: #f8fafc; color: #0f172a; border: 2px solid #e2e8f0; border-radius: 12px; padding: 12px 16px; font-weight: 600; font-size: 15px; text-decoration: none; display: flex; align-items: center; gap: 8px; transition: all .2s ease;">
                                    <iconify-icon icon="material-symbols:lock-outline"></iconify-icon>
                                    Ubah Password
                                </a>
                            </div>
                        </div>

                        <form method="post" novalidate class="form-card">
                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="nama">Nama Lengkap</label>
                                    <input type="text" id="nama" name="nama" class="form-control" value="<?= htmlspecialchars($data['nama_instruktur'] ?? '') ?>" required aria-required="true" placeholder="Masukkan nama lengkap">
                                </div>

                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" id="email" name="email" class="form-control" value="<?= htmlspecialchars($data['email'] ?? '') ?>" required aria-required="true" placeholder="Masukkan alamat email">
                                </div>

                                <div class="form-group">
                                    <label for="telepon">No. Telepon</label>
                                    <input type="text" id="telepon" name="telepon" class="form-control" value="<?= htmlspecialchars($data['no_hp'] ?? '') ?>" required aria-required="true" placeholder="Masukkan nomor telepon">
                                </div>

                                <div class="form-actions">
                                    <button type="submit" class="btn btn-primary">
                                        <iconify-icon icon="material-symbols:save"></iconify-icon>
                                        Simpan Perubahan
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                <?php else : ?>
                    <div class="content-card">
                        <div style="background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; border-radius: 12px; padding: 20px; font-weight: 600; text-align: center; font-size: 16px;">
                            <strong>Data Tidak Ditemukan.</strong> Pastikan Anda sudah login dengan benar.
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- added footer -->
    <footer>
        <p>© <?= date("Y"); ?> Manajemen Penjadwalan BBPVP - All Rights Reserved</p>
    </footer>

    <script>
        function copyEmail(email) {
            if (navigator.clipboard) {
                navigator.clipboard.writeText(email);
                const btn = event.target.closest('button');
                const original = btn.innerHTML;
                btn.innerHTML = '<iconify-icon icon="material-symbols:check"></iconify-icon> Tersalin!';
                setTimeout(() => btn.innerHTML = original, 1500);
            }
        }
    </script>
</body>
</html>
