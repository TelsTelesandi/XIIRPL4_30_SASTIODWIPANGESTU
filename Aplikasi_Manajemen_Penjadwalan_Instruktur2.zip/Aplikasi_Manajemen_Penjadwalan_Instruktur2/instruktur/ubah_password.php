<?php
session_start();
include "../config/database.php";

// Check if user is logged in and is instructor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'instruktur') {
    header("Location: ../login.php");
    exit;
}

$instruktur_id = $_SESSION['instruktur_id'] ?? 0;

// Get instructor data
$instruktur_query = mysqli_query($conn, "SELECT * FROM instruktur WHERE instruktur_id = '$instruktur_id'");
$instruktur_data = mysqli_fetch_assoc($instruktur_query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ubah Password - Portal Instruktur BBPVP</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="header-logo">
            <img src="../assets/images/logo-bbpvp.png" alt="BBPVP Bekasi" class="logo-img">
            <div class="header-text">
                <h1>Instruktur Balai Besar Pelatihan Vokasi dan Produktivitas Bekasi</h1>
                <span>Kementerian Ketenagakerjaan Republik Indonesia</span>
            </div>
        </div>
        <div class="header-user">
            <span class="user-info">
                <iconify-icon icon="material-symbols:person-outline" style="margin-right: 6px;"></iconify-icon>
                <?= htmlspecialchars($instruktur_data['nama_instruktur'] ?? 'Instruktur') ?>
            </span>
            <a href="/Aplikasi_Manajemen_Penjadwalan_Instruktur/home.php" class="logout-btn">
                <iconify-icon icon="material-symbols:logout"></iconify-icon>
                Logout
            </a>
        </div>
    </header>
    <div class="container">
        <?php include "../includes/instructor_sidebar.php"; ?>

        <div class="content">
            <div class="dashboard-container fade-in">
                <div class="dashboard-header">
                    <h2>
                        <iconify-icon icon="material-symbols:lock-outline"></iconify-icon>
                        Ubah Password
                    </h2>
                    <p class="dashboard-subtitle">Keamanan akun Anda adalah prioritas kami</p>
                </div>

                <div style="text-align: center; margin-bottom: 20px;">
                    <button id="gen-pass" type="button" style="background: #f8fafc; color: #0f172a; border: 2px solid #e2e8f0; border-radius: 12px; padding: 12px 16px; font-weight: 600; font-size: 15px; cursor: pointer; transition: all .2s ease; display: inline-flex; align-items: center; gap: 8px;">
                        <iconify-icon icon="material-symbols:bolt-outline"></iconify-icon>
                        Buat Password Kuat
                    </button>
                </div>

                <?php
                $msg = "";
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $pass_lama = $_POST['password_lama'] ?? '';
                    $pass_baru = $_POST['password_baru'] ?? '';
                    $konfirmasi = $_POST['konfirmasi'] ?? '';

                    // Ambil hash password instruktur secara aman
                    $stmt = mysqli_prepare($conn, "SELECT password FROM instruktur WHERE instruktur_id = ?");
                    mysqli_stmt_bind_param($stmt, "i", $instruktur_id);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);
                    $data = mysqli_fetch_assoc($result);

                    if ($data && password_verify($pass_lama, $data['password'])) {
                        if ($pass_baru === $konfirmasi) {
                            $hash = password_hash($pass_baru, PASSWORD_DEFAULT);
                            $upd = mysqli_prepare($conn, "UPDATE instruktur SET password = ? WHERE instruktur_id = ?");
                            mysqli_stmt_bind_param($upd, "si", $hash, $instruktur_id);
                            mysqli_stmt_execute($upd);

                            $msg = "<div style='background: #ecfdf5; color: #047857; border: 1px solid #10b981; border-radius: 12px; padding: 20px; font-weight: 600; margin-bottom: 20px;'>✅ Password berhasil diubah.</div>";
                        } else {
                            $msg = "<div style='background: #fffbeb; color: #92400e; border: 1px solid #f59e0b; border-radius: 12px; padding: 20px; font-weight: 600; margin-bottom: 20px;'>❌ Konfirmasi password tidak cocok.</div>";
                        }
                    } else {
                        $msg = "<div style='background: #fef2f2; color: #991b1b; border: 1px solid #ef4444; border-radius: 12px; padding: 20px; font-weight: 600; margin-bottom: 20px;'>❌ Password lama salah.</div>";
                    }
                }
                ?>

                <?php if (!empty($msg)): ?>
                    <?= $msg ?>
                <?php endif; ?>

                <div class="content-card">
                    <form id="form-password" method="post" autocomplete="off" class="form-card">
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="password_lama">Password Lama</label>
                                <div style="position: relative;">
                                    <input type="password" id="password_lama" name="password_lama" class="form-control" required aria-required="true">
                                    <button type="button" class="toggle" data-target="password_lama" style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%); background: transparent; border: none; color: #0d9488; font-weight: 600; cursor: pointer; padding: 8px 10px; border-radius: 8px;">Tampil</button>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="password_baru">Password Baru</label>
                                <div style="position: relative;">
                                    <input type="password" id="password_baru" name="password_baru" class="form-control" required aria-required="true" minlength="8">
                                    <button type="button" class="toggle" data-target="password_baru" style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%); background: transparent; border: none; color: #0d9488; font-weight: 600; cursor: pointer; padding: 8px 10px; border-radius: 8px;">Tampil</button>
                                </div>
                                <div style="height: 10px; border-radius: 9999px; background: #f3f4f6; overflow: hidden; margin-top: 8px;" aria-hidden="true">
                                    <span id="strength-bar" style="display: block; height: 100%; width: 0%; transition: width 200ms ease; background: #0d9488;"></span>
                                </div>
                                <small id="strength-text" style="color: #6b7280; font-size: 14px; margin-top: 6px; display: block;">Minimal 8 karakter, gunakan kombinasi huruf, angka, dan simbol.</small>
                            </div>

                            <div class="form-group">
                                <label for="konfirmasi">Konfirmasi Password Baru</label>
                                <div style="position: relative;">
                                    <input type="password" id="konfirmasi" name="konfirmasi" class="form-control" required aria-required="true">
                                    <button type="button" class="toggle" data-target="konfirmasi" style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%); background: transparent; border: none; color: #0d9488; font-weight: 600; cursor: pointer; padding: 8px 10px; border-radius: 8px;">Tampil</button>
                                </div>
                                <small id="match-text" style="color: #6b7280; font-size: 14px; margin-top: 6px; display: block;"></small>
                            </div>

                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">
                                    <iconify-icon icon="material-symbols:save-outline"></iconify-icon>
                                    Simpan
                                </button>
                                <a href="dashboard.php" class="btn btn-secondary">
                                    <iconify-icon icon="material-symbols:arrow-back"></iconify-icon>
                                    Kembali
                                </a>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="content-card" style="margin-top: 20px;">
                    <h3 style="margin: 0 0 10px 0; font-size: 18px; color: #0f172a; font-weight: 800;">Tips Keamanan</h3>
                    <ul style="margin: 0; padding-left: 18px; color: #64748b; font-size: 15px; display: grid; gap: 8px;">
                        <li>Gunakan kombinasi huruf besar, huruf kecil, angka, dan simbol.</li>
                        <li>Hindari kata kamus, tanggal lahir, atau informasi mudah ditebak.</li>
                        <li>Jangan gunakan password yang sama di banyak akun.</li>
                        <li>Perbarui password Anda secara berkala.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <p>© <?= date("Y"); ?> Manajemen Penjadwalan BBPVP - All Rights Reserved</p>
    </footer>

    <script>
    (function () {
        const toggles = document.querySelectorAll('.toggle');
        toggles.forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.getAttribute('data-target');
                const input = document.getElementById(id);
                if (!input) return;
                input.type = input.type === 'password' ? 'text' : 'password';
                btn.textContent = input.type === 'password' ? 'Tampil' : 'Sembunyi';
            });
        });

        const pwd = document.getElementById('password_baru');
        const bar = document.getElementById('strength-bar');
        const label = document.getElementById('strength-text');
        const confirm = document.getElementById('konfirmasi');
        const matchText = document.getElementById('match-text');

        function scorePassword(v) {
            let score = 0;
            if (!v) return 0;
            if (v.length >= 8) score += 25;
            if (v.length >= 12) score += 10;
            if (/[a-z]/.test(v)) score += 15;
            if (/[A-Z]/.test(v)) score += 15;
            if (/[0-9]/.test(v)) score += 15;
            if (/[^A-Za-z0-9]/.test(v)) score += 20;
            return Math.min(score, 100);
        }

        function updateStrength() {
            const v = pwd.value || '';
            const s = scorePassword(v);
            bar.style.width = s + '%';
            let text = 'Lemah';
            if (s >= 70) { text = 'Kuat'; }
            else if (s >= 40) { text = 'Sedang'; }
            bar.style.background = '#667eea';
            label.textContent = `Kekuatan password: ${text}`;
        }

        function updateMatch() {
            if (!confirm.value) { matchText.textContent = ''; return; }
            if (confirm.value === pwd.value) {
                matchText.style.color = '#667eea';
                matchText.textContent = 'Konfirmasi cocok.';
            } else {
                matchText.style.color = '#64748b';
                matchText.textContent = 'Konfirmasi tidak cocok.';
            }
        }

        pwd.addEventListener('input', () => { updateStrength(); updateMatch(); });
        confirm.addEventListener('input', updateMatch);

        document.getElementById('form-password')?.addEventListener('submit', (e) => {
            if (confirm.value !== pwd.value) {
                e.preventDefault();
                updateMatch();
                confirm.focus();
            }
        });

        const genBtn = document.getElementById('gen-pass');
        if (genBtn) {
            genBtn.addEventListener('click', () => {
                function rand(n){return Math.random().toString(36).slice(2,2+n);}
                const strong = 
                    rand(3).toUpperCase() + rand(3) + 
                    Math.floor(100 + Math.random()*900) + 
                    '!@#'[Math.floor(Math.random()*3)] + 
                    rand(6) + 'A';
                const p1 = document.getElementById('password_baru');
                const p2 = document.getElementById('konfirmasi');
                if (p1 && p2) {
                    p1.value = strong;
                    p2.value = strong;
                    p1.dispatchEvent(new Event('input', { bubbles: true }));
                    p2.dispatchEvent(new Event('input', { bubbles: true }));
                }
                genBtn.textContent = 'Password Dibuat!';
                setTimeout(()=> genBtn.textContent = 'Buat Password Kuat', 1500);
            });
        }

        updateStrength();
    })();
    </script>
</body>
</html>
 
