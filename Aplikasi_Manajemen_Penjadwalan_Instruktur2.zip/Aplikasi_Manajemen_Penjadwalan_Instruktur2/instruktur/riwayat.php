<?php
session_start();
include "../config/database.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'instruktur') {
    header("Location: ../login.php");
    exit;
}

$instruktur_id = $_SESSION['instruktur_id'] ?? 0;

$instruktur_query = mysqli_query($conn, "SELECT * FROM instruktur WHERE instruktur_id = '$instruktur_id'");
$instruktur_data = mysqli_fetch_assoc($instruktur_query);

// Backfill 'Alfa' for missed attendance starting from policy activation date (today)
try {
    $today_r = date('Y-m-d');
    $end_range = date('Y-m-d', strtotime('-1 day', strtotime($today_r)));
    // policy activation: only start counting from today
    $policy_start = date('Y-m-d');
    $start_range = null;

    if ($stmtMin = mysqli_prepare($conn, "SELECT MIN(tanggal) AS min_tgl FROM jadwal WHERE instruktur_id = ?")) {
        mysqli_stmt_bind_param($stmtMin, "i", $instruktur_id);
        mysqli_stmt_execute($stmtMin);
        $resMin = mysqli_stmt_get_result($stmtMin);
        $rowMin = mysqli_fetch_assoc($resMin);
        $start_range = $rowMin['min_tgl'] ?? null;
        mysqli_stmt_close($stmtMin);
    }

    // enforce policy start
    if ($start_range) {
        $start_range = max($start_range, $policy_start);
    }

    if ($start_range && $start_range <= $end_range && ($stmt = mysqli_prepare($conn, "
        SELECT j.jadwal_id, j.tanggal
        FROM jadwal j
        LEFT JOIN absensi a
            ON a.instruktur_id = j.instruktur_id AND a.tanggal = j.tanggal
        LEFT JOIN pengajuan_izin p
            ON p.instruktur_id = j.instruktur_id AND p.tanggal = j.tanggal AND p.status = 'Disetujui'
        WHERE j.instruktur_id = ?
          AND j.tanggal BETWEEN ? AND ?
          AND a.absensi_id IS NULL
          AND p.pengajuan_id IS NULL
        ORDER BY j.tanggal ASC
    "))) {
        mysqli_stmt_bind_param($stmt, "iss", $instruktur_id, $start_range, $end_range);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        while ($row = mysqli_fetch_assoc($res)) {
            $tgl_row = $row['tanggal'];
            $days_map = [
                'Sunday' => 'Minggu','Monday' => 'Senin','Tuesday' => 'Selasa','Wednesday' => 'Rabu','Thursday' => 'Kamis','Friday' => 'Jumat','Saturday' => 'Sabtu'
            ];
            $hari_row = $days_map[date('l', strtotime($tgl_row))] ?? date('l', strtotime($tgl_row));
            if ($ins = mysqli_prepare($conn, "INSERT INTO absensi (jadwal_id, instruktur_id, tanggal, hari, status, alasan, waktu_absen) VALUES (?, ?, ?, ?, 'Alfa', NULL, '00:00:00')")) {
                mysqli_stmt_bind_param($ins, "iiss", $row['jadwal_id'], $instruktur_id, $tgl_row, $hari_row);
                mysqli_stmt_execute($ins);
                mysqli_stmt_close($ins);
            }
        }
        mysqli_stmt_close($stmt);
    }
} catch (Throwable $e) {
    // ignore
}

$month_filter = isset($_GET['month']) ? $_GET['month'] : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';

$where_conditions = ["instruktur_id = '$instruktur_id'"];
if ($month_filter) {
    $where_conditions[] = "DATE_FORMAT(tanggal, '%Y-%m') = '" . mysqli_real_escape_string($conn, $month_filter) . "'";
}
if ($status_filter) {
    $where_conditions[] = "status = '" . mysqli_real_escape_string($conn, $status_filter) . "'";
}
$where_clause = implode(' AND ', $where_conditions);

$sql = "SELECT * FROM absensi WHERE $where_clause ORDER BY tanggal DESC";
$result = mysqli_query($conn, $sql);

$months_query = "SELECT DISTINCT DATE_FORMAT(tanggal, '%Y-%m') as month_year, 
                        DATE_FORMAT(tanggal, '%M %Y') as month_name 
                 FROM absensi 
                 WHERE instruktur_id = '$instruktur_id' 
                 ORDER BY month_year DESC";
$months_result = mysqli_query($conn, $months_query);

$stats_query = "SELECT 
                    COUNT(*) as total,
                    SUM(status='Hadir') as hadir,
                    SUM(status='Izin') as izin,
                    SUM(status='Sakit') as sakit,
                    SUM(status='Alfa') as alfa
                FROM absensi 
                WHERE instruktur_id = '$instruktur_id'";
$stats_result = mysqli_query($conn, $stats_query);
$stats = mysqli_fetch_assoc($stats_result);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Absensi - Portal Instruktur BBPVP</title>
    <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header>
        <div class="header-logo">
            <img src="../assets/images/logo-bbpvp.png" alt="BBPVP Bekasi" class="logo-img">
            <div class="header-text">
                <h1>Instruktur Balai Besar Pelatihan Vokasi dan Produktvitas Bekasi</h1>
                <span>Kementerian Ketenagakerjaan Republik Indonesi</span>
            </div>
        </div>
        <div class="header-user">
            <span class="user-info">
                <iconify-icon icon="material-symbols:person-outline" style="margin-right: 6px;"></iconify-icon>
                <?= htmlspecialchars($instruktur_data['nama_instruktur'] ?? 'Instruktur') ?>
            </span>
            <a href="../logout.php" class="logout-btn">
                <iconify-icon icon="material-symbols:logout"></iconify-icon>
                Logout
            </a>
        </div>
    </header>
    <div class="container">
        <?php include "../includes/instructor_sidebar.php"; ?>

        <div class="content">
            <div class="dashboard-container fade-in">
                <div class="dashboard-header">
                    <h2>
                        <iconify-icon icon="material-symbols:history"></iconify-icon>
                        Riwayat Absensi
                    </h2>
                    <p class="dashboard-subtitle">Lihat semua catatan kehadiran Anda</p>
                </div>

                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-number"><?= (int)($stats['total'] ?? 0) ?></div>
                        <div class="stat-label">Total Hari</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?= (int)($stats['hadir'] ?? 0) ?></div>
                        <div class="stat-label">Hadir</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?= (int)($stats['izin'] ?? 0) ?></div>
                        <div class="stat-label">Izin</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?= (int)($stats['sakit'] ?? 0) ?></div>
                        <div class="stat-label">Sakit</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?= (int)($stats['alfa'] ?? 0) ?></div>
                        <div class="stat-label">Alfa</div>
                    </div>
                </div>

                <div class="content-card form-card">
                    <h3>
                        <iconify-icon icon="material-symbols:filter-list"></iconify-icon>
                        Filter Data
                    </h3>
                    <form method="GET" style="display: flex; gap: 16px; align-items: end; flex-wrap: wrap; margin-top: 12px;">
                        <div class="form-group" style="min-width: 200px;">
                            <label>Bulan</label>
                            <select name="month" class="form-control">
                                <option value="">Semua Bulan</option>
                                <?php while ($month = mysqli_fetch_assoc($months_result)): ?>
                                    <option value="<?= $month['month_year'] ?>" <?= $month_filter == $month['month_year'] ? 'selected' : '' ?>>
                                        <?= $month['month_name'] ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="form-group" style="min-width: 200px;">
                            <label>Status</label>
                            <select name="status" class="form-control">
                                <option value="">Semua Status</option>
                                <option value="Hadir" <?= $status_filter == 'Hadir' ? 'selected' : '' ?>>Hadir</option>
                                <option value="Izin" <?= $status_filter == 'Izin' ? 'selected' : '' ?>>Izin</option>
                                <option value="Sakit" <?= $status_filter == 'Sakit' ? 'selected' : '' ?>>Sakit</option>
                                <option value="Alfa" <?= $status_filter == 'Alfa' ? 'selected' : '' ?>>Alfa</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <iconify-icon icon="material-symbols:search"></iconify-icon>
                            Terapkan
                        </button>
                        <a href="riwayat.php" class="btn btn-secondary">
                            <iconify-icon icon="material-symbols:clear"></iconify-icon>
                            Reset
                        </a>
                    </form>
                </div>

                <div class="content-card">
                    <h3>
                        <iconify-icon icon="material-symbols:table-chart"></iconify-icon>
                        Data Absensi
                    </h3>
                    <?php if ($result && mysqli_num_rows($result) > 0): ?>
                        <table class="modern-table">
                            <thead>
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Hari</th>
                                    <th>Status</th>
                                    <th>Keterangan</th>
                                    <th>Waktu</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                    <?php
                                    $date = new DateTime($row['tanggal']);
                                    $day_names = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
                                    $day_name = $day_names[$date->format('w')];
                                    $status_colors = [
                                        'Hadir' => 'background: #d1fae5; color: #047857;',
                                        'Izin' => 'background: #fef3c7; color: #92400e;',
                                        'Sakit' => 'background: #dbeafe; color: #1d4ed8;',
                                        'Alfa' => 'background: #fee2e2; color: #dc2626;'
                                    ];
                                    $icons = [
                                        'Hadir' => 'material-symbols:check-circle',
                                        'Izin' => 'material-symbols:info',
                                        'Sakit' => 'material-symbols:local-hospital',
                                        'Alfa' => 'material-symbols:cancel'
                                    ];
                                    ?>
                                    <tr>
                                        <td style="font-weight: 600; color: #1f2937;"><?= $date->format('d/m/Y') ?></td>
                                        <td><?= $day_name ?></td>
                                        <td>
                                            <span style="padding: 6px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; display: inline-flex; align-items: center; gap: 4px; <?= $status_colors[$row['status']] ?? '' ?>">
                                                <iconify-icon icon="<?= $icons[$row['status']] ?? 'material-symbols:help' ?>"></iconify-icon>
                                                <?= htmlspecialchars($row['status']) ?>
                                            </span>
                                        </td>
                                        <td style="max-width: 260px; color: #6b7280; font-style: italic;">
                                            <?= !empty($row['alasan']) ? htmlspecialchars($row['alasan']) : '-' ?>
                                        </td>
                                        <td>
                                            <?= isset($row['waktu_absen']) ? date('H:i', strtotime($row['waktu_absen'])) : '-' ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div style="text-align: center; padding: 60px 20px; color: #6b7280;">
                            <div style="font-size: 64px; margin-bottom: 16px; opacity: 0.5;">
                                <iconify-icon icon="material-symbols:event-busy"></iconify-icon>
                            </div>
                            <div class="empty-title">Tidak Ada Data</div>
                            <div>Tidak ada data absensi yang sesuai dengan filter yang dipilih</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- added footer -->
    <footer>
        <p>© <?= date("Y"); ?> Manajemen Penjadwalan BBPVP - All Rights Reserved</p>
    </footer>
</body>
</html>
