<?php
session_start();
include "../../config/database.php";

// Check if user is logged in and is instructor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'instruktur') {
    header("Location: ../../login.php");
    exit;
}

$instruktur_id = $_SESSION['instruktur_id'] ?? 0;

$materi_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$materi_id) {
    header("Location: index.php?error=invalid_id");
    exit;
}

// Get materi data first to verify ownership
$materi_query = mysqli_query($conn, "SELECT * FROM materi WHERE materi_id = '$materi_id' AND instruktur_id = '$instruktur_id'");
$materi_data = mysqli_fetch_assoc($materi_query);

if (!$materi_data) {
    header("Location: index.php?error=not_found");
    exit;
}

// Delete file from server
$file_path = "../../uploads/materi/" . $materi_data['file'];
if (file_exists($file_path)) {
    unlink($file_path);
}

// Delete from database
$delete_query = mysqli_query($conn, "DELETE FROM materi WHERE materi_id = '$materi_id' AND instruktur_id = '$instruktur_id'");

if ($delete_query) {
    header("Location: index.php?success=deleted");
} else {
    header("Location: index.php?error=delete_failed");
}
exit;
