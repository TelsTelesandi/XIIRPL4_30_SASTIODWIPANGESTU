<?php
// Debug file untuk melihat masalah download
session_start();
include "../../config/database.php";

echo "<h1>Debug Download Materi</h1>";

// Check session
echo "<h2>Session Check:</h2>";
echo "<p>User ID: " . ($_SESSION['user_id'] ?? 'NOT SET') . "</p>";
echo "<p>Role: " . ($_SESSION['role'] ?? 'NOT SET') . "</p>";
echo "<p>Instruktur ID: " . ($_SESSION['instruktur_id'] ?? 'NOT SET') . "</p>";

// Check database connection
echo "<h2>Database Check:</h2>";
if ($conn) {
    echo "<p style='color: green;'>✓ Database connected</p>";
} else {
    echo "<p style='color: red;'>✗ Database connection failed</p>";
}

// Check materi table
echo "<h2>Materi Table Check:</h2>";
$result = mysqli_query($conn, "SELECT * FROM materi LIMIT 5");
if ($result) {
    echo "<p style='color: green;'>✓ Materi table accessible</p>";
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>materi_id</th><th>instruktur_id</th><th>judul_materi</th><th>file</th><th>uploaded_at</th></tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . ($row['materi_id'] ?? 'NULL') . "</td>";
        echo "<td>" . ($row['instruktur_id'] ?? 'NULL') . "</td>";
        echo "<td>" . ($row['judul_materi'] ?? $row['judul'] ?? 'NULL') . "</td>";
        echo "<td>" . ($row['file'] ?? 'NULL') . "</td>";
        echo "<td>" . ($row['uploaded_at'] ?? 'NULL') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>✗ Cannot access materi table: " . mysqli_error($conn) . "</p>";
}

// Check upload directory
echo "<h2>Upload Directory Check:</h2>";
$upload_dir = "../../uploads/materi/";
if (is_dir($upload_dir)) {
    echo "<p style='color: green;'>✓ Upload directory exists</p>";
    $files = scandir($upload_dir);
    echo "<p>Files in upload directory:</p>";
    echo "<ul>";
    foreach ($files as $file) {
        if ($file != '.' && $file != '..') {
            echo "<li>$file</li>";
        }
    }
    echo "</ul>";
} else {
    echo "<p style='color: red;'>✗ Upload directory not found</p>";
}

// Test download link
echo "<h2>Test Download Links:</h2>";
$materi_result = mysqli_query($conn, "SELECT materi_id, judul_materi, file FROM materi LIMIT 3");
if ($materi_result && mysqli_num_rows($materi_result) > 0) {
    while ($materi = mysqli_fetch_assoc($materi_result)) {
        $download_url = "download.php?id=" . $materi['materi_id'];
        echo "<p><a href='$download_url'>Download: " . ($materi['judul_materi'] ?? $materi['judul'] ?? 'Unknown') . "</a></p>";
    }
} else {
    echo "<p style='color: red;'>No materi found for testing</p>";
}

echo "<h2>System Info:</h2>";
echo "<p>PHP Version: " . phpversion() . "</p>";
echo "<p>Current Directory: " . getcwd() . "</p>";
echo "<p>Script Path: " . __FILE__ . "</p>";
?>
