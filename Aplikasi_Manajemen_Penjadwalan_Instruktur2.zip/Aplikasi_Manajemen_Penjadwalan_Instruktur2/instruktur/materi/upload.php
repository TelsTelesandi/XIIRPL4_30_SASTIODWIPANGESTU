<?php
session_start();
include "../../config/database.php";

// Check if user is logged in and is instructor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'instruktur') {
    header("Location: ../../login.php");
    exit;
}

$instruktur_id = $_SESSION['instruktur_id'] ?? 0;

// Get instructor data
$instruktur_query = mysqli_query($conn, "SELECT * FROM instruktur WHERE instruktur_id = '$instruktur_id'");
$instruktur_data = mysqli_fetch_assoc($instruktur_query);

// Get all classes for dropdown
$kelas_query = mysqli_query($conn, "SELECT kelas_id, nama_kelas FROM kelas ORDER BY nama_kelas ASC");
$kelas_list = [];
while($kelas = mysqli_fetch_assoc($kelas_query)) {
    $kelas_list[] = $kelas;
}

$response = ['success' => false, 'message' => '', 'redirect' => ''];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $judul = isset($_POST['judul']) ? trim(mysqli_real_escape_string($conn, $_POST['judul'])) : '';
    $deskripsi = isset($_POST['deskripsi']) ? trim(mysqli_real_escape_string($conn, $_POST['deskripsi'])) : '';
    $kelas_id = isset($_POST['kelas_id']) ? (int)$_POST['kelas_id'] : 0;

    // Validasi input
    if (empty($judul)) {
        $response['message'] = 'Judul materi tidak boleh kosong!';
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

    if ($kelas_id <= 0) {
        $response['message'] = 'Silakan pilih kelas terlebih dahulu!';
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

    $verify_kelas = mysqli_query($conn, "SELECT kelas_id FROM kelas WHERE kelas_id = '$kelas_id'");
    if (mysqli_num_rows($verify_kelas) == 0) {
        $response['message'] = 'Kelas tidak valid!';
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

    // File upload validation
    $file = $_FILES['file']['name'] ?? '';
    $tmp_name = $_FILES['file']['tmp_name'] ?? '';
    $file_size = $_FILES['file']['size'] ?? 0;
    $file_error = $_FILES['file']['error'] ?? UPLOAD_ERR_NO_FILE;

    if ($file_error !== UPLOAD_ERR_OK) {
        $error_messages = [
            UPLOAD_ERR_INI_SIZE => 'File terlalu besar (melebihi batas server)',
            UPLOAD_ERR_FORM_SIZE => 'File terlalu besar (melebihi batas form)',
            UPLOAD_ERR_PARTIAL => 'File hanya terupload sebagian',
            UPLOAD_ERR_NO_FILE => 'Silakan pilih file yang ingin diupload',
            UPLOAD_ERR_NO_TMP_DIR => 'Folder temporary tidak tersedia',
            UPLOAD_ERR_CANT_WRITE => 'Gagal menulis file ke disk',
            UPLOAD_ERR_EXTENSION => 'Upload dibatalkan oleh extension'
        ];
        $response['message'] = $error_messages[$file_error] ?? 'Terjadi kesalahan saat upload file';
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

    if (empty($file)) {
        $response['message'] = 'Silakan pilih file yang ingin diupload!';
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

    $max_size = 10 * 1024 * 1024;
    if ($file_size > $max_size) {
        $response['message'] = 'Ukuran file terlalu besar. Maksimal 10MB.';
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

    $allowed_ext = ['pdf', 'doc', 'docx', 'ppt', 'pptx'];
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    
    if (!in_array($ext, $allowed_ext)) {
        $response['message'] = 'Format file tidak didukung. Gunakan: PDF, DOC, DOCX, PPT, PPTX';
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

    $dir = "../../uploads/materi/";
    if (!is_dir($dir)) {
        if (!mkdir($dir, 0777, true)) {
            $response['message'] = 'Gagal membuat folder upload. Hubungi administrator.';
            header('Content-Type: application/json');
            echo json_encode($response);
            exit;
        }
    }

    $nama_baru = time() . "_" . rand(100000, 999999) . "." . $ext;
    $file_path = $dir . $nama_baru;

    if (!move_uploaded_file($tmp_name, $file_path)) {
        $response['message'] = 'Gagal upload file. Silakan coba lagi.';
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

    $sql = "INSERT INTO materi (instruktur_id, kelas_id, judul_materi, file, catatan, uploaded_at) 
            VALUES ('$instruktur_id', '$kelas_id', '$judul', '$nama_baru', '$deskripsi', NOW())";
    
    if (mysqli_query($conn, $sql)) {
        $response['success'] = true;
        $response['message'] = 'Materi berhasil diupload!';
        $response['redirect'] = 'index.php';
    } else {
        if (file_exists($file_path)) {
            unlink($file_path);
        }
        $response['message'] = 'Gagal menyimpan materi ke database: ' . mysqli_error($conn);
    }

    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Materi - Portal Instruktur BBPVP</title>
    <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../assets/css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
            min-height: 100vh;
        }

        .upload-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 24px;
        }

        .page-header {
            background: white;
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 24px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            border: 1px solid rgba(16, 185, 129, 0.1);
        }

        .page-title {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 24px;
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 8px;
        }

        .page-subtitle {
            color: #6b7280;
            font-size: 14px;
        }

        .content-card {
            background: white;
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            border: 1px solid rgba(16, 185, 129, 0.1);
            margin-bottom: 24px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 16px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 14px;
            text-decoration: none;
            border: none;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .btn-primary {
            background: #059669;
            color: white;
        }

        .btn-primary:hover {
            background: #047857;
            transform: translateY(-1px);
        }

        .btn-secondary {
            background: #f3f4f6;
            color: #374151;
            border: 1px solid #d1d5db;
        }

        .btn-secondary:hover {
            background: #e5e7eb;
        }

        @media (max-width: 900px) {
            .upload-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-logo">
            <img src="../../assets/images/logo-bbpvp.png" alt="BBPVP Bekasi" class="logo-img">
            <div class="header-text">
                <h1>Instruktur Balai Besar Pelatihan Vokasi dan Produktivitas Bekasi</h1>
                <span>Kementerian Ketenagakerjaan Republik Indonesia</span>
            </div>
        </div>
        <div class="header-user">
            <span class="user-info">
                <iconify-icon icon="material-symbols:person-outline" style="margin-right: 6px;"></iconify-icon>
                <?= htmlspecialchars($instruktur_data['nama_instruktur'] ?? 'Instruktur') ?>
            </span>
            <a href="../../logout.php" class="logout-btn">
                <iconify-icon icon="material-symbols:logout"></iconify-icon>
                Logout
            </a>
        </div>
    </header>
    <div class="container">
        <?php include "../../includes/instructor_sidebar.php"; ?>
        <div class="content">
            <div class="dashboard-container fade-in">
        <div class="page-header">
            <h1 class="page-title">
                <iconify-icon icon="material-symbols:upload-file-outline"></iconify-icon>
                Upload Materi Baru
            </h1>
            <p class="page-subtitle">Bagikan materi pembelajaran untuk siswa Anda</p>
        </div>

                <div class="upload-grid">
                    <!-- Main upload form -->
                    <div class="content-card">
                        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px;">
                            <h3 style="display: flex; align-items: center; gap: 8px; font-size: 18px; font-weight: 600; color: #1f2937;">
                                <iconify-icon icon="material-symbols:cloud-upload-outline" style="color: #059669;"></iconify-icon>
                                Form Upload Materi
                            </h3>
                            <a href="index.php" style="background: #f8fafc; color: #374151; border: 2px solid #e5e7eb; border-radius: 12px; padding: 12px 16px; font-weight: 600; font-size: 15px; text-decoration: none; display: flex; align-items: center; gap: 8px; transition: all 0.2s ease;">
                                <iconify-icon icon="material-symbols:arrow-back"></iconify-icon>
                                Kembali
                            </a>
                        </div>

            <form method="post" enctype="multipart/form-data" id="uploadForm">
                <!-- Added kelas dropdown -->
                <div style="margin-bottom: 24px;">
                    <label for="kelas_id" style="display: block; font-weight: 600; color: #374151; margin-bottom: 8px;">
                        <iconify-icon icon="material-symbols:class-outline" style="color: #059669; margin-right: 8px;"></iconify-icon>
                        Pilih Kelas *
                    </label>
                    <select id="kelas_id" 
                            name="kelas_id" 
                            class="form-control"
                            required>
                        <option value="">-- Pilih Kelas --</option>
                        <?php foreach($kelas_list as $kelas): ?>
                        <option value="<?= $kelas['kelas_id']; ?>">
                            <?= htmlspecialchars($kelas['nama_kelas']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <div style="font-size: 12px; color: #6b7280; margin-top: 4px;">
                        Pilih kelas yang akan menerima materi ini
                    </div>
                </div>

                <div style="margin-bottom: 24px;">
                    <label for="judul" style="display: block; font-weight: 600; color: #374151; margin-bottom: 8px;">
                        <iconify-icon icon="material-symbols:title-outline" style="color: #059669; margin-right: 8px;"></iconify-icon>
                        Judul Materi *
                    </label>
                    <input type="text" 
                           id="judul" 
                           name="judul" 
                           class="form-control"
                           placeholder="Masukkan judul materi yang jelas dan deskriptif..."
                           required>
                    <div style="font-size: 12px; color: #6b7280; margin-top: 4px;">
                        Contoh: "Pengenalan HTML dan CSS Dasar"
                    </div>
                </div>

                <div style="margin-bottom: 24px;">
                    <label for="deskripsi" style="display: block; font-weight: 600; color: #374151; margin-bottom: 8px;">
                        <iconify-icon icon="material-symbols:description-outline" style="color: #059669; margin-right: 8px;"></iconify-icon>
                        Deskripsi Materi
                    </label>
                    <textarea id="deskripsi" 
                              name="deskripsi" 
                              class="form-control"
                              rows="4"
                              placeholder="Berikan deskripsi singkat tentang materi ini..."
                              style="resize: vertical;"></textarea>
                    <div style="font-size: 12px; color: #6b7280; margin-top: 4px;">
                        Opsional - Jelaskan apa yang akan dipelajari siswa
                    </div>
                </div>

                <!-- Interactive drag and drop file upload area -->
                <div style="margin-bottom: 32px;">
                    <label style="display: block; font-weight: 600; color: #374151; margin-bottom: 8px;">
                        <iconify-icon icon="material-symbols:attach-file-outline" style="color: #059669; margin-right: 8px;"></iconify-icon>
                        File Materi *
                    </label>
                    
                    <div id="dropZone" class="upload-zone">
                        <input type="file" 
                               id="file" 
                               name="file" 
                               accept=".pdf,.doc,.docx,.ppt,.pptx"
                               required
                               style="display: none;">
                        
                        <div id="uploadContent" class="upload-content">
                            <iconify-icon icon="material-symbols:cloud-upload-outline" style="font-size: 48px; color: #059669; margin-bottom: 16px;"></iconify-icon>
                            <h4 style="color: #374151; margin-bottom: 8px;">Drag & Drop File atau Klik untuk Browse</h4>
                            <p style="color: #6b7280; margin-bottom: 16px;">Format: PDF, DOC, DOCX, PPT, PPTX (Max: 10MB)</p>
                            <button type="button" class="btn btn-primary" onclick="document.getElementById('file').click()">
                                <iconify-icon icon="material-symbols:folder-open-outline"></iconify-icon>
                                Pilih File
                            </button>
                        </div>

                        <div id="filePreview" class="file-preview" style="display: none;">
                            <div style="display: flex; align-items: center; gap: 16px;">
                                <div id="fileIcon" style="font-size: 32px;"></div>
                                <div style="flex: 1;">
                                    <div id="fileName" style="font-weight: 600; color: #374151; margin-bottom: 4px;"></div>
                                    <div id="fileSize" style="font-size: 12px; color: #6b7280;"></div>
                                </div>
                                <button type="button" id="removeFile" style="color: #dc2626; background: none; border: none; padding: 8px; border-radius: 6px; cursor: pointer;">
                                    <iconify-icon icon="material-symbols:close" style="font-size: 20px;"></iconify-icon>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Action buttons -->
                <div style="display: flex; gap: 12px; justify-content: flex-end;">
                    <a href="index.php" class="btn btn-secondary">
                        <iconify-icon icon="material-symbols:close"></iconify-icon>
                        Batal
                    </a>
                    <button type="submit" id="submitBtn" class="btn btn-primary">
                        <iconify-icon icon="material-symbols:upload-file-outline"></iconify-icon>
                        Upload Materi
                    </button>
                </div>
            </form>
        </div>

        <!-- Helpful information sidebar -->
        <div class="content-card">
            <h3 style="display: flex; align-items: center; gap: 8px; font-size: 18px; font-weight: 600; color: #1f2937; margin-bottom: 20px;">
                <iconify-icon icon="material-symbols:help-outline" style="color: #0d9488;"></iconify-icon>
                Panduan Upload
            </h3>
            
            <div style="margin-bottom: 24px;">
                <h4 style="color: #374151; font-size: 14px; font-weight: 600; margin-bottom: 12px;">Format File yang Didukung:</h4>
                <div style="display: flex; flex-direction: column; gap: 8px;">
                    <div style="display: flex; align-items: center; gap: 8px; font-size: 13px; color: #6b7280;">
                        <iconify-icon icon="vscode-icons:file-type-pdf2" style="font-size: 16px;"></iconify-icon>
                        PDF Documents
                    </div>
                    <div style="display: flex; align-items: center; gap: 8px; font-size: 13px; color: #6b7280;">
                        <iconify-icon icon="vscode-icons:file-type-word" style="font-size: 16px;"></iconify-icon>
                        Word Documents (DOC, DOCX)
                    </div>
                    <div style="display: flex; align-items: center; gap: 8px; font-size: 13px; color: #6b7280;">
                        <iconify-icon icon="vscode-icons:file-type-powerpoint" style="font-size: 16px;"></iconify-icon>
                        PowerPoint (PPT, PPTX)
                    </div>
                </div>
            </div>

            <div style="margin-bottom: 24px;">
                <h4 style="color: #374151; font-size: 14px; font-weight: 600; margin-bottom: 12px;">Tips Upload:</h4>
                <ul style="color: #6b7280; font-size: 13px; line-height: 1.6; margin: 0; padding-left: 16px;">
                    <li style="margin-bottom: 6px;">Gunakan nama file yang jelas</li>
                    <li style="margin-bottom: 6px;">Pastikan file tidak corrupt</li>
                    <li style="margin-bottom: 6px;">Ukuran maksimal 10MB</li>
                    <li style="margin-bottom: 6px;">Berikan deskripsi yang membantu</li>
                </ul>
            </div>

            <div style="background: #dbeafe; border: 1px solid #93c5fd; border-radius: 8px; padding: 12px; display: flex; align-items: flex-start; gap: 8px;">
                <iconify-icon icon="material-symbols:info-outline" style="color: #1d4ed8; margin-top: 2px;"></iconify-icon>
                <p style="color: #1e40af; font-size: 13px; margin: 0;">File yang diupload akan tersedia untuk semua siswa di kelas Anda.</p>
            </div>
        </div> <!-- .upload-grid -->
    </div> <!-- .dashboard-container -->
    </div> <!-- .content -->
    </div> <!-- .container -->

<!-- JavaScript for interactivity -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('file');
    const uploadContent = document.getElementById('uploadContent');
    const filePreview = document.getElementById('filePreview');
    const fileName = document.getElementById('fileName');
    const fileSize = document.getElementById('fileSize');
    const fileIcon = document.getElementById('fileIcon');
    const removeFile = document.getElementById('removeFile');
    const submitBtn = document.getElementById('submitBtn');
    const form = document.getElementById('uploadForm');

    // Drag and drop functionality
    dropZone.addEventListener('dragover', function(e) {
        e.preventDefault();
        dropZone.style.borderColor = '#059669';
        dropZone.style.backgroundColor = '#f0fdf4';
    });

    dropZone.addEventListener('dragleave', function(e) {
        e.preventDefault();
        dropZone.style.borderColor = '#d1d5db';
        dropZone.style.backgroundColor = '#f9fafb';
    });

    dropZone.addEventListener('drop', function(e) {
        e.preventDefault();
        dropZone.style.borderColor = '#d1d5db';
        dropZone.style.backgroundColor = '#f9fafb';
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            fileInput.files = files;
            handleFileSelect(files[0]);
        }
    });

    // File input change
    fileInput.addEventListener('change', function(e) {
        if (e.target.files.length > 0) {
            handleFileSelect(e.target.files[0]);
        }
    });

    // Remove file
    removeFile.addEventListener('click', function() {
        fileInput.value = '';
        uploadContent.style.display = 'block';
        filePreview.style.display = 'none';
        dropZone.style.borderColor = '#d1d5db';
        dropZone.style.backgroundColor = '#f9fafb';
    });

    // Handle file selection
    function handleFileSelect(file) {
        const maxSize = 10 * 1024 * 1024; // 10MB
        
        if (file.size > maxSize) {
            showErrorAlert('Ukuran file terlalu besar. Maksimal 10MB.');
            fileInput.value = '';
            return;
        }

        const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation'];
        
        if (!allowedTypes.includes(file.type)) {
            showErrorAlert('Format file tidak didukung. Gunakan PDF, DOC, DOCX, PPT, atau PPTX.');
            fileInput.value = '';
            return;
        }

        // Show file preview
        fileName.textContent = file.name;
        fileSize.textContent = formatFileSize(file.size);
        
        // Set appropriate icon
        if (file.type.includes('pdf')) {
            fileIcon.innerHTML = '<iconify-icon icon="vscode-icons:file-type-pdf2"></iconify-icon>';
        } else if (file.type.includes('word')) {
            fileIcon.innerHTML = '<iconify-icon icon="vscode-icons:file-type-word"></iconify-icon>';
        } else if (file.type.includes('presentation')) {
            fileIcon.innerHTML = '<iconify-icon icon="vscode-icons:file-type-powerpoint"></iconify-icon>';
        }

        uploadContent.style.display = 'none';
        filePreview.style.display = 'block';
        dropZone.style.borderColor = '#059669';
        dropZone.style.backgroundColor = '#f0fdf4';
    }

    // Format file size
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validate form
        if (!document.getElementById('kelas_id').value) {
            showErrorAlert('Silakan pilih kelas terlebih dahulu!');
            return;
        }
        
        if (!document.getElementById('judul').value.trim()) {
            showErrorAlert('Silakan masukkan judul materi!');
            return;
        }
        
        if (!document.getElementById('file').files.length) {
            showErrorAlert('Silakan pilih file yang ingin diupload!');
            return;
        }

        submitBtn.innerHTML = '<iconify-icon icon="material-symbols:hourglass-empty" class="spin"></iconify-icon> Mengupload...';
        submitBtn.disabled = true;
        
        const formData = new FormData(form);
        
        fetch(window.location.href, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showSuccessAlert(data.message);
                setTimeout(() => {
                    window.location.href = data.redirect;
                }, 1500);
            } else {
                showErrorAlert(data.message);
                submitBtn.innerHTML = '<iconify-icon icon="material-symbols:upload-file-outline"></iconify-icon> Upload Materi';
                submitBtn.disabled = false;
            }
        })
        .catch(error => {
            showErrorAlert('Terjadi kesalahan: ' + error.message);
            submitBtn.innerHTML = '<iconify-icon icon="material-symbols:upload-file-outline"></iconify-icon> Upload Materi';
            submitBtn.disabled = false;
        });
    });

    // Alert functions
    window.showSuccessAlert = function(message) {
        const alert = document.createElement('div');
        alert.className = 'alert-success';
        alert.innerHTML = `<iconify-icon icon="material-symbols:check-circle-outline"></iconify-icon> ${message}`;
        document.body.appendChild(alert);
        setTimeout(() => alert.remove(), 5000);
    };

    window.showErrorAlert = function(message) {
        const alert = document.createElement('div');
        alert.className = 'alert-error';
        alert.innerHTML = `<iconify-icon icon="material-symbols:error-outline"></iconify-icon> ${message}`;
        document.body.appendChild(alert);
        setTimeout(() => alert.remove(), 5000);
    };

    window.showInfoAlert = function(message) {
        const alert = document.createElement('div');
        alert.className = 'alert-info';
        alert.innerHTML = `<iconify-icon icon="material-symbols:info-outline"></iconify-icon> ${message}`;
        document.body.appendChild(alert);
        setTimeout(() => alert.remove(), 3000);
    };
});
</script>

<!-- CSS for styling -->
<style>
.upload-zone {
    border: 2px dashed #d1d5db;
    border-radius: 12px;
    padding: 32px;
    text-align: center;
    background-color: #f9fafb;
    transition: all 0.3s ease;
    cursor: pointer;
}

.upload-zone:hover {
    border-color: #059669;
    background-color: #f0fdf4;
}

.upload-content h4 {
    font-size: 16px;
    font-weight: 600;
}

.file-preview {
    padding: 16px;
    background-color: #f0fdf4;
    border-radius: 8px;
    border: 1px solid #059669;
}

.form-input {
    padding: 12px 16px;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    font-size: 14px;
    transition: all 0.2s ease;
    background-color: white;
}

.form-input:focus {
    outline: none;
    border-color: #059669;
    box-shadow: 0 0 0 3px rgba(5, 150, 105, 0.1);
}

.alert-success, .alert-error, .alert-info {
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 16px 20px;
    border-radius: 8px;
    color: white;
    font-weight: 500;
    z-index: 1000;
    display: flex;
    align-items: center;
    gap: 8px;
    animation: slideIn 0.3s ease;
}

.alert-success {
    background-color: #059669;
}

.alert-error {
    background-color: #dc2626;
}

.alert-info {
    background-color: #0d9488;
}

@keyframes slideIn {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

.spin {
    animation: spin 1s linear infinite;
}

@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

@media (max-width: 768px) {
    .upload-grid {
        grid-template-columns: 1fr !important;
    }
}
</style>

<footer>
    <p>© <?= date("Y"); ?> Manajemen Penjadwalan BBPVP - All Rights Reserved</p>
</footer>
</body>
</html>
