<?php
session_start();
include "../../config/database.php";

// Check if user is logged in and is instructor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'instruktur') {
    header("Location: ../../login.php");
    exit;
}

$instruktur_id = $_SESSION['instruktur_id'] ?? 0;

// Get materi ID parameter
$materi_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$materi_id) {
    http_response_code(400);
    die('ID materi tidak valid');
}

// Get materi data from database
$materi_query = mysqli_query($conn, "SELECT * FROM materi WHERE materi_id = '$materi_id' AND instruktur_id = '$instruktur_id'");
$materi_data = mysqli_fetch_assoc($materi_query);

if (!$materi_data) {
    http_response_code(404);
    die('Materi tidak ditemukan atau Anda tidak memiliki akses');
}

$file = $materi_data['file'];

// Validate file path to prevent directory traversal
$file_path = realpath(__DIR__ . '/../../uploads/materi/' . $file);
$base_path = realpath(__DIR__ . '/../../uploads/materi/');

if ($file_path === false || strpos($file_path, $base_path) !== 0 || !file_exists($file_path)) {
    http_response_code(404);
    die('File tidak ditemukan di server');
}

// Get file extension
$file_ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));

// Map file extensions to MIME types
$mime_types = array(
    'pdf' => 'application/pdf',
    'doc' => 'application/msword',
    'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'xls' => 'application/vnd.ms-excel',
    'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'ppt' => 'application/vnd.ms-powerpoint',
    'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'txt' => 'text/plain',
    'jpg' => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'png' => 'image/png',
    'gif' => 'image/gif',
    'zip' => 'application/zip',
    'rar' => 'application/x-rar-compressed',
    '7z' => 'application/x-7z-compressed'
);

// Get MIME type
$mime_type = isset($mime_types[$file_ext]) ? $mime_types[$file_ext] : 'application/octet-stream';

header('Content-Type: ' . $mime_type);
header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
header('Content-Length: ' . filesize($file_path));
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Read and output file
readfile($file_path);
exit;
?>
