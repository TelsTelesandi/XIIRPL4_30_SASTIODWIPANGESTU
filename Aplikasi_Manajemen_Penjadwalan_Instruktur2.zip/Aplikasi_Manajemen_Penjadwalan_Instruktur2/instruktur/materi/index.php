<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'instruktur') {
    header("Location: ../../login.php");
    exit;
}

include "../../config/database.php";

$instruktur_id = $_SESSION['instruktur_id'] ?? 0;

if (!$conn) {
    die("Database connection error");
}

// Get instructor data
$instruktur_query = mysqli_query($conn, "SELECT * FROM instruktur WHERE instruktur_id = '$instruktur_id'");
$instruktur_data = mysqli_fetch_assoc($instruktur_query);

// Get all classes for filter
$kelas_query = mysqli_query($conn, "SELECT kelas_id, nama_kelas FROM kelas ORDER BY nama_kelas ASC");
$kelas_list = [];
while($kelas = mysqli_fetch_assoc($kelas_query)) {
    $kelas_list[] = $kelas;
}

// Get selected class filter
$selected_kelas = isset($_GET['kelas_id']) ? (int)$_GET['kelas_id'] : 0;

// Get materi data
$materi_query = "SELECT m.*, k.nama_kelas FROM materi m 
                 LEFT JOIN kelas k ON m.kelas_id = k.kelas_id 
                 WHERE m.instruktur_id = '$instruktur_id'";

if ($selected_kelas > 0) {
    $materi_query .= " AND m.kelas_id = '$selected_kelas'";
}

$materi_query .= " ORDER BY m.uploaded_at DESC";
$materi_result = mysqli_query($conn, $materi_query);

if (!$materi_result) {
    die("Query error: " . mysqli_error($conn));
}

$materi_list = [];
while($materi = mysqli_fetch_assoc($materi_result)) {
    $materi_list[] = $materi;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Materi - Portal Instruktur</title>
    <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../assets/css/style.css">
    <style>
        /* Layout & Spacing */
        .content { 
            padding: 32px; 
            background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
        }
        .dashboard-container { 
            max-width: 1400px; 
            margin: 0 auto; 
        }
        
        /* Statistics Grid */
        .stats-grid { 
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 24px;
            margin-bottom: 32px; 
        }
        .stat-card {
            background: linear-gradient(135deg, #ffffff 0%, #f9fafb 100%);
            border: 2px solid #e5e7eb;
            border-radius: 16px;
            padding: 28px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #059669, #10b981);
        }
        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 24px rgba(5, 150, 105, 0.15);
            border-color: #10b981;
        }
        .stat-number {
            font-size: 42px;
            font-weight: 800;
            color: #059669;
            margin-bottom: 8px;
            line-height: 1;
        }
        .stat-label {
            font-size: 15px;
            color: #6b7280;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        /* Filter Card */
        .filter-card { 
            background: white;
            border: 2px solid #e5e7eb;
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 24px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
            display: flex; 
            align-items: center; 
            gap: 20px; 
            flex-wrap: wrap; 
        }
        .filter-label { 
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 700; 
            color: #374151;
            font-size: 15px;
        }
        .filter-select { 
            min-width: 220px;
            padding: 12px 16px;
            border: 2px solid #d1d5db;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 500;
            background: white;
            color: #374151;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .filter-select:hover {
            border-color: #059669;
        }
        .filter-select:focus {
            outline: none;
            border-color: #059669;
            box-shadow: 0 0 0 3px rgba(5, 150, 105, 0.1);
        }
        .filter-card .spacer { 
            flex: 1 1 auto; 
        }
        
        /* Materi Card */
        .materi-card { 
            background: white;
            border: 2px solid #e5e7eb;
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 16px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center; 
            justify-content: space-between;
            gap: 20px;
            transition: all 0.3s ease;
        }
        .materi-card:hover {
            border-color: #059669;
            box-shadow: 0 8px 20px rgba(5, 150, 105, 0.12);
            transform: translateY(-2px);
        }
        .materi-icon { 
            font-size: 64px; 
            min-width: 80px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #059669;
        }
        .materi-info { 
            flex: 1;
            min-width: 0;
        }
        .materi-name { 
            font-size: 20px; 
            font-weight: 700; 
            color: #1f2937;
            margin-bottom: 8px;
            line-height: 1.3;
        }
        .materi-meta { 
            display: flex;
            align-items: center;
            flex-wrap: wrap; 
            gap: 16px; 
            font-size: 14px; 
        }
        .materi-meta span {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: #6b7280;
            font-weight: 500;
        }
        .materi-date { 
            color: #64748b; 
            font-weight: 600; 
        }
        .materi-actions { 
            display: flex;
            gap: 12px;
            flex-shrink: 0;
        }
        .materi-actions .btn-small { 
            min-width: 120px; 
            padding: 10px 18px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.2s ease;
            justify-content: center; 
        }
        .btn-download {
            background: linear-gradient(135deg, #e0f2fe, #bae6fd);
            color: #0369a1;
            border: 2px solid #bae6fd;
        }
        .btn-download:hover {
            background: linear-gradient(135deg, #bae6fd, #93c5fd);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(3, 105, 161, 0.2);
        }
        .btn-delete {
            background: linear-gradient(135deg, #fee2e2, #fecaca);
            color: #dc2626;
            border: 2px solid #fecaca;
        }
        .btn-delete:hover {
            background: linear-gradient(135deg, #fecaca, #fca5a5);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(220, 38, 38, 0.2);
        }
        
        /* Content Card */
        .content-card {
            background: white;
            border: 2px solid #e5e7eb;
            border-radius: 16px;
            padding: 28px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        }
        .content-card h3 {
            font-size: 20px;
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        /* Alert Messages */
        .alert {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            font-weight: 600;
            font-size: 14px;
        }
        .alert-success {
            background: linear-gradient(135deg, #d1fae5, #a7f3d0);
            color: #047857;
            border: 2px solid #6ee7b7;
        }
        .alert-error {
            background: linear-gradient(135deg, #fee2e2, #fecaca);
            color: #dc2626;
            border: 2px solid #fca5a5;
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 80px 20px;
        }
        .empty-icon {
            font-size: 80px;
            color: #d1d5db;
            margin-bottom: 20px;
            opacity: 0.6;
        }
        .empty-title {
            font-size: 24px;
            font-weight: 700;
            color: #6b7280;
            margin-bottom: 12px;
        }
        .empty-text {
            font-size: 16px;
            color: #9ca3af;
            margin-bottom: 32px;
            max-width: 400px;
            margin-left: auto;
            margin-right: auto;
        }
        
        /* Responsive */
        @media (max-width: 1024px) {
            .content { padding: 24px; }
            .materi-card { 
                flex-wrap: wrap;
                gap: 16px;
            }
            .materi-actions {
                width: 100%;
                justify-content: flex-end;
            }
        }
        @media (max-width: 768px) {
            .content { 
                margin-left: 0 !important; 
                width: 100% !important; 
                padding: 20px; 
            }
            .stats-grid {
                grid-template-columns: 1fr;
            }
            .filter-card {
                flex-direction: column;
                align-items: stretch;
            }
            .filter-select {
                width: 100%;
            }
            .materi-card { 
                flex-direction: column;
                align-items: flex-start; 
            }
            .materi-actions {
                width: 100%;
                flex-direction: column;
            }
            .materi-actions .btn-small {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-logo">
            <img src="../../assets/images/logo-bbpvp.png" alt="BBPVP Bekasi" class="logo-img">
            <div class="header-text">
                <h1>Instruktur Balai Besar Pelatihan Vokasi dan Produktivitas Bekasi</h1>
                <span>Kementerian Ketenagakerjaan Republik Indonesia</span>
            </div>
        </div>
        <div class="header-user">
            <span class="user-info">
                <iconify-icon icon="material-symbols:person-outline" style="margin-right: 6px;"></iconify-icon>
                <?= htmlspecialchars($instruktur_data['nama_instruktur'] ?? 'Instruktur') ?>
            </span>
            <a href="../../logout.php" class="logout-btn">
                <iconify-icon icon="material-symbols:logout"></iconify-icon>
                Logout
            </a>
        </div>
    </header>
    <div class="container">
        <?php include "../../includes/instructor_sidebar.php"; ?>

        <div class="content">
            <div class="dashboard-container fade-in">
                <div class="dashboard-header">
                    <h2>
                        <iconify-icon icon="material-symbols:folder-outline"></iconify-icon>
                        Kelola Materi Pembelajaran
                    </h2>
                    <p class="dashboard-subtitle">Lihat, kelola, dan bagikan materi pembelajaran Anda</p>
                </div>

                <!-- Statistics -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-number"><?= count($materi_list); ?></div>
                        <div class="stat-label">Total Materi</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?= count($kelas_list); ?></div>
                        <div class="stat-label">Kelas Aktif</div>
                    </div>
                </div>

                <!-- Filter Section -->
                <div class="content-card form-card filter-card">
                    <span class="filter-label">
                        <iconify-icon icon="material-symbols:filter-list"></iconify-icon>
                        Filter Kelas:
                    </span>
                    <select class="filter-select" onchange="filterByClass(this.value)">
                        <option value="">Semua Kelas</option>
                        <?php foreach($kelas_list as $kelas): ?>
                        <option value="<?= $kelas['kelas_id']; ?>" <?= $selected_kelas == $kelas['kelas_id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($kelas['nama_kelas']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <div class="spacer"></div>
                    <a href="upload.php" class="btn btn-primary">
                        <iconify-icon icon="material-symbols:add"></iconify-icon>
                        Upload Materi Baru
                    </a>
                </div>

                <!-- Success/Error Messages -->
                <?php if (isset($_GET['success'])): ?>
                    <div class="alert alert-success">
                        <iconify-icon icon="material-symbols:check-circle-outline"></iconify-icon>
                        <?php
                        switch($_GET['success']) {
                            case 'deleted':
                                echo 'Materi berhasil dihapus!';
                                break;
                            default:
                                echo 'Operasi berhasil!';
                        }
                        ?>
                    </div>
                <?php endif; ?>

                <?php if (isset($_GET['error'])): ?>
                    <div class="alert alert-error">
                        <iconify-icon icon="material-symbols:error-outline"></iconify-icon>
                        <?php
                        switch($_GET['error']) {
                            case 'invalid_id':
                                echo 'ID materi tidak valid!';
                                break;
                            case 'not_found':
                                echo 'Materi tidak ditemukan!';
                                break;
                            case 'delete_failed':
                                echo 'Gagal menghapus materi!';
                                break;
                            default:
                                echo 'Terjadi kesalahan!';
                        }
                        ?>
                    </div>
                <?php endif; ?>

                <!-- Materi List -->
                <div class="content-card">
                    <?php if (count($materi_list) > 0): ?>
                        <h3>
                            <iconify-icon icon="material-symbols:description"></iconify-icon>
                            Daftar Materi (<?= count($materi_list); ?>)
                        </h3>
                        
                        <?php foreach($materi_list as $materi): ?>
                            <div class="materi-card">
                                <div class="materi-icon">
                                    <?php
if (isset($materi['file']) && !empty($materi['file'])) {
    $ext = strtolower(pathinfo($materi['file'], PATHINFO_EXTENSION));
} else {
    $ext = ''; // atau bisa juga kasih default value
}

if ($ext === 'pdf') {
    echo '<iconify-icon icon="vscode-icons:file-type-pdf2"></iconify-icon>';
} elseif (in_array($ext, ['doc', 'docx'])) {
    echo '<iconify-icon icon="vscode-icons:file-type-word"></iconify-icon>';
} elseif (in_array($ext, ['xls', 'xlsx'])) {
    echo '<iconify-icon icon="vscode-icons:file-type-excel"></iconify-icon>';
} elseif (in_array($ext, ['ppt', 'pptx'])) {
    echo '<iconify-icon icon="vscode-icons:file-type-powerpoint"></iconify-icon>';
} else {
    echo '<iconify-icon icon="material-symbols:file-present"></iconify-icon>';
}
?>

                                </div>
                                <div class="materi-info">
                                    <div class="materi-name"><?= htmlspecialchars($materi['judul_materi'] ?? $materi['judul'] ?? 'Materi'); ?></div>
                                    <div class="materi-meta">
                                        <span>👥 <?= htmlspecialchars($materi['nama_kelas'] ?? 'Kelas'); ?></span>
                                        <span class="materi-date">📅 <?= date('d M Y', strtotime($materi['uploaded_at'])); ?></span>
                                    </div>
                                </div>
                                <div class="materi-actions">
                                    <a href="download.php?id=<?= $materi['materi_id']; ?>" class="btn-small btn-download">
                                        <iconify-icon icon="material-symbols:download"></iconify-icon>
                                        Download
                                    </a>
                                    <a href="hapus.php?id=<?= $materi['materi_id']; ?>" class="btn-small btn-delete" onclick="return confirm('Yakin ingin menghapus materi ini?')">
                                        <iconify-icon icon="material-symbols:delete-outline"></iconify-icon>
                                        Hapus
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="empty-state">
                            <div class="empty-icon">
                                <iconify-icon icon="material-symbols:folder-open-outline"></iconify-icon>
                            </div>
                            <div class="empty-title">Belum Ada Materi</div>
                            <div class="empty-text">Anda belum mengupload materi pembelajaran apapun. Mulai dengan mengupload materi baru.</div>
                            <a href="upload.php" class="btn btn-primary">
                                <iconify-icon icon="material-symbols:add"></iconify-icon>
                                Upload Materi Pertama
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <p>© <?= date("Y"); ?> Manajemen Penjadwalan BBPVP - All Rights Reserved</p>
    </footer>

    <script>
        function filterByClass(kelasId) {
            if (kelasId) {
                window.location.href = '?kelas_id=' + kelasId;
            } else {
                window.location.href = '?';
            }
        }
    </script>
</body>
</html>
