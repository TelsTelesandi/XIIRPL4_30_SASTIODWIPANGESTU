<?php
session_start();
include "../config/database.php";
include "../config/app.php";

// Check if instruktur_id exists in session
if (!isset($_SESSION['instruktur_id']) || empty($_SESSION['instruktur_id'])) {
    header('Location: ' . app_url('login.php'));
    exit;
}

$instruktur_id = $_SESSION['instruktur_id'];

// Get instructor data with error handling
$instruktur_query = mysqli_query($conn, "SELECT * FROM instruktur WHERE instruktur_id = '$instruktur_id'");
if (!$instruktur_query) {
    die("Error: " . mysqli_error($conn));
}
$instruktur_data = mysqli_fetch_assoc($instruktur_query);

if (!$instruktur_data) {
    die("Instruktur tidak ditemukan");
}

// Check today's attendance
$today = date('Y-m-d');
$attendance_query = mysqli_query($conn, "SELECT * FROM absensi WHERE instruktur_id = '$instruktur_id' AND tanggal = '$today'");
if (!$attendance_query) {
    die("Error: " . mysqli_error($conn));
}
$today_attendance = mysqli_fetch_assoc($attendance_query);

// Get attendance statistics with error handling
$total_days_query = mysqli_query($conn, "SELECT COUNT(DISTINCT tanggal) as total FROM absensi WHERE instruktur_id = '$instruktur_id'");
if (!$total_days_query) {
    error_log("Query error: " . mysqli_error($conn));
    $total_days = 0;
} else {
    $total_days = mysqli_fetch_assoc($total_days_query)['total'] ?? 0;
}

$present_days_query = mysqli_query($conn, "SELECT COUNT(*) as total FROM absensi WHERE instruktur_id = '$instruktur_id' AND status = 'Hadir'");
if (!$present_days_query) {
    error_log("Query error: " . mysqli_error($conn));
    $present_days = 0;
} else {
    $present_days = mysqli_fetch_assoc($present_days_query)['total'] ?? 0;
}

$attendance_rate = $total_days > 0 ? round(($present_days / $total_days) * 100, 1) : 0;

// Backfill 'Alfa' for missed attendance starting from policy activation date (today)
try {
    $today_dash = date('Y-m-d');
    $end_range = date('Y-m-d', strtotime('-1 day', strtotime($today_dash)));
    // policy activation: only start counting from today
    $policy_start = date('Y-m-d');
    $start_range = null;

    if ($stmtMin = mysqli_prepare($conn, "SELECT MIN(tanggal) AS min_tgl FROM jadwal WHERE instruktur_id = ?")) {
        mysqli_stmt_bind_param($stmtMin, "i", $instruktur_id);
        mysqli_stmt_execute($stmtMin);
        $resMin = mysqli_stmt_get_result($stmtMin);
        $rowMin = mysqli_fetch_assoc($resMin);
        $start_range = $rowMin['min_tgl'] ?? null;
        mysqli_stmt_close($stmtMin);
    }

    // enforce policy start
    if ($start_range) {
        $start_range = max($start_range, $policy_start);
    }

    if ($start_range && $start_range <= $end_range && ($stmt = mysqli_prepare($conn, "
        SELECT j.jadwal_id, j.tanggal
        FROM jadwal j
        LEFT JOIN absensi a
            ON a.instruktur_id = j.instruktur_id AND a.tanggal = j.tanggal
        LEFT JOIN pengajuan_izin p
            ON p.instruktur_id = j.instruktur_id AND p.tanggal = j.tanggal AND p.status = 'Disetujui'
        WHERE j.instruktur_id = ?
          AND j.tanggal BETWEEN ? AND ?
          AND a.absensi_id IS NULL
          AND p.pengajuan_id IS NULL
        ORDER BY j.tanggal ASC
    "))) {
        mysqli_stmt_bind_param($stmt, "iss", $instruktur_id, $start_range, $end_range);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        while ($row = mysqli_fetch_assoc($res)) {
            $tgl_row = $row['tanggal'];
            $day_map = [
                'Sunday' => 'Minggu','Monday' => 'Senin','Tuesday' => 'Selasa','Wednesday' => 'Rabu','Thursday' => 'Kamis','Friday' => 'Jumat','Saturday' => 'Sabtu'
            ];
            $hari_row = $day_map[date('l', strtotime($tgl_row))] ?? date('l', strtotime($tgl_row));
            if ($ins = mysqli_prepare($conn, "INSERT INTO absensi (jadwal_id, instruktur_id, tanggal, hari, status, alasan, waktu_absen) VALUES (?, ?, ?, ?, 'Alfa', NULL, '00:00:00')")) {
                mysqli_stmt_bind_param($ins, "iiss", $row['jadwal_id'], $instruktur_id, $tgl_row, $hari_row);
                mysqli_stmt_execute($ins);
                mysqli_stmt_close($ins);
            }
        }
        mysqli_stmt_close($stmt);
    }
} catch (Throwable $e) {
    // silently ignore to keep dashboard rendering
}

// Get upcoming schedules with error handling
$upcoming_schedules_result = mysqli_query($conn, "SELECT j.*, k.nama_kelas FROM jadwal j LEFT JOIN kelas k ON j.kelas_id = k.kelas_id WHERE j.instruktur_id = '$instruktur_id' AND j.tanggal >= CURDATE() ORDER BY j.tanggal ASC LIMIT 3");
if (!$upcoming_schedules_result) {
    error_log("Upcoming schedules query error: " . mysqli_error($conn));
    $upcoming_schedules = false;
} else {
    $upcoming_schedules = $upcoming_schedules_result;
}

// Get recent materials with error handling
$recent_materials_result = mysqli_query($conn, "SELECT * FROM materi WHERE instruktur_id = '$instruktur_id' ORDER BY uploaded_at DESC LIMIT 3");
if (!$recent_materials_result) {
    error_log("Recent materials query error: " . mysqli_error($conn));
    $recent_materials = false;
} else {
    $recent_materials = $recent_materials_result;
}


?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Portal Instruktur BBPVP</title>
    <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header>
        <div class="header-logo">
            <img src="../assets/images/logo-bbpvp.png" alt="BBPVP Bekasi" class="logo-img">
            <div class="header-text">
                <h1>Instruktur Balai Besar Pelatihan Vokasi dan Produktivitas Bekasi</h1>
                <span>Kementerian Ketenagakerjaan Republik Indonesia</span>
            </div>
        </div>
        <div class="header-user">
            <span class="user-info">
                <iconify-icon icon="material-symbols:person-outline" style="margin-right: 6px;"></iconify-icon>
                <?= htmlspecialchars($instruktur_data['nama_instruktur'] ?? 'Instruktur') ?>
            </span>
            <a href="<?= app_url('logout.php') ?>" class="logout-btn">
                <iconify-icon icon="material-symbols:logout"></iconify-icon>
                Logout
            </a>
        </div>
    </header>
    <div class="container">
        <?php include "../includes/instructor_sidebar.php"; ?>

        <div class="content">
            <div class="dashboard-container fade-in">
        <!-- Official Government Dashboard Header -->
        <div style="background: #1e3a8a; color: white; padding: 24px; border-radius: 8px; margin-bottom: 24px; border-left: 6px solid #3b82f6;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h1 style="margin: 0 0 8px 0; font-size: 28px; font-weight: 700;">Dashboard Sistem Informasi</h1>
                    <p style="margin: 0; font-size: 14px; opacity: 0.9;">Balai Besar Pelatihan Vokasi dan Produktivitas - Bekasi</p>
                    <p style="margin: 4px 0 0 0; font-size: 12px; opacity: 0.8;">Kementerian Ketenagakerjaan Republik Indonesia</p>
                </div>
               <div style="text-align: right;">
    <div id="tanggal" style="font-size: 14px; opacity: 0.9; margin-bottom: 4px;"></div>
    <div id="jam" style="font-size: 18px; font-weight: 600;"></div>
</div>
        </div>

<script>
function updateTime() {
    const now = new Date();
    const tanggal = now.toLocaleDateString('id-ID', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });
    const waktu = now.toLocaleTimeString('id-ID', { hour12: false });
    const tglEl = document.getElementById('tanggal');
    const jamEl = document.getElementById('jam');
    if (tglEl) tglEl.textContent = tanggal;
    if (jamEl) jamEl.textContent = waktu + ' WIB';
}
setInterval(updateTime, 1000);
updateTime();
</script>

    <!-- Statistik Utama (gaya admin) -->
    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin: 24px 0;">
        <div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 6px; padding: 20px; border-left: 4px solid #059669;">
            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 8px;">
            <div>
                    <h3 style="margin: 0 0 4px 0; font-size: 13px; font-weight: 600; color: #6b7280; text-transform: uppercase;">Tingkat Kehadiran</h3>
                    <div style="font-size: 32px; font-weight: 700; color: #1f2937;"><?= $attendance_rate ?>%</div>
            </div>
                <div style="background: #ecfdf5; padding: 12px; border-radius: 6px;">
                    <iconify-icon icon="material-symbols:assignment-turned-in" style="font-size: 28px; color: #059669;"></iconify-icon>
            </div>
        </div>
            <p style="margin: 8px 0 0 0; font-size: 12px; color: #9ca3af;">Rasio hadir dari total hari absensi</p>
    </div>

        <div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 6px; padding: 20px; border-left: 4px solid #3b82f6;">
            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 8px;">
                <div>
                    <h3 style="margin: 0 0 4px 0; font-size: 13px; font-weight: 600; color: #6b7280; text-transform: uppercase;">Jadwal Mendatang</h3>
                    <div style="font-size: 32px; font-weight: 700; color: #1f2937;"><?= $upcoming_schedules ? mysqli_num_rows($upcoming_schedules) : 0 ?></div>
                </div>
                <div style="background: #eff6ff; padding: 12px; border-radius: 6px;">
                    <iconify-icon icon="material-symbols:calendar-today" style="font-size: 28px; color: #3b82f6;"></iconify-icon>
                </div>
            </div>
            <p style="margin: 8px 0 0 0; font-size: 12px; color: #9ca3af;">Jadwal mengajar terdekat</p>
        </div>

        <div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 6px; padding: 20px; border-left: 4px solid #8b5cf6;">
            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 8px;">
                <div>
                    <h3 style="margin: 0 0 4px 0; font-size: 13px; font-weight: 600; color: #6b7280; text-transform: uppercase;">Total Materi</h3>
                    <div style="font-size: 32px; font-weight: 700; color: #1f2937;"><?= $recent_materials ? mysqli_num_rows($recent_materials) : 0 ?></div>
                </div>
                <div style="background: #f3e8ff; padding: 12px; border-radius: 6px;">
                    <iconify-icon icon="material-symbols:folder" style="font-size: 28px; color: #8b5cf6;"></iconify-icon>
                </div>
            </div>
            <p style="margin: 8px 0 0 0; font-size: 12px; color: #9ca3af;">Materi yang Anda unggah</p>
        </div>
    </div>

    <!-- Status Kehadiran Hari Ini (gaya admin) -->
    <div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 6px; padding: 20px; margin-bottom: 24px;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
                <h3 style="color: #1f2937; font-size: 16px; font-weight: 600; margin: 0 0 4px 0; display:flex; align-items:center; gap:8px;">
                    <iconify-icon icon="material-symbols:how-to-reg-outline" style="font-size: 20px; color: #059669;"></iconify-icon>
                    Status Kehadiran Hari Ini
                </h3>
                <p style="color: #6b7280; font-size: 13px; margin: 6px 0 0 28px;">Pantau kehadiran Anda untuk hari ini</p>
            </div>
            <div style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-radius: 8px; font-weight: 600; <?= $today_attendance ? 'background: #dcfce7; color: #047857;' : 'background: #fee2e2; color: #dc2626;' ?>">
                <iconify-icon icon="<?= $today_attendance ? 'material-symbols:check-circle' : 'material-symbols:schedule' ?>"></iconify-icon>
                <?= $today_attendance ? 'Sudah Absen Hari Ini' : 'Belum Absen Hari Ini' ?>
            </div>
        </div>
    </div>

    <!-- Jadwal Mendatang (tabel gaya admin) -->
    <div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 6px; margin-bottom: 24px;">
        <div style="padding: 12px 16px; background: #f9fafb; border-bottom: 1px solid #e5e7eb; border-radius: 6px 6px 0 0;">
            <h3 style="margin: 0; font-size: 16px; font-weight: 600; color: #1f2937; display: flex; align-items: center; gap: 8px;">
                <iconify-icon icon="material-symbols:calendar-month-outline" style="font-size: 20px; color: #2563eb;"></iconify-icon>
                Jadwal Mengajar Mendatang
                </h3>
            </div>
        <div style="padding: 16px;">
            <?php if ($upcoming_schedules && mysqli_num_rows($upcoming_schedules) > 0): ?>
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 12px;">
                <thead>
                    <tr style="background: #f9fafb; border-bottom: 2px solid #e5e7eb;">
                        <th style="padding: 10px; text-align: left; font-size: 13px; font-weight: 600; color: #374151;">No</th>
                        <th style="padding: 10px; text-align: left; font-size: 13px; font-weight: 600; color: #374151;">Tanggal</th>
                        <th style="padding: 10px; text-align: left; font-size: 13px; font-weight: 600; color: #374151;">Kelas</th>
                        <th style="padding: 10px; text-align: left; font-size: 13px; font-weight: 600; color: #374151;">Waktu</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no=1; if ($upcoming_schedules) { mysqli_data_seek($upcoming_schedules, 0); while ($schedule = mysqli_fetch_assoc($upcoming_schedules)): ?>
                    <tr style="border-bottom: 1px solid #f3f4f6;">
                        <td style="padding: 10px; color: #6b7280;"><?= $no++; ?></td>
                        <td style="padding: 10px; color: #1f2937;"><?= date('d/m/Y', strtotime($schedule['tanggal'])) ?></td>
                        <td style="padding: 10px; color: #1f2937; font-weight: 600;">><?= htmlspecialchars($schedule['nama_kelas'] ?? 'Kelas') ?></td>
                        <td style="padding: 10px; color: #6b7280;"><?= htmlspecialchars($schedule['jam_mulai'] . ' - ' . $schedule['jam_selesai']) ?></td>
                    </tr>
                    <?php endwhile; } ?>
                </tbody>
            </table>
            <div style="text-align: right;">
                <a href="jadwal.php" style="display: inline-block; padding: 8px 16px; background: #2563eb; color: white; text-decoration: none; border-radius: 4px; font-size: 14px; font-weight: 500;">Lihat Semua Jadwal →</a>
                    </div>
            <?php else: ?>
            <div style="text-align: center; padding: 40px 20px;">
                <iconify-icon icon="material-symbols:calendar-today-outline" style="font-size: 48px; color: #9ca3af; margin-bottom: 12px;"></iconify-icon>
                <div style="font-size: 16px; font-weight: 600; color: #374151; margin-bottom: 4px;">Tidak ada jadwal mendatang</div>
                <div style="font-size: 14px; color: #6b7280;">Belum terdapat jadwal mengajar</div>
                </div>
            <?php endif; ?>
        </div>
        </div>

    <!-- Materi Terbaru (gaya admin) -->
    <div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 6px; margin-bottom: 24px;">
        <div style="padding: 16px 20px; background: #f9fafb; border-bottom: 1px solid #e5e7eb; border-radius: 6px 6px 0 0;">
            <h3 style="margin: 0; font-size: 16px; font-weight: 600; color: #1f2937; display: flex; align-items: center; gap: 8px;">
                <iconify-icon icon="material-symbols:folder-open" style="font-size: 20px; color: #8b5cf6;"></iconify-icon>
                    Materi Terbaru
                </h3>
            </div>
        <div style="padding: 20px;">
            <?php if ($recent_materials && mysqli_num_rows($recent_materials) > 0): ?>
                <?php if ($recent_materials) { mysqli_data_seek($recent_materials, 0); while ($material = mysqli_fetch_assoc($recent_materials)): ?>
                    <div style="padding: 12px 0; border-bottom: 1px solid #f3f4f6; display: flex; justify-content: space-between; align-items: center;">
                        <div>
                        <?php $judul_materi = isset($material['judul_materi']) && $material['judul_materi'] !== null ? $material['judul_materi'] : ($material['judul'] ?? 'Materi'); ?>
                        <h4 style="font-weight: 600; color: #1f2937; margin: 0 0 4px 0;"><?= htmlspecialchars($judul_materi) ?></h4>
                        <p style="color: #6b7280; font-size: 14px; margin: 0;">
                                <?php if (!empty($material['uploaded_at'])): ?>
                                    Diupload: <?= date('d M Y H:i', strtotime($material['uploaded_at'])) ?>
                                <?php else: ?>
                                    Diupload: Tidak diketahui
                                <?php endif; ?>
                            </p>
                        </div>
                    <a href="materi/download.php?id=<?= urlencode($material['materi_id'] ?? '') ?>" download style="color: #059669; background: none; border: none; padding: 8px; cursor: pointer; font-weight: 600; display: flex; align-items: center; gap: 4px; text-decoration: none;">
                            <iconify-icon icon="material-symbols:download"></iconify-icon>
                        </a>
                    </div>
                <?php endwhile; } ?>
            <?php else: ?>
                <div style="text-align: center; padding: 40px 20px; color: #6b7280;">Belum ada materi yang diupload</div>
            <?php endif; ?>
            <div style="text-align: right; margin-top: 12px;">
                <a href="materi/index.php" style="display: inline-block; padding: 8px 16px; background: #8b5cf6; color: white; text-decoration: none; border-radius: 4px; font-size: 14px; font-weight: 500;">Kelola Materi →</a>
            </div>
        </div>
    </div>

    <!-- Aksi Cepat (gaya admin) -->
    <div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 6px;">
        <div style="padding: 16px 20px; background: #f9fafb; border-bottom: 1px solid #e5e7eb; border-radius: 6px 6px 0 0;">
            <h3 style="margin: 0; font-size: 16px; font-weight: 600; color: #1f2937; display: flex; align-items: center; gap: 8px;">
                <iconify-icon icon="material-symbols:menu-open" style="font-size: 20px; color: #059669;"></iconify-icon>
                Aksi Cepat
            </h3>
        </div>
        <div style="padding: 20px;">
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px;">
                <?php if (!$today_attendance): ?>
                <a href="absensi.php" style="border: 1px solid #e5e7eb; border-radius: 6px; padding: 16px; text-decoration: none; color: #374151; transition: all 0.2s;" onmouseover="this.style.borderColor='#059669'; this.style.background='#f0fdf4';" onmouseout="this.style.borderColor='#e5e7eb'; this.style.background='white';">
                    <iconify-icon icon="material-symbols:how-to-reg-outline" style="font-size: 24px; color: #059669; margin-bottom: 8px;"></iconify-icon>
                    <div style="font-size: 14px; font-weight: 600;">Absensi Hari Ini</div>
                </a>
                <?php endif; ?>
                <a href="jadwal.php" style="border: 1px solid #e5e7eb; border-radius: 6px; padding: 16px; text-decoration: none; color: #374151; transition: all 0.2s;" onmouseover="this.style.borderColor='#2563eb'; this.style.background='#f0f9ff';" onmouseout="this.style.borderColor='#e5e7eb'; this.style.background='white';">
                    <iconify-icon icon="material-symbols:calendar-month-outline" style="font-size: 24px; color: #2563eb; margin-bottom: 8px;"></iconify-icon>
                    <div style="font-size: 14px; font-weight: 600;">Lihat Jadwal</div>
                </a>
                <a href="materi/index.php" style="border: 1px solid #e5e7eb; border-radius: 6px; padding: 16px; text-decoration: none; color: #374151; transition: all 0.2s;" onmouseover="this.style.borderColor='#8b5cf6'; this.style.background='#f5f3ff';" onmouseout="this.style.borderColor='#e5e7eb'; this.style.background='white';">
                    <iconify-icon icon="material-symbols:folder-outline" style="font-size: 24px; color: #8b5cf6; margin-bottom: 8px;"></iconify-icon>
                    <div style="font-size: 14px; font-weight: 600;">Kelola Materi</div>
                </a>
                <a href="profil.php" style="border: 1px solid #e5e7eb; border-radius: 6px; padding: 16px; text-decoration: none; color: #374151; transition: all 0.2s;" onmouseover="this.style.borderColor='#10b981'; this.style.background='#ecfdf5';" onmouseout="this.style.borderColor='#e5e7eb'; this.style.background='white';">
                    <iconify-icon icon="material-symbols:person-outline" style="font-size: 24px; color: #10b981; margin-bottom: 8px;"></iconify-icon>
                    <div style="font-size: 14px; font-weight: 600;">Edit Profil</div>
                </a>
            </div>
        </div>
    </div>
            </div>
        </div>
    </div>

<style>
@media (max-width: 768px) {
    .main-content > div:last-child {
        grid-template-columns: 1fr !important;
    }
    
    .main-content > div:nth-child(4) {
        grid-template-columns: 1fr !important;
    }
}
</style>

   
</body>
</html>
