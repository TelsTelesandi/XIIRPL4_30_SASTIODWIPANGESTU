<?php
session_start();
include "../config/database.php";

// Check if user is logged in and is instructor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'instruktur') {
    header("Location: ../login.php");
    exit;
}

$instruktur_id = $_SESSION['instruktur_id'] ?? 0;

// Get instructor data
$instruktur_query = mysqli_query($conn, "SELECT * FROM instruktur WHERE instruktur_id = '$instruktur_id'");
$instruktur_data = mysqli_fetch_assoc($instruktur_query);

// Get current month and year
$current_month = isset($_GET['month']) ? (int)$_GET['month'] : date('n');
$current_year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');

// Validate month and year
if ($current_month < 1 || $current_month > 12) $current_month = date('n');
if ($current_year < 2020 || $current_year > 2030) $current_year = date('Y');

// Get schedules for the current month (only past)
$start_date = "$current_year-" . sprintf('%02d', $current_month) . "-01";
$end_date = date('Y-m-t', strtotime($start_date));

$schedules_query = "SELECT j.*, k.nama_kelas, k.deskripsi, j.ruang 
                   FROM jadwal j 
                   LEFT JOIN kelas k ON j.kelas_id = k.kelas_id 
                   WHERE j.instruktur_id = '$instruktur_id' 
                   AND j.tanggal BETWEEN '$start_date' AND '$end_date'
                   AND (
                        j.tanggal < CURDATE()
                        OR (j.tanggal = CURDATE() AND j.jam_selesai < CURTIME())
                   )
                   ORDER BY j.tanggal DESC, j.jam_mulai ASC";

$schedules_result = mysqli_query($conn, $schedules_query);

// Organize schedules by date
$schedules_by_date = [];
while ($schedule = mysqli_fetch_assoc($schedules_result)) {
    $date = $schedule['tanggal'];
    if (!isset($schedules_by_date[$date])) {
        $schedules_by_date[$date] = [];
    }
    $schedules_by_date[$date][] = $schedule;
}

// Get month name in Indonesian
$month_names = [
    1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
    5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
    9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
];

// Calculate previous and next month
$prev_month = $current_month - 1;
$prev_year = $current_year;
if ($prev_month < 1) {
    $prev_month = 12;
    $prev_year--;
}

$next_month = $current_month + 1;
$next_year = $current_year;
if ($next_month > 12) {
    $next_month = 1;
    $next_year++;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Jadwal - Portal Instruktur BBPVP</title>
    <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        :root {
            --brand: #0ea5a5;
            --bg: #f8fafc;
            --surface: #ffffff;
            --text: #0f172a;
            --muted: #64748b;
            --light-muted: #94a3b8;
            --border: #e2e8f0;
            --radius: 16px;
            --sidebar-w: 280px;
            --content-gap: 48px;
            --card-gap: 32px;
        }

        * { box-sizing: border-box; }
        html, body { height: 100%; }
        body {
            font-family: 'Inter', system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
            background: var(--bg);
            color: var(--text);
            line-height: 1.6;
        }

        .schedule-page {
            margin-left: calc(var(--sidebar-w) + var(--content-gap));
            padding: 32px 24px;
            max-width: 1200px;
            margin-right: 24px;
        }

        @media (max-width: 992px) {
            .schedule-page { 
                margin-left: 0; 
                margin-right: 0;
                padding: 20px 16px; 
            }
        }

        .toolbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 24px;
            flex-wrap: wrap;
            margin-bottom: 32px;
        }
        
        .title-wrap {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        
        .title-chip {
            background: rgba(148,163,184,0.18);
            color: #111827;
            border: 1px solid rgba(148,163,184,0.6);
            border-radius: 999px;
            padding: 8px 14px;
            font-weight: 600;
            font-size: 13px;
            letter-spacing: 0.025em;
        }
        
        .page-title {
            font-size: 32px;
            font-weight: 800;
            letter-spacing: -0.025em;
            color: var(--text);
        }

        .toolbar-actions {
            display: flex;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
        }
        
        .btn, .nav-btn {
            appearance: none;
            border: 1px solid var(--border);
            background: var(--surface);
            color: var(--text);
            border-radius: 12px;
            padding: 10px 16px;
            font-weight: 600;
            font-size: 14px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease;
            box-shadow: 0 1px 3px rgba(0,0,0,0.04);
        }
        
        .btn:hover, .nav-btn:hover {
            border-color: var(--brand);
            box-shadow: 0 4px 16px rgba(14,165,165,0.12);
            transform: translateY(-1px);
        }
        
        .btn.primary {
            background: var(--brand);
            color: white;
            border-color: var(--brand);
        }

        .month {
            min-width: 200px;
            text-align: center;
            font-weight: 700;
            font-size: 16px;
        }

        .breadcrumb {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--muted);
            font-size: 14px;
            margin-bottom: 16px;
        }
        .breadcrumb a { 
            color: var(--brand); 
            font-weight: 600; 
            text-decoration: none;
            transition: color 0.2s ease;
        }
        .breadcrumb a:hover {
            color: #0891b2;
        }

        .card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: 0 4px 24px rgba(0,0,0,0.04);
            overflow: hidden;
        }

        .schedule-list {
            display: flex;
            flex-direction: column;
            gap: var(--card-gap);
            padding: 24px;
        }

        .schedule-date-group {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .date-header {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 18px 20px;
            border-radius: 14px;
            background: #f1f5f9;
            border: 1px solid var(--border);
            box-shadow: 0 1px 3px rgba(0,0,0,0.04);
        }
        
        .date-number {
            min-width: 48px; 
            height: 48px;
            display: grid; 
            place-items: center;
            font-weight: 800; 
            font-size: 18px;
            border-radius: 12px;
            background: #e5e7eb; 
            color: #374151;
            border: 1px solid rgba(148,163,184,0.8);
        }

        .date-info h3 {
            margin: 0;
            font-size: 16px;
            font-weight: 700;
            color: var(--text);
        }

        .date-info p {
            margin: 2px 0 0 0;
            font-size: 14px;
            color: var(--muted);
        }

        .schedule-items {
            display: flex;
            flex-direction: column;
            gap: 16px;
            margin-left: 64px;
        }

        .schedule-item {
            background: #f9fafb;
            border: 1px solid #e5e7eb;
            border-radius: 14px;
            padding: 20px;
            box-shadow: 0 1px 4px rgba(15,23,42,0.04);
            transition: all 0.2s ease;
            opacity: 0.9;
        }
        
        .schedule-item:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(15,23,42,0.08);
        }

        .schedule-item.past {
            background: #f9fafb;
            border-style: dashed;
        }

        .schedule-header { 
            display: flex; 
            justify-content: space-between; 
            align-items: flex-start;
            gap: 20px; 
            margin-bottom: 12px;
        }

        .schedule-content {
            flex: 1;
            min-width: 0;
        }
        
        .schedule-title { 
            font-weight: 700; 
            font-size: 18px; 
            margin: 0 0 6px 0;
            color: #111827;
            line-height: 1.4;
        }

        .badge-time {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            height: 32px;
            min-width: 120px;
            max-width: 140px;
            padding: 0 12px;
            border-radius: 999px;
            background: #4b5563;
            color: white;
            font-weight: 600;
            font-size: 13px;
            flex-shrink: 0;
            letter-spacing: 0.025em;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 600;
            letter-spacing: 0.04em;
            text-transform: uppercase;
            background: rgba(55,65,81,0.12);
            color: #4b5563;
        }

        .schedule-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 16px;
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid #e5e7eb;
        }

        .meta-item {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 13px;
            color: var(--muted);
            font-weight: 500;
        }

        .empty-state {
            text-align: center;
            padding: 80px 24px;
            color: var(--light-muted);
        }

        .empty-title {
            font-size: 20px;
            font-weight: 700;
            color: var(--muted);
            margin-bottom: 8px;
        }

        .empty-state > div:last-child {
            font-size: 14px;
            color: var(--light-muted);
        }

        @media (max-width: 1024px) {
            .main-content.schedule-page {
                margin-left: calc(var(--sidebar-w, 280px) + 24px) !important;
                margin-right: 16px !important;
            }
        }

        @media (max-width: 768px) {
            .main-content.schedule-page {
                margin-left: 0 !important;
                margin-right: 0 !important;
                padding: 16px !important;
            }
            
            .toolbar {
                flex-direction: column;
                align-items: stretch;
                gap: 20px;
            }
            
            .toolbar-actions { 
                justify-content: space-between; 
            }
            
            .schedule-items {
                margin-left: 0;
            }
            
            .schedule-header {
                flex-direction: column;
                gap: 16px;
                align-items: stretch;
            }
            
            .badge-time { 
                align-self: flex-start;
                min-width: auto;
                height: 32px;
            }
            
            .schedule-meta {
                flex-direction: column;
                gap: 12px;
            }
        }

        @media (max-width: 480px) {
            .date-header {
                padding: 14px 16px;
            }
            .schedule-item {
                padding: 16px;
            }
            .page-title {
                font-size: 28px;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-logo">
            <img src="../assets/images/logo-bbpvp.png" alt="BBPVP Bekasi" class="logo-img">
            <div class="header-text">
                <h1>Instruktur Balai Besar Pelatihan Vokasi dan Produktivitas Bekasi</h1>
                <span>Kementerian Ketenagakerjaan Republik Indonesia</span>
            </div>
        </div>
        <div class="header-user">
            <span class="user-info">
                <iconify-icon icon="material-symbols:person-outline" style="margin-right: 6px;"></iconify-icon>
                <?= htmlspecialchars($instruktur_data['nama_instruktur'] ?? 'Instruktur') ?>
            </span>
            <a href="../logout.php" class="logout-btn">
                <iconify-icon icon="material-symbols:logout"></iconify-icon>
                Logout
            </a>
        </div>
    </header>
    <div class="container">
        <?php include "../includes/instructor_sidebar.php"; ?>

        <main class="main-content schedule-page">
            <nav class="breadcrumb">
                <a href="dashboard.php">Dashboard</a>
                <span>›</span>
                <span>History Jadwal</span>
            </nav>

            <div class="toolbar">
                <div class="title-wrap">
                    <span class="title-chip">Instruktur</span>
                    <h1 class="page-title">History Jadwal Mengajar</h1>
                </div>
                <div class="toolbar-actions">
                    <a class="nav-btn" href="?month=<?= $prev_month ?>&year=<?= $prev_year ?>">‹</a>
                    <div class="month"><?= $month_names[$current_month] ?> <?= $current_year ?></div>
                    <a class="nav-btn" href="?month=<?= $next_month ?>&year=<?= $next_year ?>">›</a>
                    <a class="btn" href="jadwal.php">
                        <iconify-icon icon="material-symbols:calendar-month-outline"></iconify-icon>
                        Jadwal Aktif
                    </a>
                </div>
            </div>

            <section class="card">
                <?php if (empty($schedules_by_date)): ?>
                    <div class="empty-state">
                        <div class="empty-title">Belum Ada History Jadwal</div>
                        <div>Tidak ada jadwal yang sudah lewat untuk bulan <?= $month_names[$current_month] ?> <?= $current_year ?></div>
                    </div>
                <?php else: ?>
                    <div class="schedule-list">
                        <?php foreach ($schedules_by_date as $date => $schedules): ?>
                            <?php
                            $date_obj = new DateTime($date);
                            $day_names = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
                            $day_name = $day_names[$date_obj->format('w')];
                            ?>
                            <div class="schedule-date-group">
                                <div class="date-header">
                                    <div class="date-number"><?= $date_obj->format('d') ?></div>
                                    <div class="date-info">
                                        <h3><?= $day_name ?></h3>
                                        <p><?= $date_obj->format('d') ?> <?= $month_names[(int)$date_obj->format('n')] ?> <?= $date_obj->format('Y') ?></p>
                                    </div>
                                </div>
                                <div class="schedule-items">
                                    <?php foreach ($schedules as $schedule): ?>
                                        <div class="schedule-item past">
                                            <div class="schedule-header">
                                                <div class="schedule-content">
                                                    <h4 class="schedule-title">
                                                        <?= htmlspecialchars($schedule['nama_kelas'] ?: 'Kelas Tidak Diketahui') ?>
                                                    </h4>
                                                    <span class="status-badge">
                                                        Selesai
                                                    </span>
                                                </div>
                                                <span class="badge-time">
                                                    <?= date('H:i', strtotime($schedule['jam_mulai'])) ?> - <?= date('H:i', strtotime($schedule['jam_selesai'])) ?>
                                                </span>
                                            </div>
                                            <div class="schedule-meta">
                                                <?php if (isset($schedule['ruangan']) && $schedule['ruangan']): ?>
                                                    <span class="meta-item">📍 <?= htmlspecialchars($schedule['ruangan']) ?></span>
                                                <?php endif; ?>
                                                <span class="meta-item">👥 Kelas <?= htmlspecialchars($schedule['nama_kelas'] ?: 'Tidak Diketahui') ?></span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>
        </main>

        <script>
            (function() {
                const root = document.documentElement;
                function setSidebarWidth() {
                    const sidebar = document.querySelector('.sidebar');
                    if (sidebar) root.style.setProperty('--sidebar-w', sidebar.offsetWidth + 'px');
                }
                setSidebarWidth();
                window.addEventListener('resize', setSidebarWidth);
            })();
        </script>
    </div>
</body>
</html>


