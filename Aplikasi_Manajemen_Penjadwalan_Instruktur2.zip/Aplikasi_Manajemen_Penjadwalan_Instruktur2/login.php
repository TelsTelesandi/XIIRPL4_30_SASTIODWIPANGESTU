<?php
session_start();
include "config/database.php";
include "config/app.php";

if (isset($_POST['login'])) {
    // Ambil input & sanitasi
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Query pakai prepared statement
    $stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE username = ?");
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user['password'])) {
        // Simpan data ke session
        $_SESSION['user_id']  = $user['user_id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role']     = $user['role'];

        if ($user['role'] == 'instruktur') {
            $instruktur_stmt = mysqli_prepare($conn, "SELECT instruktur_id FROM instruktur WHERE user_id = ?");
            mysqli_stmt_bind_param($instruktur_stmt, "i", $user['user_id']);
            mysqli_stmt_execute($instruktur_stmt);
            $instruktur_result = mysqli_stmt_get_result($instruktur_stmt);
            $instruktur_data = mysqli_fetch_assoc($instruktur_result);
            
            if ($instruktur_data) {
                $_SESSION['instruktur_id'] = $instruktur_data['instruktur_id'];
            }
        }

        // Redirect sesuai role
        if ($user['role'] == 'admin') {
            header('Location: ' . app_url('admin/dashboard.php'));
        } else {
            header('Location: ' . app_url('instruktur/dashboard.php'));
        }
        exit;
    } else {
        $error = "Username atau password salah!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Manajemen Penjadwalan BBPVP</title>
    <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* Updated login page styling to use green theme instead of orange */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #059669 0%, #0d9488 50%, #14b8a6 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .login-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(5, 150, 105, 0.3);
            width: 100%;
            max-width: 400px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .login-header {
            text-align: center;
            margin-bottom: 32px;
        }

        .login-header .logo {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #10b981, #059669);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            color: white;
            font-size: 32px;
            box-shadow: 0 8px 25px rgba(16, 185, 129, 0.3);
            overflow: hidden;
        }

        /* Updated logo image styling for better display */
        .login-header .logo img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            border-radius: 16px;
            background: white;
            padding: 8px;
        }

        .login-header .logo .default-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            height: 100%;
        }

        .login-header h1 {
            font-size: 24px;
            font-weight: 800;
            color: #1f2937;
            margin-bottom: 8px;
        }

        .login-header p {
            color: #6b7280;
            font-size: 14px;
            font-weight: 500;
        }

        .error-message {
            background: linear-gradient(135deg, #fef2f2, #fee2e2);
            color: #dc2626;
            padding: 12px 16px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-size: 14px;
            border: 2px solid #f87171;
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-weight: 600;
            color: #374151;
            margin-bottom: 6px;
            font-size: 14px;
        }

        .form-group input {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #bbf7d0;
            border-radius: 12px;
            font-size: 14px;
            transition: all 0.3s ease;
            background: #ffffff;
        }

        .form-group input:focus {
            outline: none;
            border-color: #059669;
            box-shadow: 0 0 0 3px rgba(5, 150, 105, 0.1);
            transform: translateY(-1px);
        }

        .login-button {
            width: 100%;
            background: linear-gradient(135deg, #059669, #0d9488);
            color: white;
            border: none;
            padding: 14px 16px;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .login-button:hover {
            background: linear-gradient(135deg, #047857, #0f766e);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(5, 150, 105, 0.4);
        }

        .login-footer {
            text-align: center;
            margin-top: 24px;
            padding-top: 24px;
            border-top: 2px solid #bbf7d0;
            color: #6b7280;
            font-size: 12px;
            font-weight: 500;
        }

        /* Updated Kemnaker branding elements to use green theme */
        .kemnaker-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: linear-gradient(135deg, #f0fdf4, #dcfce7);
            color: #047857;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            border: 1px solid #bbf7d0;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <div class="logo">
                <?php 
                $logoPath = "assets/images/logo-bbpvp.png";
                $logoExists = file_exists($logoPath);
                
                // Add cache busting parameter to force reload
                $logoUrl = $logoPath . "?v=" . time();
                
                if ($logoExists): 
                ?>
                    <img src="<?= $logoUrl ?>" alt="Logo BBPVP Bekasi" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                    <div class="default-icon" style="display: none;">
                        <iconify-icon icon="material-symbols:work-outline"></iconify-icon>
                    </div>
                <?php else: ?>
                    <div class="default-icon">
                        <iconify-icon icon="material-symbols:work-outline"></iconify-icon>
                    </div>
                <?php endif; ?>
            </div>
            <h1>BBPVP Bekasi</h1>
            <p>Sistem Manajemen Penjadwalan Instruktur & Kelas Pelatihan</p>
            <div class="kemnaker-badge">
                <iconify-icon icon="material-symbols:verified-outline"></iconify-icon>
                Kementerian Ketenagakerjaan Republik Indonesia
            </div>
        </div>

        <?php if (isset($error)) : ?>
            <div class="error-message">
                <iconify-icon icon="material-symbols:error-outline"></iconify-icon>
                <?= $error; ?>
            </div>
        <?php endif; ?>

        <form method="post" action="">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" placeholder="Masukkan username" required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Masukkan password" required>
            </div>

            <button type="submit" name="login" class="login-button">
                <iconify-icon icon="material-symbols:login"></iconify-icon>
                Masuk
            </button>
        </form>

        <div class="login-footer">
            © 2025 BBPVP Bekasi - Kementerian Ketenagakerjaan <br>
            Sastio Dwi Pangestu - Telesandi Vocational School
        </div>
    </div>
</body>
</html>
