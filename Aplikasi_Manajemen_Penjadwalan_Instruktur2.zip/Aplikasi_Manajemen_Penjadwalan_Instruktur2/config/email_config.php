<?php
// Email configuration
define('ADMIN_EMAIL', 'sastiodwipangestu@gmail.com');
define('SMTP_HOST', ''); // Set if using SMTP
define('SMTP_PORT', 587); // Set if using SMTP
define('SMTP_USERNAME', ''); // Set if using SMTP
define('SMTP_PASSWORD', ''); // Set if using SMTP

// Function to send email
function sendContactEmail($name, $email, $subject, $message) {
    $to = ADMIN_EMAIL;
    $email_subject = "Kontak BBPVP: " . $subject;
    $email_body = "Dari: $name\n";
    $email_body .= "Email: $email\n\n";
    $email_body .= "Pesan:\n$message";
    $headers = "From: $email\r\n";
    $headers .= "Reply-To: $email\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    
    // Try to send email
    $mail_sent = mail($to, $email_subject, $email_body, $headers);
    
    if ($mail_sent) {
        return ['status' => 'success', 'message' => 'Terima kasih! Pesan Anda telah berhasil dikirim.'];
    } else {
        // Log error for debugging
        error_log("Mail sending failed: To=$to, Subject=$email_subject");
        return ['status' => 'error', 'message' => 'Maaf, terjadi kesalahan saat mengirim pesan. Silakan coba lagi.'];
    }
}
?>