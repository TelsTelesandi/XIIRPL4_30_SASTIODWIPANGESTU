<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_manajemen_penjadwalan_bbpvp";

$conn = mysqli_connect($host, $user, $pass, $db);

if ($conn) {
    echo "Koneksi BERHASIL ke database: $db";
} else {
    echo "Koneksi GAGAL: " . mysqli_connect_error();
}
?>
