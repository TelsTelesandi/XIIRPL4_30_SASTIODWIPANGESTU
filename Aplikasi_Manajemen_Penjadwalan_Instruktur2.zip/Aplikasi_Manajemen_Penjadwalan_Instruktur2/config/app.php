<?php
// Penentuan base path aplikasi otomatis relatif terhadap DocumentRoot.
// Bisa dioverride dengan mendefinisikan APP_BASE lebih dulu (mis. via .env/constant).
if (!defined('APP_BASE') || APP_BASE === '') {
	$docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? realpath($_SERVER['DOCUMENT_ROOT']) : null;
	// Folder project = satu level di atas file ini (../)
	$projectRoot = realpath(__DIR__ . '/..');
	if ($docRoot && $projectRoot) {
		$docRoot = str_replace('\\', '/', $docRoot);
		$projectRoot = str_replace('\\', '/', $projectRoot);
		$rel = str_replace($docRoot, '', $projectRoot);
		$rel = '/' . ltrim($rel, '/');
		define('APP_BASE', rtrim($rel, '/'));
	} else {
		// Fallback: sesuaikan manual jika perlu
		define('APP_BASE', '/Aplikasi_Manajemen_Penjadwalan_Instruktur2');
	}
}

if (!function_exists('app_url')) {
	function app_url(string $path = '/'): string {
		$normalized = '/' . ltrim($path, '/');
		return (APP_BASE === '' ? '' : rtrim(APP_BASE, '/')) . $normalized;
	}
}
?>


