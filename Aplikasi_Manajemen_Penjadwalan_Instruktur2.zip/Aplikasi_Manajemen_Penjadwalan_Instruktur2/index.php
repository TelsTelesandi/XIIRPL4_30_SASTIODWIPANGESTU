<?php
// Redirect ke halaman login
// Alih-alih redirect ke login.php, sekarang kita include home.php
require_once __DIR__ . '/home.php';
exit();
?>
