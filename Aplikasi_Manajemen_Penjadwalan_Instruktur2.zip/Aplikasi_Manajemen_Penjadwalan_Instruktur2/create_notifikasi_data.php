<?php
include "config/database.php";

echo "<h1>Create Sample Notifikasi Data</h1>";

// Check if we have absensi data with Izin, Sakit, Alfa
$result = mysqli_query($conn, "SELECT a.*, i.nama_instruktur 
                               FROM absensi a 
                               JOIN instruktur i ON a.instruktur_id = i.instruktur_id 
                               WHERE a.status IN ('Izin', 'Sakit', 'Alfa') 
                               ORDER BY a.tanggal DESC");

if ($result && mysqli_num_rows($result) > 0) {
    echo "<h2>Found " . mysqli_num_rows($result) . " absensi records with Izin/Sakit/Alfa</h2>";
    
    while ($row = mysqli_fetch_assoc($result)) {
        // Check if notifikasi already exists for this absensi
        $check_sql = "SELECT COUNT(*) as count FROM notifikasi WHERE absensi_id = " . $row['absensi_id'];
        $check_result = mysqli_query($conn, $check_sql);
        $check_row = mysqli_fetch_assoc($check_result);
        
        if ($check_row['count'] == 0) {
            // Create notifikasi
            $insert_sql = "INSERT INTO notifikasi (absensi_id, status_notifikasi, keterangan, is_read, created_at) 
                          VALUES (" . $row['absensi_id'] . ", '" . $row['status'] . "', 
                                  'Instruktur " . $row['nama_instruktur'] . " " . strtolower($row['status']) . " pada " . date('d-m-Y', strtotime($row['tanggal'])) . "', 
                                  0, NOW())";
            
            if (mysqli_query($conn, $insert_sql)) {
                echo "<p>✓ Created notifikasi for " . $row['nama_instruktur'] . " - " . $row['status'] . " on " . $row['tanggal'] . "</p>";
            } else {
                echo "<p>✗ Error creating notifikasi: " . mysqli_error($conn) . "</p>";
            }
        } else {
            echo "<p>→ Notifikasi already exists for " . $row['nama_instruktur'] . " - " . $row['status'] . " on " . $row['tanggal'] . "</p>";
        }
    }
} else {
    echo "<h2>No absensi records found with Izin/Sakit/Alfa</h2>";
    echo "<p>Creating sample data...</p>";
    
    // Get first instruktur
    $instruktur_result = mysqli_query($conn, "SELECT instruktur_id, nama_instruktur FROM instruktur LIMIT 1");
    if ($instruktur_result && mysqli_num_rows($instruktur_result) > 0) {
        $instruktur = mysqli_fetch_assoc($instruktur_result);
        
        // Create sample absensi
        $absensi_sql = "INSERT INTO absensi (instruktur_id, tanggal, status, keterangan) 
                       VALUES (" . $instruktur['instruktur_id'] . ", CURDATE(), 'Izin', 'Sample izin data')";
        
        if (mysqli_query($conn, $absensi_sql)) {
            $absensi_id = mysqli_insert_id($conn);
            
            // Create corresponding notifikasi
            $notifikasi_sql = "INSERT INTO notifikasi (absensi_id, status_notifikasi, keterangan, is_read, created_at) 
                              VALUES ($absensi_id, 'Izin', 'Instruktur " . $instruktur['nama_instruktur'] . " izin hari ini', 0, NOW())";
            
            if (mysqli_query($conn, $notifikasi_sql)) {
                echo "<p>✓ Created sample absensi and notifikasi for " . $instruktur['nama_instruktur'] . "</p>";
            } else {
                echo "<p>✗ Error creating notifikasi: " . mysqli_error($conn) . "</p>";
            }
        } else {
            echo "<p>✗ Error creating absensi: " . mysqli_error($conn) . "</p>";
        }
    } else {
        echo "<p>No instruktur found in database</p>";
    }
}

echo "<h2>Final Check:</h2>";
$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM notifikasi");
if ($result) {
    $row = mysqli_fetch_assoc($result);
    echo "<p>Total notifikasi now: " . $row['count'] . "</p>";
}

echo "<p><a href='notifikasi.php'>Go to Notifikasi Page</a></p>";
?>
