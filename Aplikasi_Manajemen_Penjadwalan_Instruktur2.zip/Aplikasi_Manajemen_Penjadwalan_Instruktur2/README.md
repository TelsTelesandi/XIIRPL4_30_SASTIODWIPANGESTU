# Aplikasi Manajemen Penjadwalan Instruktur dan Kelas Pelatihan

Aplikasi web untuk mengelola penjadwalan instruktur dan kelas pelatihan dengan sistem absensi otomatis dan notifikasi real-time.

## 🚀 Fitur Utama

### 👨‍💼 Role Admin
- **Dashboard** - Ringkasan data dan grafik kehadiran
- **Kelola Instruktur** - CRUD data instruktur
- **Kelola Kelas** - CRUD data kelas pelatihan
- **Kelola Jadwal** - Penjadwalan kelas dan instruktur
- **Pemantauan Absensi** - Monitoring kehadiran real-time
- **Laporan** - Cetak laporan absensi dan jadwal
- **Pengaturan** - Konfigurasi sistem dan reset password

### 👨‍🏫 Role Instruktur
- **Form Absensi Otomatis** - Input kehadiran berdasarkan jadwal
- **Riwayat Absensi** - Lihat history kehadiran
- **Upload Materi** - Upload file PDF/DOCX kelas
- **Edit Profil** - Update data pribadi dan password

## 🗄️ Struktur Database

Database: `db_manajemen_penjadwalan_bbpvp`

### Tabel Utama:
1. **users** - Data login dan role
2. **instruktur** - Data detail instruktur
3. **kelas** - Data kelas pelatihan
4. **jadwal** - Penjadwalan kelas + instruktur
5. **absensi** - Form absensi instruktur
6. **materi** - Upload materi kelas
7. **notifikasi** - Notifikasi izin/sakit/alfa
8. **laporan** - Arsip laporan admin

## 🛠️ Teknologi yang Digunakan

- **Backend**: PHP 7.4+
- **Database**: MySQL 5.7+
- **Frontend**: Bootstrap 5, Chart.js
- **Icons**: Font Awesome 6
- **Server**: Apache/Nginx

## 📋 Persyaratan Sistem

- PHP 7.4 atau lebih tinggi
- MySQL 5.7 atau lebih tinggi
- Web server (Apache/Nginx)
- Ekstensi PHP: PDO, PDO_MySQL

## 🚀 Cara Install

### 1. Clone Repository
```bash
git clone [url-repository]
cd aplikasi-manajemen-penjadwalan
```

### 2. Setup Database
- Buat database MySQL dengan nama `db_manajemen_penjadwalan_bbpvp`
- Import struktur database dari file SQL yang disediakan
- Atau jalankan query CREATE TABLE yang ada di dokumentasi

### 3. Konfigurasi Database
Edit file `config/database.php`:
```php
$host = 'localhost';
$dbname = 'db_manajemen_penjadwalan_bbpvp';
$username = 'root';  // Sesuaikan dengan username MySQL Anda
$password = '';       // Sesuaikan dengan password MySQL Anda
```

### 4. Setup Web Server
- Pastikan folder aplikasi dapat diakses dari web server
- Set permission yang sesuai untuk folder uploads (jika ada)

### 5. Akses Aplikasi
- Buka browser dan akses URL aplikasi
- Login dengan kredensial default atau buat user baru

## 🔐 Default Login

### Admin
- Username: `admin`
- Password: `admin123`

### Instruktur
- Username: `instruktur1`
- Password: `instruktur123`

*Note: Ganti password default setelah login pertama kali*

## 📱 Alur Sistem

### Login
1. User input username & password
2. Sistem cek role (admin/instruktur)
3. Redirect sesuai role

### Admin Flow
1. Dashboard dengan statistik
2. Kelola data (instruktur, kelas, jadwal)
3. Monitor absensi real-time
4. Generate laporan

### Instruktur Flow
1. Login → langsung ke form absensi
2. Sistem cek jadwal hari ini
3. Jika ada jadwal → tampilkan form
4. Submit absensi → data masuk database
5. Jika izin/sakit → admin dapat notifikasi

## 🔄 Fitur Khusus

### Sistem Notifikasi
- Otomatis notifikasi admin jika instruktur izin/sakit/alfa
- Real-time monitoring status kehadiran
- Badge notifikasi di dashboard admin

### Validasi Absensi
- Wajib alasan jika status Izin/Sakit
- Cek jadwal otomatis berdasarkan tanggal
- Riwayat absensi terbatas (10 terakhir)

### Keamanan
- Session management
- Role-based access control
- Password hashing
- SQL injection prevention

## 📊 Dashboard Admin

### Statistik Cards
- Total Instruktur
- Total Kelas
- Jadwal Mendatang
- Absensi Hari Ini

### Grafik Kehadiran
- Chart 7 hari terakhir
- Breakdown status: Hadir, Izin, Sakit, Alfa
- Visualisasi trend kehadiran

### Jadwal Terdekat
- List 5 jadwal mendatang
- Info kelas dan instruktur
- Tanggal dan jam pelaksanaan

## 🎯 Fitur CRUD

### Instruktur
- ✅ Tambah instruktur baru
- ✅ Edit data instruktur
- ✅ Hapus instruktur
- ✅ List semua instruktur

### Kelas
- ✅ Tambah kelas baru
- ✅ Edit data kelas
- ✅ Hapus kelas
- ✅ List semua kelas

### Jadwal
- ✅ Buat jadwal baru
- ✅ Edit jadwal
- ✅ Hapus jadwal
- ✅ List semua jadwal

## 📝 Format Data

### Tanggal
- Format input: YYYY-MM-DD
- Display: Format Indonesia (Senin, 1 Januari 2024)

### Jam
- Format: HH:MM (24 jam)
- Display: HH:MM

### Status Kehadiran
- Hadir (Hijau)
- Izin (Kuning)
- Sakit (Biru)
- Alfa (Merah)

## 🚨 Troubleshooting

### Error Koneksi Database
- Cek konfigurasi database.php
- Pastikan MySQL service running
- Cek username/password database

### Error Upload File
- Cek permission folder uploads
- Pastikan ekstensi file diizinkan
- Cek ukuran file maksimal

### Session Error
- Pastikan session_start() dipanggil
- Cek konfigurasi PHP session
- Restart web server jika perlu

## 📞 Support

Untuk bantuan teknis atau pertanyaan:
- Email: support@example.com
- Dokumentasi: [link-dokumentasi]
- Issue Tracker: [link-github-issues]

## 📄 License

Aplikasi ini dikembangkan untuk internal use. All rights reserved.

---

**Version**: 1.0.0  
**Last Updated**: Januari 2024  
**Developer**: Tim Development BBPVP

