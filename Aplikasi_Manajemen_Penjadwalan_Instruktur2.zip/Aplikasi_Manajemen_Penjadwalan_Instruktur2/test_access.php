<?php
// Test file untuk memastikan semua halaman bisa diakses
session_start();
include "config/database.php";

echo "<h1>Test Akses Halaman Instruktur</h1>";

// Test database connection
if ($conn) {
    echo "<p style='color: green;'>✓ Database connection: OK</p>";
} else {
    echo "<p style='color: red;'>✗ Database connection: FAILED</p>";
}

// Test file existence and permissions
$test_files = [
    'instruktur/dashboard.php',
    'instruktur/riwayat.php',
    'instruktur/materi/index.php',
    'instruktur/materi/download.php',
    'instruktur/materi/upload.php',
    'instruktur/materi/hapus.php'
];

echo "<h2>File Access Test:</h2>";
foreach ($test_files as $file) {
    if (file_exists($file)) {
        if (is_readable($file)) {
            echo "<p style='color: green;'>✓ $file: EXISTS & READABLE</p>";
        } else {
            echo "<p style='color: orange;'>⚠ $file: EXISTS but NOT READABLE</p>";
        }
    } else {
        echo "<p style='color: red;'>✗ $file: NOT FOUND</p>";
    }
}

// Test upload directory
echo "<h2>Upload Directory Test:</h2>";
if (is_dir('uploads/materi')) {
    echo "<p style='color: green;'>✓ Upload directory: EXISTS</p>";
    if (is_writable('uploads/materi')) {
        echo "<p style='color: green;'>✓ Upload directory: WRITABLE</p>";
    } else {
        echo "<p style='color: red;'>✗ Upload directory: NOT WRITABLE</p>";
    }
} else {
    echo "<p style='color: red;'>✗ Upload directory: NOT FOUND</p>";
}

// Test .htaccess files
echo "<h2>Security Files Test:</h2>";
$htaccess_files = ['.htaccess', 'uploads/.htaccess', 'uploads/materi/.htaccess'];
foreach ($htaccess_files as $file) {
    if (file_exists($file)) {
        echo "<p style='color: green;'>✓ $file: EXISTS</p>";
    } else {
        echo "<p style='color: red;'>✗ $file: NOT FOUND</p>";
    }
}

// Test database tables
echo "<h2>Database Tables Test:</h2>";
$tables = ['instruktur', 'kelas', 'materi', 'absensi', 'jadwal'];
foreach ($tables as $table) {
    $result = mysqli_query($conn, "SHOW TABLES LIKE '$table'");
    if (mysqli_num_rows($result) > 0) {
        echo "<p style='color: green;'>✓ Table '$table': EXISTS</p>";
    } else {
        echo "<p style='color: red;'>✗ Table '$table': NOT FOUND</p>";
    }
}

// Test sample data
echo "<h2>Data Test:</h2>";
$instruktur_count = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM instruktur"));
$kelas_count = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM kelas"));
$materi_count = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM materi"));

echo "<p>Instruktur: $instruktur_count</p>";
echo "<p>Kelas: $kelas_count</p>";
echo "<p>Materi: $materi_count</p>";

// Test materi table structure
echo "<h2>Materi Table Structure:</h2>";
$result = mysqli_query($conn, "DESCRIBE materi");
if ($result) {
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . $row['Default'] . "</td>";
        echo "<td>" . $row['Extra'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>✗ Cannot describe materi table</p>";
}

echo "<h2>Test Links:</h2>";
echo "<p><a href='login.php'>Login Page</a></p>";
echo "<p><a href='instruktur/dashboard.php'>Instruktur Dashboard</a></p>";
echo "<p><a href='instruktur/riwayat.php'>Riwayat Absensi</a></p>";
echo "<p><a href='instruktur/materi/index.php'>Kelola Materi</a></p>";
echo "<p><a href='admin/dashboard.php'>Admin Dashboard</a></p>";

echo "<h2>System Info:</h2>";
echo "<p>PHP Version: " . phpversion() . "</p>";
echo "<p>Current Time: " . date('Y-m-d H:i:s') . "</p>";
echo "<p>Server: " . $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown' . "</p>";
?>
