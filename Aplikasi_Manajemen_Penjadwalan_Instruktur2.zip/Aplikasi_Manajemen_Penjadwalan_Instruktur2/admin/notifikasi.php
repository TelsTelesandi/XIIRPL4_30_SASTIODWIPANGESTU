<?php
include "../config/database.php";

$bootstrap_pengajuan = "CREATE TABLE IF NOT EXISTS pengajuan_izin (
  pengajuan_id INT AUTO_INCREMENT PRIMARY KEY,
  instruktur_id INT NOT NULL,
  tanggal DATE NOT NULL,
  jenis ENUM('Izin','Sakit') NOT NULL,
  alasan TEXT NULL,
  lampiran VARCHAR(255) NULL,
  status ENUM('Diajukan','Disetujui','Ditolak','Dibatalkan') NOT NULL DEFAULT 'Diajukan',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  decided_at DATETIME NULL,
  decided_by INT NULL,
  INDEX (instruktur_id), INDEX (tanggal)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
mysqli_query($conn, $bootstrap_pengajuan);

// Fokus halaman: Pengajuan Izin/Sakit (notifikasi lama dihapus)

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $pengajuan_id = isset($_POST['pengajuan_id']) ? (int)$_POST['pengajuan_id'] : 0;
    
    if (($action == 'approve' || $action == 'reject') && $pengajuan_id > 0) {
        // Load pengajuan
        $p = mysqli_query($conn, "SELECT * FROM pengajuan_izin WHERE pengajuan_id=$pengajuan_id");
        $row = mysqli_fetch_assoc($p);
        if ($row) {
            $newStatus = $action == 'approve' ? 'Disetujui' : 'Ditolak';
            mysqli_query($conn, "UPDATE pengajuan_izin SET status='$newStatus', decided_at=NOW() WHERE pengajuan_id=$pengajuan_id");
            if ($action == 'approve') {
                // create absensi entry if not exists
                $instrukturId = (int)$row['instruktur_id'];
                $tanggal = mysqli_real_escape_string($conn, $row['tanggal']);
                $alasan = mysqli_real_escape_string($conn, (string)($row['alasan'] ?? ''));
                $jenis = mysqli_real_escape_string($conn, (string)$row['jenis']);
                $cek = mysqli_query($conn, "SELECT absensi_id FROM absensi WHERE instruktur_id='{$instrukturId}' AND tanggal='{$tanggal}' LIMIT 1");
                if ($cek && mysqli_num_rows($cek)==0) {
                    // cari jadwal_id pada tanggal tsb, fallback 0 jika tidak ada
                    $qJ = mysqli_query($conn, "SELECT jadwal_id FROM jadwal WHERE instruktur_id='{$instrukturId}' AND tanggal='{$tanggal}' LIMIT 1");
                    $jadwal_id = 0;
                    if ($qJ && ($j = mysqli_fetch_assoc($qJ))) {
                        $jadwal_id = (int)$j['jadwal_id'];
                    }
                    $hari = date('l', strtotime($row['tanggal']));
                    $map = ['Sunday'=>'Minggu','Monday'=>'Senin','Tuesday'=>'Selasa','Wednesday'=>'Rabu','Thursday'=>'Kamis','Friday'=>'Jumat','Saturday'=>'Sabtu'];
                    $hari_id = $map[$hari] ?? $hari;
                    mysqli_query($conn, "INSERT INTO absensi (jadwal_id, instruktur_id, tanggal, hari, status, alasan, waktu_absen) VALUES ({$jadwal_id}, '{$instrukturId}', '{$tanggal}', '$hari_id', '{$jenis}', '{$alasan}', NOW())");
                    $absensi_id = mysqli_insert_id($conn);
                    // create notifikasi (handle schema differences: keterangan/pesan/deskripsi optional)
                    $statusNotif = ($row['jenis'] === 'Izin') ? 'Izin' : (($row['jenis'] === 'Sakit') ? 'Sakit' : 'Alfa');
                    $ketNotif = 'Instruktur #' . $instrukturId . ' ' . strtolower($statusNotif) . ' pada ' . date('d-m-Y', strtotime($tanggal));
                    $ketCol = null;
                    if ($c = mysqli_query($conn, "SHOW COLUMNS FROM notifikasi LIKE 'keterangan'")) {
                        if (mysqli_num_rows($c) > 0) { $ketCol = 'keterangan'; }
                        mysqli_free_result($c);
                    }
                    if (!$ketCol && ($c = mysqli_query($conn, "SHOW COLUMNS FROM notifikasi LIKE 'pesan'"))) {
                        if (mysqli_num_rows($c) > 0) { $ketCol = 'pesan'; }
                        mysqli_free_result($c);
                    }
                    if (!$ketCol && ($c = mysqli_query($conn, "SHOW COLUMNS FROM notifikasi LIKE 'deskripsi'"))) {
                        if (mysqli_num_rows($c) > 0) { $ketCol = 'deskripsi'; }
                        mysqli_free_result($c);
                    }
                    if ($ketCol) {
                        $sqlNotif = sprintf(
                            "INSERT INTO notifikasi (absensi_id, status_notifikasi, %s, is_read, created_at) VALUES (?, ?, ?, 0, NOW())",
                            $ketCol
                        );
                        if ($stmtN = mysqli_prepare($conn, $sqlNotif)) {
                            $ketSafe = $ketNotif; // bound parameter handles escaping
                            mysqli_stmt_bind_param($stmtN, "iss", $absensi_id, $statusNotif, $ketSafe);
                            mysqli_stmt_execute($stmtN);
                            mysqli_stmt_close($stmtN);
                        }
                    } else {
                        // fallback without text column
                        if ($stmtN = mysqli_prepare($conn, "INSERT INTO notifikasi (absensi_id, status_notifikasi, is_read, created_at) VALUES (?, ?, 0, NOW())")) {
                            mysqli_stmt_bind_param($stmtN, "is", $absensi_id, $statusNotif);
                            mysqli_stmt_execute($stmtN);
                            mysqli_stmt_close($stmtN);
                        }
                    }
                }
            }
        }
    }
    
    // Refresh the page (pastikan belum ada output sebelum ini)
    header("Location: notifikasi.php");
    exit;
}
?>

<?php
// Masukkan header & sidebar setelah proses POST agar tidak terjadi "headers already sent"
include "../includes/header.php";
include "../includes/sidebar.php";
?>
<div class="content">
    <div class="dashboard-container fade-in">
        <div class="dashboard-header">
            <h2>
                <iconify-icon icon="material-symbols:assignment-ind"></iconify-icon>
                Pengajuan Izin/Sakit Instruktur
            </h2>
            <p class="dashboard-subtitle">Kelola Pengajuan Instruktur: Ajukan, Setujui, atau Tolak</p>
        </div>

        <!-- Pengajuan Izin/Sakit: Statistik dan Aksi -->
        <?php
            $qStats = mysqli_query($conn, "SELECT 
                COUNT(*) total,
                SUM(status='Diajukan') pending,
                SUM(status='Disetujui') approved,
                SUM(status='Ditolak') rejected,
                SUM(status='Dibatalkan') cancelled
            FROM pengajuan_izin");
            $pstats = mysqli_fetch_assoc($qStats) ?: ['pending'=>0,'approved'=>0,'rejected'=>0,'cancelled'=>0,'total'=>0];
            $plist = mysqli_query($conn, "SELECT p.*, i.nama_instruktur FROM pengajuan_izin p LEFT JOIN instruktur i ON i.instruktur_id=p.instruktur_id ORDER BY p.created_at DESC");
        ?>
        <div class="stats-grid" style="margin-top: 24px; gap: 20px;">
            <div class="stat-card" style="padding: 24px; margin-bottom: 16px;"><h3 style="margin-bottom: 12px;">Pengajuan Diajukan</h3><div class="stat-number"><?= (int)$pstats['pending'] ?></div></div>
            <div class="stat-card" style="padding: 24px; margin-bottom: 16px;"><h3 style="margin-bottom: 12px;">Disetujui</h3><div class="stat-number" style="color:#10b981;">
                <?= (int)$pstats['approved'] ?></div></div>
            <div class="stat-card" style="padding: 24px; margin-bottom: 16px;"><h3 style="margin-bottom: 12px;">Ditolak</h3><div class="stat-number" style="color:#ef4444;">
                <?= (int)$pstats['rejected'] ?></div></div>
        </div>

        <!-- Added more padding and margins to content card -->
        <div class="content-card" style="margin-top: 28px; padding: 28px;">
            <h3 style="margin-bottom: 20px; display:flex; align-items:center; gap:8px; font-size: 18px;">
                <iconify-icon icon="material-symbols:assignment-ind"></iconify-icon>
                Daftar Pengajuan Izin/Sakit
            </h3>
            <!-- Added padding and line-height to table for better spacing -->
            <table class="modern-table" style="border-collapse: collapse; width: 100%;">
                <thead>
                    <tr style="border-bottom: 3px solid #e5e7eb;">
                        <th style="padding: 16px 12px; text-align: left;">Instruktur</th>
                        <th style="padding: 16px 12px; text-align: left;">Tanggal</th>
                        <th style="padding: 16px 12px; text-align: left;">Jenis</th>
                        <th style="padding: 16px 12px; text-align: left;">Alasan</th>
                        <th style="padding: 16px 12px; text-align: left;">Lampiran</th>
                        <th style="padding: 16px 12px; text-align: left;">Status</th>
                        <th style="padding: 16px 12px; text-align: left;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($plist && mysqli_num_rows($plist) > 0): while($r=mysqli_fetch_assoc($plist)): ?>
                    <tr style="border-bottom: 1px solid #f0f0f0; transition: background 0.2s;">
                        <td style="padding: 16px 12px;"><?= htmlspecialchars($r['nama_instruktur'] ?? 'Instruktur') ?></td>
                        <td style="padding: 16px 12px;"><?= htmlspecialchars(date('d/m/Y', strtotime($r['tanggal']))) ?></td>
                        <td style="padding: 16px 12px;"><?= htmlspecialchars($r['jenis']) ?></td>
                        <td style="padding: 16px 12px; max-width: 200px; word-wrap: break-word;"><?= htmlspecialchars($r['alasan'] ?? '-') ?></td>
                        <td style="padding: 16px 12px;"><?php if(!empty($r['lampiran'])): ?><a target="_blank" href="../<?= $r['lampiran'] ?>" style="color: #3b82f6; text-decoration: none; font-weight: 500;">Lihat</a><?php else: ?>-<?php endif; ?></td>
                        <td style="padding: 16px 12px;">
                            <span style="padding: 6px 12px; border-radius: 6px; font-weight: 500; font-size: 13px; 
                            <?php 
                                if ($r['status']==='Diajukan') echo 'background: #fef3c7; color: #92400e;';
                                elseif ($r['status']==='Disetujui') echo 'background: #d1fae5; color: #065f46;';
                                elseif ($r['status']==='Ditolak') echo 'background: #fee2e2; color: #7f1d1d;';
                                else echo 'background: #e5e7eb; color: #374151;';
                            ?>">
                            <?= htmlspecialchars($r['status']) ?></span>
                        </td>
                        <td style="padding: 16px 12px;">
                            <?php if ($r['status']==='Diajukan'): ?>
                            <form method="post" style="display:inline-flex; gap:8px;">
                                <input type="hidden" name="pengajuan_id" value="<?= $r['pengajuan_id'] ?>">
                                <button class="btn btn-primary" name="action" value="approve" onclick="return confirm('Setujui pengajuan ini?')" style="padding: 8px 14px; font-size: 13px;">Setujui</button>
                                <button class="btn btn-danger" name="action" value="reject" onclick="return confirm('Tolak pengajuan ini?')" style="padding: 8px 14px; font-size: 13px;">Tolak</button>
                            </form>
                            <?php else: ?>-
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; else: ?>
                    <tr><td colspan="7" style="text-align:center; color:#6b7280; padding:32px;">Belum ada pengajuan</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Monitoring Kehadiran & Lokasi Hari Ini -->
        <?php
            $today = date('Y-m-d');
            $qAbsensiHariIni = mysqli_query(
                $conn,
                "SELECT a.*, i.nama_instruktur 
                 FROM absensi a 
                 LEFT JOIN instruktur i ON i.instruktur_id = a.instruktur_id
                 WHERE a.tanggal = CURDATE()
                 ORDER BY a.waktu_absen DESC"
            );
        ?>
        <div class="content-card" style="margin-top: 32px; padding: 28px;">
            <h3 style="margin-bottom: 20px; display:flex; align-items:center; gap:8px; font-size: 18px;">
                <iconify-icon icon="material-symbols:my-location"></iconify-icon>
                Monitoring Kehadiran & Lokasi 
            </h3>
            <table class="modern-table" style="border-collapse: collapse; width: 100%;">
                <thead>
                    <tr style="border-bottom: 3px solid #e5e7eb;">
                        <th style="padding: 16px 12px; text-align: left;">Instruktur</th>
                        <th style="padding: 16px 12px; text-align: left;">Tanggal</th>
                        <th style="padding: 16px 12px; text-align: left;">Waktu Absen</th>
                        <th style="padding: 16px 12px; text-align: left;">Status</th>
                        <th style="padding: 16px 12px; text-align: left;">Lokasi</th>
                        <th style="padding: 16px 12px; text-align: left;">Validasi Lokasi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($qAbsensiHariIni && mysqli_num_rows($qAbsensiHariIni) > 0): ?>
                        <?php while ($a = mysqli_fetch_assoc($qAbsensiHariIni)): ?>
                            <tr style="border-bottom: 1px solid #f0f0f0; transition: background 0.2s;">
                                <td style="padding: 16px 12px;"><?= htmlspecialchars($a['nama_instruktur'] ?? 'Instruktur') ?></td>
                                <td style="padding: 16px 12px;"><?= htmlspecialchars(date('d/m/Y', strtotime($a['tanggal']))) ?></td>
                                <td style="padding: 16px 12px;"><?= htmlspecialchars($a['waktu_absen'] ? date('H:i', strtotime($a['waktu_absen'])) : '-') ?></td>
                                <td style="padding: 16px 12px;"><?= htmlspecialchars($a['status'] ?? '-') ?></td>
                                <td style="padding: 16px 12px;">
                                    <?php if (!empty($a['latitude']) && !empty($a['longitude'])): ?>
                                        <?php $lat = (float)$a['latitude']; $lng = (float)$a['longitude']; ?>
                                        <div style="font-size: 13px; color:#4b5563;">
                                            Lat: <?= htmlspecialchars(number_format($lat, 6)) ?>,
                                            Lng: <?= htmlspecialchars(number_format($lng, 6)) ?><br>
                                            <a href="https://www.google.com/maps?q=<?= $lat ?>,<?= $lng ?>" target="_blank" style="color:#2563eb; text-decoration:none; font-weight:500;">
                                                Lihat di Google Maps
                                            </a>
                                        </div>
                                    <?php else: ?>
                                        <span style="font-size:13px; color:#9ca3af;">Tidak ada data lokasi</span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 16px 12px;">
                                    <?php
                                        $lokasiValid = (int)($a['lokasi_valid'] ?? 0);
                                        $jarak = isset($a['jarak_meter']) ? (int)$a['jarak_meter'] : null;
                                    ?>
                                    <?php if ($lokasiValid === 1): ?>
                                        <span style="padding: 6px 12px; border-radius: 999px; background:#d1fae5; color:#065f46; font-weight:600; font-size:12px;">
                                            Di dalam area
                                            <?php if ($jarak !== null): ?>
                                                (± <?= $jarak ?> m)
                                            <?php endif; ?>
                                        </span>
                                    <?php elseif (!empty($a['latitude']) && !empty($a['longitude'])): ?>
                                        <span style="padding: 6px 12px; border-radius: 999px; background:#fee2e2; color:#7f1d1d; font-weight:600; font-size:12px;">
                                            Di luar area
                                            <?php if ($jarak !== null): ?>
                                                (± <?= $jarak ?> m)
                                            <?php endif; ?>
                                        </span>
                                    <?php else: ?>
                                        <span style="padding: 6px 12px; border-radius: 999px; background:#e5e7eb; color:#374151; font-weight:500; font-size:12px;">
                                            Tidak diverifikasi
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align:center; color:#6b7280; padding:32px;">
                                Belum ada absensi hari ini.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>
</div>

<?php include "../includes/footer.php"; ?>
