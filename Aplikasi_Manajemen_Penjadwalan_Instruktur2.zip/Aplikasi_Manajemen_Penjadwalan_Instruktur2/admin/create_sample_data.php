<?php
include "config/database.php";

echo "<h1>Create Sample Data for Admin Dashboard</h1>";

// Check if we have any data
$instruktur_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM instruktur"))['count'];
$kelas_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM kelas"))['count'];
$jadwal_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM jadwal"))['count'];
$absensi_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM absensi"))['count'];

echo "<h2>Current Data Status:</h2>";
echo "<p>Instruktur: $instruktur_count</p>";
echo "<p>Kelas: $kelas_count</p>";
echo "<p>Jadwal: $jadwal_count</p>";
echo "<p>Absensi: $absensi_count</p>";

// Create sample instruktur if none exist
if ($instruktur_count == 0) {
    echo "<h2>Creating Sample Instruktur...</h2>";
    $instruktur_data = [
        ['nama_instruktur' => 'Dr. Ahmad Wijaya', 'email' => 'ahmad@example.com', 'no_hp' => '081234567890'],
        ['nama_instruktur' => 'Siti Nurhaliza', 'email' => 'siti@example.com', 'no_hp' => '081234567891'],
        ['nama_instruktur' => 'Budi Santoso', 'email' => 'budi@example.com', 'no_hp' => '081234567892']
    ];
    
    foreach ($instruktur_data as $data) {
        $sql = "INSERT INTO instruktur (nama_instruktur, email, no_hp, status) VALUES ('{$data['nama_instruktur']}', '{$data['email']}', '{$data['no_hp']}', 'aktif')";
        if (mysqli_query($conn, $sql)) {
            echo "<p>✓ Created instruktur: {$data['nama_instruktur']}</p>";
        } else {
            echo "<p>✗ Error creating instruktur: " . mysqli_error($conn) . "</p>";
        }
    }
}

// Create sample kelas if none exist
if ($kelas_count == 0) {
    echo "<h2>Creating Sample Kelas...</h2>";
    $kelas_data = [
        ['nama_kelas' => 'Pelatihan Digital Marketing', 'deskripsi' => 'Pelatihan pemasaran digital'],
        ['nama_kelas' => 'Pelatihan Web Development', 'deskripsi' => 'Pelatihan pengembangan web'],
        ['nama_kelas' => 'Pelatihan Data Analysis', 'deskripsi' => 'Pelatihan analisis data']
    ];
    
    foreach ($kelas_data as $data) {
        $sql = "INSERT INTO kelas (nama_kelas, deskripsi, status) VALUES ('{$data['nama_kelas']}', '{$data['deskripsi']}', 'aktif')";
        if (mysqli_query($conn, $sql)) {
            echo "<p>✓ Created kelas: {$data['nama_kelas']}</p>";
        } else {
            echo "<p>✗ Error creating kelas: " . mysqli_error($conn) . "</p>";
        }
    }
}

// Create sample jadwal if none exist
if ($jadwal_count == 0) {
    echo "<h2>Creating Sample Jadwal...</h2>";
    
    // Get first instruktur and kelas
    $instruktur = mysqli_fetch_assoc(mysqli_query($conn, "SELECT instruktur_id FROM instruktur LIMIT 1"));
    $kelas = mysqli_fetch_assoc(mysqli_query($conn, "SELECT kelas_id FROM kelas LIMIT 1"));
    
    if ($instruktur && $kelas) {
        $jadwal_data = [
            ['tanggal' => date('Y-m-d'), 'jam_mulai' => '08:00:00', 'jam_selesai' => '12:00:00', 'materi' => 'Pengenalan Digital Marketing'],
            ['tanggal' => date('Y-m-d', strtotime('+1 day')), 'jam_mulai' => '09:00:00', 'jam_selesai' => '13:00:00', 'materi' => 'Strategi Pemasaran Online'],
            ['tanggal' => date('Y-m-d', strtotime('+2 days')), 'jam_mulai' => '10:00:00', 'jam_selesai' => '14:00:00', 'materi' => 'Analisis Data Pemasaran']
        ];
        
        foreach ($jadwal_data as $data) {
            $sql = "INSERT INTO jadwal (instruktur_id, kelas_id, tanggal, jam_mulai, jam_selesai, materi) 
                    VALUES ({$instruktur['instruktur_id']}, {$kelas['kelas_id']}, '{$data['tanggal']}', '{$data['jam_mulai']}', '{$data['jam_selesai']}', '{$data['materi']}')";
            if (mysqli_query($conn, $sql)) {
                echo "<p>✓ Created jadwal: {$data['materi']} on {$data['tanggal']}</p>";
            } else {
                echo "<p>✗ Error creating jadwal: " . mysqli_error($conn) . "</p>";
            }
        }
    }
}

// Create sample absensi if none exist
if ($absensi_count == 0) {
    echo "<h2>Creating Sample Absensi...</h2>";
    
    // Get all instruktur
    $instruktur_result = mysqli_query($conn, "SELECT instruktur_id, nama_instruktur FROM instruktur");
    $dates = [date('Y-m-d'), date('Y-m-d', strtotime('-1 day')), date('Y-m-d', strtotime('-2 days'))];
    $statuses = ['Hadir', 'Hadir', 'Hadir', 'Izin', 'Sakit', 'Alfa'];
    
    while ($instruktur = mysqli_fetch_assoc($instruktur_result)) {
        foreach ($dates as $date) {
            $status = $statuses[array_rand($statuses)];
            $keterangan = "Sample absensi data";
            
            $sql = "INSERT INTO absensi (instruktur_id, tanggal, status, keterangan) 
                    VALUES ({$instruktur['instruktur_id']}, '$date', '$status', '$keterangan')";
            
            if (mysqli_query($conn, $sql)) {
                echo "<p>✓ Created absensi for {$instruktur['nama_instruktur']} on $date - $status</p>";
            } else {
                echo "<p>✗ Error creating absensi: " . mysqli_error($conn) . "</p>";
            }
        }
    }
}

// Create sample notifikasi
echo "<h2>Creating Sample Notifikasi...</h2>";
$absensi_result = mysqli_query($conn, "SELECT absensi_id, instruktur_id FROM absensi WHERE status IN ('Izin', 'Sakit', 'Alfa')");
$instruktur_names = [];

while ($absensi = mysqli_fetch_assoc($absensi_result)) {
    // Get instruktur name
    if (!isset($instruktur_names[$absensi['instruktur_id']])) {
        $instruktur_query = mysqli_query($conn, "SELECT nama_instruktur FROM instruktur WHERE instruktur_id = {$absensi['instruktur_id']}");
        $instruktur_names[$absensi['instruktur_id']] = mysqli_fetch_assoc($instruktur_query)['nama_instruktur'];
    }
    
    // Get absensi details
    $absensi_detail = mysqli_fetch_assoc(mysqli_query($conn, "SELECT tanggal, status FROM absensi WHERE absensi_id = {$absensi['absensi_id']}"));
    
    // Check if notifikasi already exists
    $check_sql = "SELECT COUNT(*) as count FROM notifikasi WHERE absensi_id = {$absensi['absensi_id']}";
    $check_result = mysqli_query($conn, $check_sql);
    $check_row = mysqli_fetch_assoc($check_result);
    
    if ($check_row['count'] == 0) {
        $keterangan = "Instruktur " . $instruktur_names[$absensi['instruktur_id']] . " " . strtolower($absensi_detail['status']) . " pada " . date('d-m-Y', strtotime($absensi_detail['tanggal']));
        
        $sql = "INSERT INTO notifikasi (absensi_id, status_notifikasi, keterangan, is_read, created_at) 
                VALUES ({$absensi['absensi_id']}, '{$absensi_detail['status']}', '$keterangan', 0, NOW())";
        
        if (mysqli_query($conn, $sql)) {
            echo "<p>✓ Created notifikasi for {$instruktur_names[$absensi['instruktur_id']]} - {$absensi_detail['status']}</p>";
        } else {
            echo "<p>✗ Error creating notifikasi: " . mysqli_error($conn) . "</p>";
        }
    }
}

echo "<h2>Final Status:</h2>";
$instruktur_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM instruktur"))['count'];
$kelas_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM kelas"))['count'];
$jadwal_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM jadwal"))['count'];
$absensi_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM absensi"))['count'];
$notifikasi_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM notifikasi"))['count'];

echo "<p>Instruktur: $instruktur_count</p>";
echo "<p>Kelas: $kelas_count</p>";
echo "<p>Jadwal: $jadwal_count</p>";
echo "<p>Absensi: $absensi_count</p>";
echo "<p>Notifikasi: $notifikasi_count</p>";

echo "<p><a href='dashboard.php'>Go to Admin Dashboard</a></p>";
echo "<p><a href='notifikasi.php'>Go to Notifikasi Page</a></p>";
?>
