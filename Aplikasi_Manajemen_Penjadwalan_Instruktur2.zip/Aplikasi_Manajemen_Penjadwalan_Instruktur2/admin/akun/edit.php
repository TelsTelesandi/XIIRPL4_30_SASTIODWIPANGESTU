<?php
include "../../config/database.php";
include "../../includes/header.php";
include "../../includes/sidebar.php";

$id = $_GET['id'];
$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE user_id=$id"));

if (isset($_POST['update'])) {
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $role = $_POST['role'];

    mysqli_query($conn, "UPDATE users SET 
        nama='$nama', 
        username='$username', 
        role='$role' 
        WHERE user_id=$id
    ");

    echo "<script>alert('Akun berhasil diperbarui!');window.location='index.php';</script>";
}
?>
<div style="display:flex;justify-content:center;margin-top:40px;min-height:60vh;align-items:flex-start;width:100%;">
  <div class="content-card" style="max-width: 480px; width:100%; background: #fff; box-shadow: 0 2px 8px #e5e5e5; border-radius: 10px; padding: 24px 32px;">
  <h2 style="display:flex;align-items:center;gap:8px;font-size:1.5rem;margin-bottom:22px;"><iconify-icon icon="material-symbols:edit-outline"></iconify-icon>Edit Akun</h2>
<form method="post">
    <div style="display:grid;gap:16px;">
        <div>
            <label style="display:block;font-weight:600;color:#374151;margin-bottom:6px;">Nama</label>
            <input type="text" name="nama" value="<?= htmlspecialchars($user['nama'] ?? '') ?>" required style="width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;">
        </div>
        <div>
            <label style="display:block;font-weight:600;color:#374151;margin-bottom:6px;">Username</label>
            <input type="text" name="username" value="<?= htmlspecialchars($user['username'] ?? '') ?>" required style="width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;">
        </div>
        <div>
            <label style="display:block;font-weight:600;color:#374151;margin-bottom:6px;">Role</label>
            <select name="role" required style="width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;background:#fff;">
                <option value="admin" <?= (isset($user['role']) && $user['role']=='admin')?'selected':''; ?>>Admin</option>
                <option value="instruktur" <?= (isset($user['role']) && $user['role']=='instruktur')?'selected':''; ?>>Instruktur</option>
            </select>
        </div>
    </div>
    <div style="display:flex;gap:8px;margin-top:22px;justify-content:flex-end;">
        <a href="index.php" class="btn" style="display:inline-block;padding:10px 14px;border-radius:8px;border:1px solid #e5e7eb;color:#374151;text-decoration:none;font-weight:600;">Batal</a>
        <button type="submit" name="update" class="btn btn-primary" style="padding:10px 14px;border-radius:8px;background:#15803d;color:white;border:0;font-weight:600;">Simpan</button>
    </div>
</form>
</div>
</div>
<?php include "../../includes/footer.php"; ?>
