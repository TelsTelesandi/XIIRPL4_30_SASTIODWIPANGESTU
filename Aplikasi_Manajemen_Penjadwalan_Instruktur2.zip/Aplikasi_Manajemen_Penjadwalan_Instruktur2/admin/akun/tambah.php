<?php
include "../../config/database.php";
include "../../includes/header.php";
include "../../includes/sidebar.php";

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$nama = trim($_POST['nama'] ?? '');
	$username = trim($_POST['username'] ?? '');
	$password = $_POST['password'] ?? '';
	$role = $_POST['role'] ?? 'instruktur';

	if ($nama === '' || $username === '' || $password === '' || $role === '') {
		$error = 'Semua field wajib diisi.';
	} else {
		// Cek username unik
		$cekStmt = mysqli_prepare($conn, "SELECT 1 FROM users WHERE username = ? LIMIT 1");
		mysqli_stmt_bind_param($cekStmt, "s", $username);
		mysqli_stmt_execute($cekStmt);
		$cekResult = mysqli_stmt_get_result($cekStmt);
		if ($cekResult && mysqli_num_rows($cekResult) > 0) {
			$error = 'Username sudah digunakan, pilih yang lain.';
		} else {
			$hashed = password_hash($password, PASSWORD_DEFAULT);
			$insertStmt = mysqli_prepare($conn, "INSERT INTO users (nama, username, password, role) VALUES (?, ?, ?, ?)");
			if ($insertStmt) {
				mysqli_stmt_bind_param($insertStmt, "ssss", $nama, $username, $hashed, $role);
				$ok = mysqli_stmt_execute($insertStmt);
				if ($ok) {
					echo "<script>alert('Akun berhasil ditambahkan'); window.location='index.php';</script>";
					exit;
				} else {
					$error = 'Gagal menambahkan akun: ' . mysqli_error($conn);
				}
			} else {
				$error = 'Gagal menyiapkan perintah SQL.';
			}
		}
	}
}
?>

<div class="content">
	<div class="dashboard-container fade-in">
		<div class="dashboard-header">
			<h2>
				<iconify-icon icon="material-symbols:person-add-outline"></iconify-icon>
				Tambah Akun
			</h2>
			<p class="dashboard-subtitle">Buat akun baru untuk admin/instruktur</p>
		</div>

		<div class="content-card" style="max-width: 640px;">
			<?php if ($error): ?>
				<div style="background:#fef2f2;border:1px solid #fecaca;color:#b91c1c;padding:12px 16px;border-radius:8px;margin-bottom:16px;">
					<?= htmlspecialchars($error); ?>
				</div>
			<?php endif; ?>

			<form method="post">
				<div style="display:grid;gap:12px;">
					<div>
						<label style="display:block;font-weight:600;color:#374151;margin-bottom:6px;">Nama</label>
						<input type="text" name="nama" required style="width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;">
					</div>
					<div>
						<label style="display:block;font-weight:600;color:#374151;margin-bottom:6px;">Username</label>
						<input type="text" name="username" required style="width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;">
					</div>
					<div>
						<label style="display:block;font-weight:600;color:#374151;margin-bottom:6px;">Password</label>
						<input type="password" name="password" required style="width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;">
					</div>
					<div>
						<label style="display:block;font-weight:600;color:#374151;margin-bottom:6px;">Role</label>
						<select name="role" required style="width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;background:#fff;">
							<option value="admin">Admin</option>
							<option value="instruktur">Instruktur</option>
						</select>
					</div>
				</div>

				<div style="display:flex;gap:8px;margin-top:16px;justify-content:flex-end;">
					<a href="index.php" class="btn" style="display:inline-block;padding:10px 14px;border-radius:8px;border:1px solid #e5e7eb;color:#374151;text-decoration:none;font-weight:600;">Batal</a>
					<button type="submit" class="btn btn-primary" style="padding:10px 14px;border-radius:8px;background:#15803d;color:white;border:0;font-weight:600;">Simpan</button>
				</div>
			</form>
		</div>
	</div>
</div>

<?php include "../../includes/footer.php"; ?>


