<?php
include "../../config/database.php";
include "../../includes/header.php";
include "../../includes/sidebar.php";

// Ambil semua akun
$result = mysqli_query($conn, "SELECT * FROM users ORDER BY role");
?>

<div class="content">
    <div class="dashboard-container fade-in">
        <div class="dashboard-header">
            <h2>
                <iconify-icon icon="material-symbols:settings-outline"></iconify-icon>
                Manajemen Akun
            </h2>
            <p class="dashboard-subtitle">Kelola akun pengguna sistem</p>
        </div>

        <div style="margin-bottom: 24px;">
            <a href="tambah.php" class="btn btn-primary">
                <iconify-icon icon="material-symbols:person-add-outline"></iconify-icon>
                Tambah Akun
            </a>
        </div>

        <div class="content-card">
            <table class="modern-table">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td>
                            <div style="font-weight: 600; color: #1f2937;">
                                <?= htmlspecialchars($row['nama'] ?? ''); ?>
                            </div>
                        </td>
                        <td><?= htmlspecialchars($row['username'] ?? ''); ?></td>
                        <td>
                            <span style="background: #dbeafe; color: #1d4ed8; padding: 4px 8px; border-radius: 6px; font-size: 12px; font-weight: 600;">
                                <?= ucfirst($row['role'] ?? ''); ?>
                            </span>
                        </td>
                        <td>
                            <a href="edit.php?id=<?= $row['user_id']; ?>" 
                               style="color: #8b5cf6; text-decoration: none; font-weight: 600; margin-right: 12px;">
                                <iconify-icon icon="material-symbols:edit-outline"></iconify-icon>
                                Edit
                            </a>
                            <a href="reset_password.php?id=<?= $row['user_id']; ?>" 
                               style="color: #f59e0b; text-decoration: none; font-weight: 600; margin-right: 12px;">
                                <iconify-icon icon="material-symbols:lock-reset-outline"></iconify-icon>
                                Reset
                            </a>
                            <a href="hapus.php?id=<?= $row['user_id']; ?>" 
                               onclick="return confirm('Yakin hapus akun ini?')"
                               style="color: #dc2626; text-decoration: none; font-weight: 600;">
                                <iconify-icon icon="material-symbols:delete-outline"></iconify-icon>
                                Hapus
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Fixed footer include path -->
<?php include "../../includes/footer.php"; ?>
