<?php
session_start();
include "../../config/database.php";
include "../../includes/header.php";
include "../../includes/sidebar.php";

// Get all materials from all instructors
$query = "SELECT m.*, i.nama_instruktur FROM materi m JOIN instruktur i ON m.instruktur_id = i.instruktur_id ORDER BY m.uploaded_at DESC";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Query error: " . mysqli_error($conn));
}
?>

<div class="content">
    <div class="page-header">
        <h2>
            <iconify-icon icon="material-symbols:folder-open"></iconify-icon>
            Kelola Materi
        </h2>
        <p>Kelola semua materi yang diupload oleh instruktur</p>
    </div>

    <div class="content-card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 style="font-size: 18px; font-weight: 700; color: #1f2937;">Daftar Materi</h3>
        </div>

        <div style="overflow-x: auto;">
            <table class="modern-table">
                <thead>
                    <tr>
                        <th>Judul Materi</th>
                        <th>Instruktur</th>
                        <th>File</th>
                        <th>Tanggal Upload</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($result) > 0): ?>
                        <?php while ($material = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td>
                                <span style="font-weight: 600; color: #1f2937;">
                                    <?= htmlspecialchars($material['judul_materi']) ?>
                                </span>
                            </td>
                            <td>
                                <span style="background: #fef3c7; color: #92400e; padding: 4px 8px; border-radius: 6px; font-size: 12px; font-weight: 600;">
                                    <?= htmlspecialchars($material['nama_instruktur']) ?>
                                </span>
                            </td>
                            <td>
                                <span style="background: #e0e7ff; color: #3730a3; padding: 4px 8px; border-radius: 6px; font-size: 12px; font-weight: 600;">
                                    <?= htmlspecialchars($material['file']) ?>
                                </span>
                            </td>
                            <td>
                                <span style="color: #6b7280; font-size: 14px;">
                                    <?= date('d M Y H:i', strtotime($material['uploaded_at'])) ?>
                                </span>
                            </td>
                            <td>
                                <div style="display: flex; gap: 8px;">
                                    <a href="../../uploads/materi/<?= urlencode($material['file']) ?>" download style="padding: 6px 12px; background: #059669; color: white; border-radius: 6px; text-decoration: none; font-size: 12px; font-weight: 600; display: inline-flex; align-items: center; gap: 4px;">
                                        <iconify-icon icon="material-symbols:download"></iconify-icon>
                                        Download
                                    </a>
                                    <a href="hapus.php?materi_id=<?= $material['materi_id'] ?>" onclick="return confirm('Yakin ingin menghapus materi ini?')" style="padding: 6px 12px; background: #dc2626; color: white; border-radius: 6px; text-decoration: none; font-size: 12px; font-weight: 600; display: inline-flex; align-items: center; gap: 4px;">
                                        <iconify-icon icon="material-symbols:delete-outline"></iconify-icon>
                                        Hapus
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" style="text-align: center; color: #6b7280; padding: 20px;">
                                Belum ada materi yang diupload
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include "../../includes/footer.php"; ?>
