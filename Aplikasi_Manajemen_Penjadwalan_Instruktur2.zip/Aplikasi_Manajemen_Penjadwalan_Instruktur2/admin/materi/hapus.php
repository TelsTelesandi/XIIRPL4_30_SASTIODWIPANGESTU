<?php
session_start();
include "../../config/database.php";

if (!isset($_GET['materi_id'])) {
    header("Location: index.php");
    exit;
}

$materi_id = $_GET['materi_id'];

// Get material info to delete file
$query = "SELECT file FROM materi WHERE materi_id = '$materi_id'";
$result = mysqli_query($conn, $query);
$material = mysqli_fetch_assoc($result);

if ($material) {
    // Delete file from server
    $file_path = "../../uploads/materi/" . $material['file'];
    if (file_exists($file_path)) {
        unlink($file_path);
    }

    // Delete from database
    $delete_query = "DELETE FROM materi WHERE materi_id = '$materi_id'";
    if (mysqli_query($conn, $delete_query)) {
        header("Location: index.php?success=Material berhasil dihapus");
    } else {
        header("Location: index.php?error=Gagal menghapus material");
    }
} else {
    header("Location: index.php?error=Material tidak ditemukan");
}
?>
