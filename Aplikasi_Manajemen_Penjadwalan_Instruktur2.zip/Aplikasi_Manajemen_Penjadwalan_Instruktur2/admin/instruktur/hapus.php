<?php
include "../../config/database.php";

$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM instruktur WHERE instruktur_id='$id'");

echo "<script>alert('Instruktur berhasil dihapus!');window.location='index.php';</script>";
?>
