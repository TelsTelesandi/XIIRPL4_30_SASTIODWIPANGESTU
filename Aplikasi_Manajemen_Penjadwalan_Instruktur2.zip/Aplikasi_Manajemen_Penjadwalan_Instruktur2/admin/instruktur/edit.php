<?php
include "../../config/database.php";
include "../../includes/header.php";
include "../../includes/sidebar.php";

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

// ambil data instruktur
$result = mysqli_query($conn, "SELECT * FROM instruktur WHERE instruktur_id = $id");
$instruktur = mysqli_fetch_assoc($result);

// jika data tidak ada
if (!$instruktur) {
    echo "<script>alert('Data instruktur tidak ditemukan!');window.location='index.php';</script>";
    exit;
}

if (isset($_POST['update'])) {
    $nama     = mysqli_real_escape_string($conn, $_POST['nama']);
    $email    = mysqli_real_escape_string($conn, $_POST['email']);
    $telepon  = mysqli_real_escape_string($conn, $_POST['telepon']);
    $keahlian = mysqli_real_escape_string($conn, $_POST['keahlian']);

    $update = mysqli_query($conn, "UPDATE instruktur SET 
        nama_instruktur='$nama', 
        email='$email', 
        no_hp='$telepon',
        keahlian='$keahlian'
        WHERE instruktur_id=$id
    ");

    if ($update) {
        echo "<script>alert('Data instruktur berhasil diperbarui!');window.location='index.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui data!');</script>";
    }
}
?>

<div class="content">
    <div class="dashboard-container fade-in">
        <!-- Updated header with modern icon -->
        <div class="dashboard-header">
            <h2>
                <iconify-icon icon="material-symbols:edit-outline"></iconify-icon>
                Edit Instruktur
            </h2>
            <p class="dashboard-subtitle">Perbarui data instruktur</p>
        </div>

        <!-- Modern form card -->
        <div class="content-card form-card">
            <form method="post" class="form-grid">
                <div class="form-group">
                    <label for="nama">Nama Lengkap</label>
                    <input type="text" id="nama" name="nama" class="form-control" 
                           value="<?= htmlspecialchars($instruktur['nama_instruktur']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" class="form-control" 
                           value="<?= htmlspecialchars($instruktur['email']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="telepon">Nomor Telepon</label>
                    <input type="text" id="telepon" name="telepon" class="form-control" 
                           value="<?= htmlspecialchars($instruktur['no_hp']); ?>">
                </div>

                <div class="form-group">
                    <label for="keahlian">Keahlian</label>
                    <input type="text" id="keahlian" name="keahlian" class="form-control" 
                           value="<?= htmlspecialchars($instruktur['keahlian']); ?>">
                </div>

                <div class="form-actions">
                    <button type="submit" name="update" class="btn btn-primary">
                        <iconify-icon icon="material-symbols:save-outline"></iconify-icon>
                        Simpan Perubahan
                    </button>
                    <a href="index.php" class="btn btn-secondary">
                        <iconify-icon icon="material-symbols:arrow-back"></iconify-icon>
                        Kembali
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include "../../includes/footer.php"; ?>
