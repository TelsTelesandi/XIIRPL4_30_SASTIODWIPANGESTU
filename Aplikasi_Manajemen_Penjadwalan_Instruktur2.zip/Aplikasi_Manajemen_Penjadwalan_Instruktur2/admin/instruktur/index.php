<?php
include "../../config/database.php";
include "../../includes/header.php";
include "../../includes/sidebar.php";

$result = mysqli_query($conn, "SELECT * FROM instruktur ORDER BY nama_instruktur ASC");
?>

<div class="content">
    <div class="dashboard-container fade-in">
        <!-- Updated header with modern icon and styling -->
        <div class="dashboard-header">
            <h2>
                <iconify-icon icon="material-symbols:group-outline"></iconify-icon>
                Data Instruktur Teknologi Informasi dan Komunikasi (TIK)
            </h2>
            <p class="dashboard-subtitle">Pengelolaan Data Instruktur </p>
        </div>

        <!-- Modern action button -->
        <div style="margin-bottom: 24px;">
            <a href="tambah.php" class="btn btn-primary">
                <iconify-icon icon="material-symbols:person-add-outline"></iconify-icon>
                Tambah Instruktur
            </a>
        </div>

        <!-- Modern table card -->
        <div class="content-card">
            <table class="modern-table">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Telepon</th>
                        <th>Keahlian</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td>
                            <div style="font-weight: 600; color: #1f2937;">
                                <?= htmlspecialchars($row['nama_instruktur']); ?>
                            </div>
                        </td>
                        <td><?= htmlspecialchars($row['email']); ?></td>
                        <td><?= htmlspecialchars($row['no_hp']); ?></td>
                        <td>
                            <span class="badge" style="background: #f3e8ff; color: #7c3aed;">
                                <?= htmlspecialchars($row['keahlian']); ?>
                            </span>
                        </td>
                        <td>
                            <a href="edit.php?id=<?= isset($row['instruktur_id']) ? htmlspecialchars($row['instruktur_id']) : '' ?>" 
                               style="color: #8b5cf6; text-decoration: none; font-weight: 600; margin-right: 12px;">
                                <iconify-icon icon="material-symbols:edit-outline"></iconify-icon>
                                Edit
                            </a>
                            <a href="hapus.php?id=<?= isset($row['instruktur_id']) ? htmlspecialchars($row['instruktur_id']) : '' ?>" 
                               onclick="return confirm('Yakin hapus instruktur ini?')"
                               style="color: #dc2626; text-decoration: none; font-weight: 600;">
                                <iconify-icon icon="material-symbols:delete-outline"></iconify-icon>
                                Hapus
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include "../../includes/footer.php"; ?>
