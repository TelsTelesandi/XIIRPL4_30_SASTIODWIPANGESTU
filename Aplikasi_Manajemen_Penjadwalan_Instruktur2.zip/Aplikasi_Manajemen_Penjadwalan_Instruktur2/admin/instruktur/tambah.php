<?php
include "../../config/database.php";
include "../../includes/header.php";
include "../../includes/sidebar.php";

if (isset($_POST['simpan'])) {
    $nama      = mysqli_real_escape_string($conn, $_POST['nama']);
    $email     = mysqli_real_escape_string($conn, $_POST['email']);
    $no_hp     = mysqli_real_escape_string($conn, $_POST['telepon']);
    $keahlian  = mysqli_real_escape_string($conn, $_POST['keahlian']);

    // Buat akun user otomatis
    $username = strtolower(str_replace(" ", "", $nama)); // username dari nama
    $password = password_hash("123456", PASSWORD_DEFAULT); // password default
    mysqli_query($conn, "INSERT INTO users (username, password, role) 
                         VALUES ('$username', '$password', 'instruktur')");

    // Ambil user_id terakhir
    $user_id = mysqli_insert_id($conn);

    // Simpan data instruktur
    mysqli_query($conn, "INSERT INTO instruktur (user_id, nama_instruktur, email, no_hp, keahlian) 
        VALUES ('$user_id','$nama','$email','$no_hp','$keahlian')");

    echo "<script>alert('Instruktur berhasil ditambahkan!');window.location='index.php';</script>";
}
?>

<div class="content">
    <div class="dashboard-container fade-in">
        <!-- Updated header with modern icon -->
        <div class="dashboard-header">
            <h2>
                <iconify-icon icon="material-symbols:person-add-outline"></iconify-icon>
                Tambah Instruktur
            </h2>
            <p class="dashboard-subtitle">Lengkapi data instruktur baru</p>
        </div>

        <!-- Modern form card -->
        <div class="content-card form-card">
            <form method="post" class="form-grid">
                <div class="form-group">
                    <label for="nama">Nama Lengkap</label>
                    <input type="text" id="nama" name="nama" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="telepon">Nomor Telepon</label>
                    <input type="text" id="telepon" name="telepon" class="form-control">
                </div>

                <div class="form-group">
                    <label for="keahlian">Keahlian</label>
                    <input type="text" id="keahlian" name="keahlian" class="form-control" placeholder="Contoh: Web Development, Mobile App">
                </div>

                <div class="form-actions">
                    <button type="submit" name="simpan" class="btn btn-primary">
                        <iconify-icon icon="material-symbols:save-outline"></iconify-icon>
                        Simpan
                    </button>
                    <a href="index.php" class="btn btn-secondary">
                        <iconify-icon icon="material-symbols:arrow-back"></iconify-icon>
                        Kembali
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include "../../includes/footer.php"; ?>
