<?php
include "../../config/database.php";
include "../../includes/header.php";
include "../../includes/sidebar.php";

$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM kelas WHERE id=$id"));

if (isset($_POST['update'])) {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);

    mysqli_query($conn, "UPDATE kelas SET nama='$nama', deskripsi='$deskripsi' WHERE id=$id");

    echo "<script>alert('Kelas berhasil diperbarui!');window.location='index.php';</script>";
}
?>

<div class="content">
    <div class="dashboard-container fade-in">
        <!-- Updated header with modern icon -->
        <div class="dashboard-header">
            <h2>
                <iconify-icon icon="material-symbols:edit-outline"></iconify-icon>
                Edit Kelas
            </h2>
            <p class="dashboard-subtitle">Perbarui informasi kelas</p>
        </div>

        <!-- Modern form card -->
        <div class="content-card form-card">
            <form method="post" class="form-grid">
                <div class="form-group">
                    <label for="nama">Nama Kelas</label>
                    <input type="text" id="nama" name="nama" class="form-control" 
                           value="<?= htmlspecialchars($data['nama']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="deskripsi">Deskripsi</label>
                    <textarea id="deskripsi" name="deskripsi" class="form-control" rows="4"><?= htmlspecialchars($data['deskripsi']); ?></textarea>
                </div>

                <div class="form-actions">
                    <button type="submit" name="update" class="btn btn-primary">
                        <iconify-icon icon="material-symbols:save-outline"></iconify-icon>
                        Simpan Perubahan
                    </button>
                    <a href="index.php" class="btn btn-secondary">
                        <iconify-icon icon="material-symbols:arrow-back"></iconify-icon>
                        Kembali
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include "../../includes/footer.php"; ?>
