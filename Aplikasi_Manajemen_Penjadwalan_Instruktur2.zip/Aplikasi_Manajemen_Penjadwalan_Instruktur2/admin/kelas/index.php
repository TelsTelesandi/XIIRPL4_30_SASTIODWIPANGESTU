<?php
include "../../config/database.php";
include "../../includes/header.php";
include "../../includes/sidebar.php";

$result = mysqli_query($conn, "SELECT * FROM kelas ORDER BY nama_kelas ASC");
?>

<div class="content">
    <div class="dashboard-container fade-in">
        <div class="dashboard-header">
            <h2>
                <iconify-icon icon="material-symbols:school-outline"></iconify-icon>
                Data Kelas Pelatihan Gedung Teknologi Informasi dan Komunikasi
            </h2>
            <p class="dashboard-subtitle">Pengelolaan Kelas Pelatihan TIK</p>
        </div>

        <div style="margin-bottom: 24px;">
            <a href="tambah.php" class="btn btn-primary">
                <iconify-icon icon="material-symbols:add-box-outline"></iconify-icon>
                Tambah Kelas
            </a>
        </div>

        <div class="content-card">
            <table class="modern-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Kelas</th>
                        <th>Deskripsi</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no=1; while($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td>
                            <span style="background: #f1f5f9; color: #6b7280; padding: 4px 8px; border-radius: 6px; font-size: 12px; font-weight: 600;">
                                <?= $no++; ?>
                            </span>
                        </td>
                        <td>
                            <div style="font-weight: 600; color: #1f2937;">
                                <?= htmlspecialchars($row['nama_kelas']); ?>
                            </div>
                        </td>
                        <!-- Fixed description column to show proper field -->
                        <td>
                            <div style="color: #6b7280;">
                                <?= htmlspecialchars($row['deskripsi'] ?? 'Tidak ada deskripsi'); ?>
                            </div>
                        </td>
                        <td>
                            <a href="edit.php?id=<?= $row['kelas_id']; ?>" 
                               style="color: #8b5cf6; text-decoration: none; font-weight: 600; margin-right: 12px;">
                                <iconify-icon icon="material-symbols:edit-outline"></iconify-icon>
                                Edit
                            </a>
                            <a href="hapus.php?id=<?= $row['kelas_id']; ?>" 
                               onclick="return confirm('Yakin hapus kelas ini?')"
                               style="color: #dc2626; text-decoration: none; font-weight: 600;">
                                <iconify-icon icon="material-symbols:delete-outline"></iconify-icon>
                                Hapus
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include "../../includes/footer.php"; ?>
