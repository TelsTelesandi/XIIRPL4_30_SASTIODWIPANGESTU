<?php
include "../../config/database.php";
include "../../includes/header.php";
include "../../includes/sidebar.php";

if (isset($_POST['simpan'])) {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);

    mysqli_query($conn, "INSERT INTO kelas (nama_kelas, deskripsi) VALUES ('$nama', '$deskripsi')");

    echo "<script>alert('Kelas berhasil ditambahkan!');window.location='index.php';</script>";
}

?>

<div class="content">
    <div class="dashboard-container fade-in">
        <!-- Updated header with modern icon -->
        <div class="dashboard-header">
            <h2>
                <iconify-icon icon="material-symbols:add-box-outline"></iconify-icon>
                Tambah Kelas
            </h2>
            <p class="dashboard-subtitle">Buat kelas atau program pelatihan baru</p>
        </div>

        <!-- Modern form card -->
        <div class="content-card form-card">
            <form method="post" class="form-grid">
                <div class="form-group">
                    <label for="nama">Nama Kelas</label>
                    <input type="text" id="nama" name="nama" class="form-control" 
                           placeholder="Contoh: Web Development Dasar" required>
                </div>

                <div class="form-group">
                    <label for="deskripsi">Deskripsi</label>
                    <textarea id="deskripsi" name="deskripsi" class="form-control" rows="4" 
                              placeholder="Jelaskan tujuan dan materi kelas ini..."></textarea>
                </div>

                <div class="form-actions">
                    <button type="submit" name="simpan" class="btn btn-primary">
                        <iconify-icon icon="material-symbols:save-outline"></iconify-icon>
                        Simpan
                    </button>
                    <a href="index.php" class="btn btn-secondary">
                        <iconify-icon icon="material-symbols:arrow-back"></iconify-icon>
                        Kembali
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include "../../includes/footer.php"; ?>
