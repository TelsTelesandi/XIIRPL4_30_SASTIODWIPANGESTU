<?php
include "../../config/database.php";

$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM kelas WHERE id=$id");

echo "<script>alert('Kelas berhasil dihapus!');window.location='index.php';</script>";
