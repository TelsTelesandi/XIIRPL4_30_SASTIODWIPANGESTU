<?php
include "../config/database.php";
include "../includes/header.php";
include "../includes/sidebar.php";

$sql = "SELECT * FROM instruktur ORDER BY nama ASC";
$result = mysqli_query($conn, $sql);
?>

<h2>👨‍🏫 Data Instruktur</h2>
<a href="instruktur/tambah.php">➕ Tambah Instruktur</a>
<table border="1" cellspacing="0" cellpadding="8" width="100%">
    <tr style="background:#023e8a; color:white;">
        <th>No</th>
        <th>Nama</th>
        <th>Email</th>
        <th>Telepon</th>
        <th>Aksi</th>
    </tr>
    <?php $no=1; while($row=mysqli_fetch_assoc($result)): ?>
    <tr>
        <td><?= $no++; ?></td>
        <td><?= $row['nama']; ?></td>
        <td><?= $row['email']; ?></td>
        <td><?= $row['telepon']; ?></td>
        <td>
            <a href="instruktur/edit.php?id=<?= $row['id']; ?>">✏️ Edit</a> | 
            <a href="instruktur/hapus.php?id=<?= $row['id']; ?>" onclick="return confirm('Yakin hapus data ini?')">🗑️ Hapus</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

<?php include "../includes/footer.php"; ?>








