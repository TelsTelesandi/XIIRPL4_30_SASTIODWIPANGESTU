<?php
include "../../config/database.php";
include "../../includes/header.php";
include "../../includes/sidebar.php";

$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM jadwal WHERE jadwal_id=$id"));
$kelas = mysqli_query($conn, "SELECT * FROM kelas ORDER BY nama_kelas ASC");
$instruktur = mysqli_query($conn, "SELECT * FROM instruktur ORDER BY nama_instruktur ASC");

if (isset($_POST['update'])) {
    $kelas_id = $_POST['kelas_id'];
    $instruktur_id = $_POST['instruktur_id'];
    $tanggal = $_POST['tanggal'];
    $jam_mulai = $_POST['jam_mulai'];
    $jam_selesai = $_POST['jam_selesai'];

    mysqli_query($conn, "UPDATE jadwal SET 
        kelas_id='$kelas_id',
        instruktur_id='$instruktur_id',
        tanggal='$tanggal',
        jam_mulai='$jam_mulai',
        jam_selesai='$jam_selesai'
        WHERE jadwal_id=$id
    ");

    echo "<script>alert('Jadwal berhasil diperbarui!');window.location='index.php';</script>";
}
?>

<!-- Added proper content container and styling structure -->
<div class="content">
    <div class="dashboard-container">
        <div class="dashboard-header">
            <h2>
                <iconify-icon icon="material-symbols:edit-outline"></iconify-icon>
                Edit Jadwal
            </h2>
            <p class="dashboard-subtitle">Perbarui informasi jadwal pelatihan</p>
        </div>

        <div class="content-card form-card">
            <form method="post" class="form-grid">
                <div class="form-group">
                    <label for="kelas_id">Kelas</label>
                    <select name="kelas_id" id="kelas_id" class="form-control" required>
                        <option value="">Pilih Kelas</option>
                        <?php while($k = mysqli_fetch_assoc($kelas)): ?>
                            <!-- Fixed column name from 'id' to 'kelas_id' and 'nama' to 'nama_kelas' -->
                            <option value="<?= $k['kelas_id']; ?>" <?= ($k['kelas_id']==$data['kelas_id'])?'selected':''; ?>>
                                <?= $k['nama_kelas']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="instruktur_id">Instruktur</label>
                    <select name="instruktur_id" id="instruktur_id" class="form-control" required>
                        <option value="">Pilih Instruktur</option>
                        <?php while($i = mysqli_fetch_assoc($instruktur)): ?>
                            <!-- Fixed column name from 'id' to 'instruktur_id' and 'nama' to 'nama_instruktur' -->
                            <option value="<?= $i['instruktur_id']; ?>" <?= ($i['instruktur_id']==$data['instruktur_id'])?'selected':''; ?>>
                                <?= $i['nama_instruktur']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="tanggal">Tanggal</label>
                    <input type="date" name="tanggal" id="tanggal" class="form-control" value="<?= $data['tanggal']; ?>" required>
                </div>

                <div class="grid-2">
                    <div class="form-group">
                        <label for="jam_mulai">Jam Mulai</label>
                        <input type="time" name="jam_mulai" id="jam_mulai" class="form-control" value="<?= $data['jam_mulai']; ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="jam_selesai">Jam Selesai</label>
                        <input type="time" name="jam_selesai" id="jam_selesai" class="form-control" value="<?= $data['jam_selesai']; ?>" required>
                    </div>
                </div>

                <div style="display: flex; gap: 12px; margin-top: 16px;">
                    <button type="submit" name="update" class="btn btn-primary">
                        <iconify-icon icon="material-symbols:save-outline"></iconify-icon>
                        Update Jadwal
                    </button>
                    <a href="index.php" class="btn btn-secondary">
                        <iconify-icon icon="material-symbols:arrow-back"></iconify-icon>
                        Kembali
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include "../../includes/footer.php"; ?>
