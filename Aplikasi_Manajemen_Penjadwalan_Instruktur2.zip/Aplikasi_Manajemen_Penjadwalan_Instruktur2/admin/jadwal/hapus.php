<?php
include "../../config/database.php";

$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM jadwal WHERE id=$id");

echo "<script>alert('Jadwal berhasil dihapus!');window.location='index.php';</script>";
