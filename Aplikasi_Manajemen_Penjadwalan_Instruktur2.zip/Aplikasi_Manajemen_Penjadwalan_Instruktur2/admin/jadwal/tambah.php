<?php
include "../../config/database.php";
include "../../includes/header.php";
include "../../includes/sidebar.php";

// Ambil data kelas & instruktur
$kelas = mysqli_query($conn, "SELECT * FROM kelas ORDER BY nama_kelas ASC");
$instruktur = mysqli_query($conn, "SELECT * FROM instruktur ORDER BY nama_instruktur ASC");

// Proses simpan
if (isset($_POST['simpan'])) {
    $kelas_id      = mysqli_real_escape_string($conn, $_POST['kelas_id']);
    $instruktur_id = mysqli_real_escape_string($conn, $_POST['instruktur_id']);
    $tanggal       = mysqli_real_escape_string($conn, $_POST['tanggal']);
    $jam_mulai     = mysqli_real_escape_string($conn, $_POST['jam_mulai']);
    $jam_selesai   = mysqli_real_escape_string($conn, $_POST['jam_selesai']);
    $materi        = mysqli_real_escape_string($conn, $_POST['materi'] ?? '');

    // Validasi sederhana
    if (!empty($kelas_id) && !empty($instruktur_id) && !empty($tanggal) && !empty($jam_mulai) && !empty($jam_selesai)) {
        $query = "INSERT INTO jadwal (kelas_id, instruktur_id, tanggal, jam_mulai, jam_selesai, materi) 
                  VALUES ('$kelas_id','$instruktur_id','$tanggal','$jam_mulai','$jam_selesai','$materi')";
        if (mysqli_query($conn, $query)) {
            echo "<script>alert('✅ Jadwal berhasil ditambahkan!');window.location='index.php';</script>";
        } else {
            echo "<script>alert('❌ Terjadi kesalahan: " . mysqli_error($conn) . "');</script>";
        }
    } else {
        echo "<script>alert('⚠️ Semua field wajib diisi!');</script>";
    }
}
?>

<!-- Enhanced form styling with better layout and design -->
<div class="content">
    <div class="dashboard-container fade-in">
        <div class="dashboard-header">
            <h2>
                <iconify-icon icon="material-symbols:add-box-outline"></iconify-icon>
                Tambah Jadwal Baru
            </h2>
            <p class="dashboard-subtitle">Lengkapi semua informasi jadwal pelatihan di bawah ini</p>
        </div>

        <div class="content-card form-card" style="max-width: 900px;">
            <form method="post" class="form-grid">

                <!-- Pilih Kelas - Full Width -->
                <div class="form-group">
                    <label for="kelas_id">
                        <iconify-icon icon="material-symbols:school-outline" style="margin-right: 6px; vertical-align: middle;"></iconify-icon>
                        Pilih Kelas
                    </label>
                    <select id="kelas_id" name="kelas_id" class="form-control" required>
                        <option value="">-- Pilih Kelas --</option>
                        <?php 
                        $kelas = mysqli_query($conn, "SELECT * FROM kelas ORDER BY nama_kelas ASC");
                        while ($k = mysqli_fetch_assoc($kelas)): ?>
                            <option value="<?= $k['kelas_id']; ?>"><?= htmlspecialchars($k['nama_kelas']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <!-- Pilih Instruktur - Full Width -->
                <div class="form-group">
                    <label for="instruktur_id">
                        <iconify-icon icon="material-symbols:person-outline" style="margin-right: 6px; vertical-align: middle;"></iconify-icon>
                        Pilih Instruktur
                    </label>
                    <select id="instruktur_id" name="instruktur_id" class="form-control" required>
                        <option value="">-- Pilih Instruktur --</option>
                        <?php 
                        $instruktur = mysqli_query($conn, "SELECT * FROM instruktur ORDER BY nama_instruktur ASC");
                        while ($i = mysqli_fetch_assoc($instruktur)): ?>
                            <option value="<?= $i['instruktur_id']; ?>"><?= htmlspecialchars($i['nama_instruktur']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <!-- Grid untuk tanggal & jam -->
                <!-- Tambahkan di bagian HEAD -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

<!-- Form HTML -->
<div class="grid-3">
    <div class="form-group">
        <label for="tanggal">
            <iconify-icon icon="material-symbols:calendar-today-outline" style="margin-right: 6px; vertical-align: middle;"></iconify-icon>
            Tanggal
        </label>
        <input type="text" id="tanggal" name="tanggal" class="form-control" placeholder="Pilih Tanggal" required readonly>
    </div>
    
    <div class="form-group">
        <label for="jam_mulai">
            <iconify-icon icon="material-symbols:schedule-outline" style="margin-right: 6px; vertical-align: middle;"></iconify-icon>
            Jam Mulai
        </label>
        <input type="text" id="jam_mulai" name="jam_mulai" class="form-control" placeholder="HH:MM" required readonly>
    </div>
    
    <div class="form-group">
        <label for="jam_selesai">
            <iconify-icon icon="material-symbols:schedule-outline" style="margin-right: 6px; vertical-align: middle;"></iconify-icon>
            Jam Selesai
        </label>
        <input type="text" id="jam_selesai" name="jam_selesai" class="form-control" placeholder="HH:MM" required readonly>
    </div>
</div>

<!-- Script di bagian bawah sebelum </body> -->
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/id.js"></script>

<script>
// Date Picker untuk Tanggal
flatpickr("#tanggal", {
    locale: "id",
    dateFormat: "Y-m-d",
    allowInput: false,
    minDate: "today"
});

// Time Picker untuk Jam Mulai
flatpickr("#jam_mulai", {
    enableTime: true,
    noCalendar: true,
    dateFormat: "H:i",
    time_24hr: true,
    allowInput: false
});

// Time Picker untuk Jam Selesai
flatpickr("#jam_selesai", {
    enableTime: true,
    noCalendar: true,
    dateFormat: "H:i",
    time_24hr: true,
    allowInput: false
});
</script>

                <!-- Renamed from 'deskripsi' to 'materi' to match database schema -->
                <div class="form-group">
                    <label for="materi">
                        <iconify-icon icon="material-symbols:description-outline" style="margin-right: 6px; vertical-align: middle;"></iconify-icon>
                        Materi/Topik Jadwal (Opsional)
                    </label>
                    <textarea 
                        id="materi" 
                        name="materi" 
                        class="form-control" 
                        rows="4" 
                        placeholder="Contoh: Materi dasar programming, topik khusus, atau catatan penting lainnya..."
                        style="resize: vertical; min-height: 100px;"></textarea>
                    <small style="color: #6b7280; display: block; margin-top: 4px;">💡 Tambahkan materi/topik untuk membantu peserta memahami apa yang akan diajarkan</small>
                </div>

                <!-- Aksi -->
                <div class="form-actions">
                    <button type="submit" name="simpan" class="btn btn-primary">
                        <iconify-icon icon="material-symbols:save-outline"></iconify-icon>
                        💾 Simpan Jadwal
                    </button>
                    <a href="index.php" class="btn btn-secondary">
                        <iconify-icon icon="material-symbols:arrow-back"></iconify-icon>
                        Kembali
                    </a>
                </div>
            </form>
        </div>

        <!-- Added informative tips section -->
        <div class="content-card" style="margin-top: 24px; background: linear-gradient(135deg, #f0fdf4 0%, #f1fdf5 100%); border: 1px solid #bbf7d0;">
            <div style="padding: 20px;">
                <h3 style="margin: 0 0 12px 0; color: #166534; font-size: 16px; font-weight: 600;">
                    <iconify-icon icon="material-symbols:info-outline" style="margin-right: 8px; vertical-align: middle;"></iconify-icon>
                    Tips Mengisi Form
                </h3>
                <ul style="margin: 0; padding-left: 24px; color: #4b5563;">
                    <li style="margin-bottom: 8px;"><strong>Kelas & Instruktur:</strong> Pastikan sudah terdaftar di sistem</li>
                    <li style="margin-bottom: 8px;"><strong>Tanggal & Jam:</strong> Periksa ulang agar tidak ada konflik jadwal</li>
                    <li><strong>Materi:</strong> Tuliskan topik atau materi yang akan diajarkan untuk kemudahan peserta</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php include "../../includes/footer.php"; ?>
