<?php
include "../../config/database.php";
include "../../includes/header.php";
include "../../includes/sidebar.php";

$query = "
    SELECT jadwal.*, kelas.nama_kelas AS nama_kelas, instruktur.nama_instruktur AS nama_instruktur 
    FROM jadwal
    JOIN kelas ON jadwal.kelas_id = kelas.kelas_id
    JOIN instruktur ON jadwal.instruktur_id = instruktur.instruktur_id
    ORDER BY tanggal DESC, jam_mulai DESC
";

$result = mysqli_query($conn, $query);
if (!$result) {
    error_log("Jadwal query error: " . mysqli_error($conn));
    $result = false;
}
?>

<div class="content">
    <div class="dashboard-container fade-in">
        <div class="dashboard-header">
            <h2>
                <iconify-icon icon="material-symbols:calendar-month-outline"></iconify-icon>
                Data Jadwal Pelatihan Laboratorium Teknologi Informasi dan Komunikasi
            </h2>
            <p class="dashboard-subtitle">Pengelolaan Jadwal Kelas dan Instruktur TIK</p>
        </div>

        <div style="margin-bottom: 24px;">
            <a href="tambah.php" class="btn btn-primary">
                <iconify-icon icon="material-symbols:add-box-outline"></iconify-icon>
                Tambah Jadwal
            </a>
        </div>

        <div class="content-card">
            <table class="modern-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kelas</th>
                        <th>Instruktur</th>
                        <th>Tanggal</th>
                        <th>Jam</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no=1; while($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td>
                            <span style="background: #f1f5f9; color: #6b7280; padding: 4px 8px; border-radius: 6px; font-size: 12px; font-weight: 600;">
                                <?= $no++; ?>
                            </span>
                        </td>
                        <td>
                            <div style="font-weight: 600; color: #1f2937;">
                                <?= htmlspecialchars($row['nama_kelas']); ?>
                            </div>
                        </td>
                        <td>
                            <div style="color: #6b7280;">
                                <?= htmlspecialchars($row['nama_instruktur']); ?>
                            </div>
                        </td>
                        <td><?= date('d-m-Y', strtotime($row['tanggal'])); ?></td>
                        <td><?= $row['jam_mulai']; ?> - <?= $row['jam_selesai']; ?></td>
                        <td>
                            <a href="edit.php?id=<?= $row['jadwal_id']; ?>" 
                               style="color: #8b5cf6; text-decoration: none; font-weight: 600; margin-right: 12px;">
                                <iconify-icon icon="material-symbols:edit-outline"></iconify-icon>
                                Edit
                            </a>
                            <a href="hapus.php?id=<?= $row['jadwal_id']; ?>" 
                               onclick="return confirm('Yakin hapus jadwal ini?')"
                               style="color: #dc2626; text-decoration: none; font-weight: 600;">
                                <iconify-icon icon="material-symbols:delete-outline"></iconify-icon>
                                Hapus
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include "../../includes/footer.php"; ?>
