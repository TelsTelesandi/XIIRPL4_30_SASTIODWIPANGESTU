<?php 
include '../config/database.php';
include '../config/app.php'; // Include config untuk app_url()
include '../includes/header.php'; 
include '../includes/sidebar.php';


try {
    // Get total instruktur
    $result_instruktur = mysqli_query($conn, "SELECT COUNT(*) as total FROM instruktur");
    if (!$result_instruktur) {
        error_log("Instruktur query error: " . mysqli_error($conn));
        $total_instruktur = 0;
    } else {
        $data_instruktur = mysqli_fetch_assoc($result_instruktur);
        $total_instruktur = $data_instruktur['total'] ?? 0;
    }

    // Get total kelas
    $result_kelas = mysqli_query($conn, "SELECT COUNT(*) as total FROM kelas");
    if (!$result_kelas) {
        error_log("Kelas query error: " . mysqli_error($conn));
        $total_kelas = 0;
    } else {
        $data_kelas = mysqli_fetch_assoc($result_kelas);
        $total_kelas = $data_kelas['total'] ?? 0;
    }

    // Get total jadwal - Show all jadwal
    $result_jadwal = mysqli_query($conn, "SELECT COUNT(*) as total FROM jadwal");
    if (!$result_jadwal) {
        error_log("Jadwal query error: " . mysqli_error($conn));
        $total_jadwal = 0;
    } else {
        $data_jadwal = mysqli_fetch_assoc($result_jadwal);
        $total_jadwal = $data_jadwal['total'] ?? 0;
    }

    // Debug info
    error_log("Dashboard stats - Instruktur: $total_instruktur, Kelas: $total_kelas, Jadwal: $total_jadwal");

    // Get upcoming schedules - konsisten dengan halaman jadwal (JOIN ke kelas & instruktur)
    $result_jadwal_terdekat = mysqli_query($conn, "
        SELECT j.jadwal_id, j.tanggal, j.jam_mulai, j.jam_selesai, 
               k.nama_kelas AS nama_kelas, i.nama_instruktur AS nama_instruktur
        FROM jadwal j 
            JOIN kelas k ON j.kelas_id = k.kelas_id
            JOIN instruktur i ON j.instruktur_id = i.instruktur_id
        ORDER BY j.tanggal ASC, j.jam_mulai ASC
        LIMIT 5
    ");

    $jadwal_terdekat = [];
    if ($result_jadwal_terdekat) {
        while ($row = mysqli_fetch_assoc($result_jadwal_terdekat)) {
            $jadwal_terdekat[] = $row;
        }
        error_log("Found " . count($jadwal_terdekat) . " jadwal untuk ditampilkan");
    } else {
        error_log("Jadwal terdekat query error: " . mysqli_error($conn));
    }

    // Get attendance statistics for chart - diselaraskan dengan perhitungan di halaman absensi
    $result_absensi = mysqli_query($conn, "
        SELECT 
            i.instruktur_id, 
            i.nama_instruktur, 
            SUM(a.status='Hadir') AS total_hadir,
            SUM(a.status='Izin') AS total_izin,
            SUM(a.status='Sakit') AS total_sakit,
            SUM(a.status='Alfa') AS total_alfa,
            COUNT(a.absensi_id) AS total_absensi
        FROM instruktur i 
        LEFT JOIN absensi a ON i.instruktur_id = a.instruktur_id
        GROUP BY i.instruktur_id, i.nama_instruktur
        HAVING total_absensi > 0
        ORDER BY total_hadir DESC
        LIMIT 10
    ");

    $data_absensi = [];
    if ($result_absensi) {
        while ($row = mysqli_fetch_assoc($result_absensi)) {
            $data_absensi[] = $row;
        }
        error_log("Found " . count($data_absensi) . " instruktur dengan absensi data");
    } else {
        error_log("Absensi query error: " . mysqli_error($conn));
    }

} catch (Exception $e) {
    // Fallback to default values if database error
    error_log("Dashboard error: " . $e->getMessage());
    $total_instruktur = 0;
    $total_kelas = 0;
    $total_jadwal = 0;
    $jadwal_terdekat = [];
    $data_absensi = [];
}
?>

<div class="content">
    <div class="dashboard-container fade-in">
        <!-- Official Government Dashboard Header -->
        <div class="dashboard-header">
            <div class="header-content">
                <div class="header-info">
                    <h1 class="dashboard-title">Dashboard Sistem Informasi Admin TIK</h1>
                    <p class="dashboard-subtitle">Balai Besar Pelatihan Vokasi dan Produktivitas - Bekasi</p>
                    <p class="dashboard-description">Kementerian Ketenagakerjaan Republik Indonesia</p>
                </div>
                <div class="header-time">
                    <div id="tanggal" class="time-date"></div>
                    <div id="jam" class="time-time"></div>
                </div>
            </div>
        </div>

        <script>
            function updateTime() {
                const now = new Date();
                const tanggal = now.toLocaleDateString('id-ID', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });
                const waktu = now.toLocaleTimeString('id-ID', { hour12: false });
                document.getElementById('tanggal').textContent = tanggal;
                document.getElementById('jam').textContent = waktu + ' WIB';
            }
            setInterval(updateTime, 1000);
            updateTime();
        </script>

        <!-- Official Statistics Overview -->
        <div class="stats-grid">
            <!-- Card Instruktur -->
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-card-info">
                        <h3 class="stat-title">Total Instruktur</h3>
                        <div class="stat-value"><?php echo $total_instruktur; ?></div>
                    </div>
                    <div class="stat-card-icon" style="background: #eff6ff;">
                        <!-- Added logo image instead of icon -->
                        <img src="<?php echo app_url('/assets/images/logo_Instruktur.png'); ?>" alt="Logo instruktur" style="width: 40px; height: 40px; object-fit: contain;">
                    </div>
                </div>
                <p class="stat-description">Pengajar aktif</p>
            </div>

            <!-- Card Kelas -->
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-card-info">
                        <h3 class="stat-title">Total Kelas</h3>
                        <div class="stat-value"><?php echo $total_kelas; ?></div>
                    </div>
                    <div class="stat-card-icon" style="background: #ecfdf5;">
                        <iconify-icon icon="material-symbols:school-outline" style="font-size: 28px; color: #059669;"></iconify-icon>
                    </div>
                </div>
                <p class="stat-description">Program pelatihan</p>
            </div>

            <!-- Card Jadwal -->
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-card-info">
                        <h3 class="stat-title">Total Jadwal</h3>
                        <div class="stat-value"><?php echo $total_jadwal; ?></div>
                    </div>
                    <div class="stat-card-icon" style="background: #fef2f2;">
                        <iconify-icon icon="material-symbols:calendar-month-outline" style="font-size: 28px; color: #dc2626;"></iconify-icon>
                    </div>
                </div>
                <p class="stat-description">Jadwal keseluruhan</p>
            </div>
        </div>

        <!-- Jadwal Terkini Section -->
        <div class="content-card">
            <h3 class="content-card-title">
                <iconify-icon icon="material-symbols:calendar-month-outline" style="font-size: 20px; color: #2563eb;"></iconify-icon>
                Jadwal Pelatihan Terkini
            </h3>
            <div class="content-card-body">
                <?php if (!empty($jadwal_terdekat)): ?>
                <table class="modern-table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Kelas</th>
                            <th>Instruktur</th>
                            <th>Waktu</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; foreach ($jadwal_terdekat as $jadwal): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo date('d/m/Y', strtotime($jadwal['tanggal'])); ?></td>
                            <td class="bold"><?php echo htmlspecialchars($jadwal['nama_kelas']); ?></td>
                            <td><?php echo htmlspecialchars($jadwal['nama_instruktur']); ?></td>
                            <td><?php echo $jadwal['jam_mulai']; ?> - <?php echo $jadwal['jam_selesai']; ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="content-card-footer">
                    <a href="jadwal/index.php" class="btn btn-primary">
                        Lihat Semua Jadwal →
                    </a>
                </div>
                <?php else: ?>
                <div class="content-card-empty">
                    <iconify-icon icon="material-symbols:calendar-today-outline" style="font-size: 48px; color: #9ca3af; margin-bottom: 12px;"></iconify-icon>
                    <div class="empty-title">Tidak ada data jadwal</div>
                    <div class="empty-description">Belum terdapat jadwal pelatihan yang terdaftar</div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Grafik Kehadiran Section -->
        <div class="content-card">
            <h3 class="content-card-title">
                <iconify-icon icon="material-symbols:bar-chart-4-bars" style="font-size: 20px; color: #059669;"></iconify-icon>
                Grafik Rekapitulasi Kehadiran Instruktur
            </h3>
            <div class="content-card-body">
                <canvas id="grafikKehadiran"></canvas>
                <?php if (empty($data_absensi)): ?>
                <div class="content-card-empty">
                    <iconify-icon icon="material-symbols:bar-chart-outline" style="font-size: 48px; color: #d1d5db; margin-bottom: 12px;"></iconify-icon>
                    <div class="empty-title">Data kehadiran belum tersedia</div>
                    <div class="empty-description">Tidak ada data absensi untuk ditampilkan dalam grafik</div>
                </div>
                <?php endif; ?>
            </div>
            <div class="content-card-footer">
                <a href="laporan/absensi.php" class="btn btn-primary">
                    Lihat Laporan Lengkap →
                </a>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="content-card">
            <h3 class="content-card-title">
                <iconify-icon icon="material-symbols:menu-open" style="font-size: 20px; color: #dc2626;"></iconify-icon>
                Menu Operasional
            </h3>
            <div class="quick-actions-grid">
                <a href="instruktur/tambah.php" class="quick-action-card">
                    <div class="icon"><iconify-icon icon="material-symbols:person-add-outline" style="font-size: 24px;"></iconify-icon></div>
                    <div>Tambah Instruktur</div>
                </a>
                <a href="kelas/tambah.php" class="quick-action-card">
                    <div class="icon"><iconify-icon icon="material-symbols:add-box-outline" style="font-size: 24px;"></iconify-icon></div>
                    <div>Tambah Kelas</div>
                </a>
                <a href="jadwal/tambah.php" class="quick-action-card">
                    <div class="icon"><iconify-icon icon="material-symbols:event-available-outline" style="font-size: 24px;"></iconify-icon></div>
                    <div>Tambah Jadwal</div>
                </a>
                <a href="notifikasi.php" class="quick-action-card">
                    <div class="icon"><iconify-icon icon="material-symbols:notifications-active-outline" style="font-size: 24px;"></iconify-icon></div>
                    <div>Notifikasi</div>
                </a>
            </div>
        </div>
    </div>
</div>

<!-- ChartJS -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const ctx = document.getElementById('grafikKehadiran').getContext('2d');
        
        const attendanceData = <?php echo json_encode($data_absensi); ?>;
        
        // Check if we have data
        if (attendanceData.length === 0) {
            // Hide the canvas and show message
            ctx.canvas.style.display = 'none';
            return;
        }
        
        const labels = attendanceData.map(item => item.nama_instruktur);
        const hadirData = attendanceData.map(item => parseInt(item.total_hadir));
        const izinData = attendanceData.map(item => parseInt(item.total_izin));
        const sakitData = attendanceData.map(item => parseInt(item.total_sakit));
        const alfaData = attendanceData.map(item => parseInt(item.total_alfa));
        
        const gradient1 = ctx.createLinearGradient(0, 0, 0, 300);
        gradient1.addColorStop(0, 'rgba(139, 92, 246, 0.8)');
        gradient1.addColorStop(1, 'rgba(168, 85, 247, 0.8)');
        
        const gradient2 = ctx.createLinearGradient(0, 0, 0, 300);
        gradient2.addColorStop(0, 'rgba(34, 197, 94, 0.8)');
        gradient2.addColorStop(1, 'rgba(22, 163, 74, 0.8)');
        
        const gradient3 = ctx.createLinearGradient(0, 0, 0, 300);
        gradient3.addColorStop(0, 'rgba(249, 115, 22, 0.8)');
        gradient3.addColorStop(1, 'rgba(234, 88, 12, 0.8)');
        
        // Generate colors for multiple instructors
        const colors = [gradient1, gradient2, gradient3];
        const borderColors = ['#8b5cf6', '#22c55e', '#f97316'];
        
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Hadir',
                        data: hadirData,
                        backgroundColor: 'rgba(34, 197, 94, 0.8)',
                        borderColor: '#22c55e',
                        borderWidth: 1,
                        borderRadius: 4,
                    },
                    {
                        label: 'Izin',
                        data: izinData,
                        backgroundColor: 'rgba(249, 115, 22, 0.8)',
                        borderColor: '#f97316',
                        borderWidth: 1,
                        borderRadius: 4,
                    },
                    {
                        label: 'Sakit',
                        data: sakitData,
                        backgroundColor: 'rgba(59, 130, 246, 0.8)',
                        borderColor: '#3b82f6',
                        borderWidth: 1,
                        borderRadius: 4,
                    },
                    {
                        label: 'Alfa',
                        data: alfaData,
                        backgroundColor: 'rgba(239, 68, 68, 0.8)',
                        borderColor: '#ef4444',
                        borderWidth: 1,
                        borderRadius: 4,
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { 
                    legend: { 
                        display: true,
                        position: 'top',
                        labels: {
                            usePointStyle: true,
                            padding: 20,
                            font: {
                                size: 12,
                                weight: '500'
                            }
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(31, 41, 55, 0.9)',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        borderColor: '#8b5cf6',
                        borderWidth: 1,
                        cornerRadius: 8,
                        displayColors: true,
                        callbacks: {
                            title: function(context) {
                                return '📊 ' + context[0].label;
                            },
                            label: function(context) {
                                return context.dataset.label + ': ' + context.parsed.y + ' kali';
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        stacked: true,
                        grid: {
                            display: false,
                        },
                        ticks: {
                            color: '#6b7280',
                            font: {
                                size: 12,
                                weight: '500'
                            }
                        }
                    },
                    y: {
                        stacked: true,
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(229, 231, 235, 0.5)',
                            drawBorder: false,
                        },
                        ticks: {
                            color: '#6b7280',
                            font: {
                                size: 12,
                                weight: '500'
                            }
                        }
                    }
                },
                animation: {
                    duration: 1500,
                    easing: 'easeInOutQuart',
                    delay: (context) => {
                        let delay = 0;
                        if (context.type === 'data' && context.mode === 'default') {
                            delay = context.dataIndex * 200;
                        }
                        return delay;
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
    });
</script>

<?php include '../includes/footer.php'; ?>
