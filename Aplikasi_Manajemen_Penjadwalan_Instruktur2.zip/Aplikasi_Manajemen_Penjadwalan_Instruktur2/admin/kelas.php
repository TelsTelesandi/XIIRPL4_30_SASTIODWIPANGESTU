<?php
include "../config/database.php";
include "../includes/header.php";
include "../includes/sidebar.php";

$sql = "SELECT * FROM kelas ORDER BY nama ASC";
$result = mysqli_query($conn, $sql);
?>

<h2>🏫 Data Kelas</h2>
<a href="kelas/tambah.php">➕ Tambah Kelas</a>
<table border="1" cellspacing="0" cellpadding="8" width="100%">
    <tr style="background:#023e8a; color:white;">
        <th>No</th>
        <th>Nama Kelas</th>
        <th>Deskripsi</th>
        <th>Aksi</th>
    </tr>
    <?php $no=1; while($row=mysqli_fetch_assoc($result)): ?>
    <tr>
        <td><?= $no++; ?></td>
        <td><?= $row['nama']; ?></td>
        <td><?= $row['deskripsi']; ?></td>
        <td>
            <a href="kelas/edit.php?id=<?= $row['id']; ?>">✏️ Edit</a> | 
            <a href="kelas/hapus.php?id=<?= $row['id']; ?>" onclick="return confirm('Yakin hapus data ini?')">🗑️ Hapus</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

<?php include "../includes/footer.php"; ?>








