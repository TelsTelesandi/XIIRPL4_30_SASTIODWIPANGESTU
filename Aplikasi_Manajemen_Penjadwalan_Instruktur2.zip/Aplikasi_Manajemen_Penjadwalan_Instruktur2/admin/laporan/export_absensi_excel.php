<?php
include "../../config/database.php";

function formatBulanIndonesia(string $ym): string {
    $namaBulan = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
    ];

    if (!preg_match('/^\d{4}-\d{2}$/', $ym)) {
        $ym = date('Y-m');
    }

    $timestamp = strtotime($ym . '-01');
    $bulan = $namaBulan[(int) date('n', $timestamp)] ?? date('F', $timestamp);
    $tahun = date('Y', $timestamp);

    return $bulan . ' ' . $tahun;
}

$selectedMonthInput = $_GET['bulan'] ?? date('Y-m');
if (!preg_match('/^\d{4}-\d{2}$/', $selectedMonthInput)) {
    $selectedMonthInput = date('Y-m');
}
$selectedTimestamp = strtotime($selectedMonthInput . '-01');
$filterYear = (int) date('Y', $selectedTimestamp);
$filterMonth = (int) date('n', $selectedTimestamp);
$periodeLabel = formatBulanIndonesia($selectedMonthInput);

$sql = "SELECT a.*, i.nama_instruktur AS instruktur 
        FROM absensi a 
        JOIN instruktur i ON a.instruktur_id = i.instruktur_id 
        WHERE YEAR(a.tanggal) = {$filterYear} AND MONTH(a.tanggal) = {$filterMonth}
        ORDER BY a.tanggal DESC";

$result = mysqli_query($conn, $sql);
$data = [];

if($result && mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
}

$filename = 'Laporan_Absensi_' . $selectedMonthInput . '_' . date('His') . '.csv';

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');

$output = fopen('php://output', 'w');
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM UTF-8

// Header
fputcsv($output, ['Laporan Absensi Instruktur'], ';');
fputcsv($output, ['Periode Data: ' . $periodeLabel], ';');
fputcsv($output, ['Tanggal Cetak: ' . date('d-m-Y H:i:s')], ';');
fputcsv($output, [], ';');

// Column headers
fputcsv($output, ['No', 'Nama Instruktur', 'Tanggal', 'Status'], ';');

// Data
$no = 1;
foreach($data as $row) {
    fputcsv($output, [
        $no++,
        $row['instruktur'],
        date('d-m-Y', strtotime($row['tanggal'])),
        ucfirst($row['status'])
    ], ';');
}

fclose($output);
mysqli_close($conn);
?>
