<?php
include "../../config/database.php";

function formatTanggalIndonesia(int $timestamp, bool $denganWaktu = false): string {
    $namaBulan = [
        1 => 'Januari',
        2 => 'Februari',
        3 => 'Maret',
        4 => 'April',
        5 => 'Mei',
        6 => 'Juni',
        7 => 'Juli',
        8 => 'Agustus',
        9 => 'September',
        10 => 'Oktober',
        11 => 'November',
        12 => 'Desember'
    ];

    $tanggal = date('d', $timestamp);
    $bulan = $namaBulan[(int) date('n', $timestamp)] ?? date('F', $timestamp);
    $tahun = date('Y', $timestamp);
    $hasil = $tanggal . ' ' . $bulan . ' ' . $tahun;

    if ($denganWaktu) {
        $hasil .= ' ' . date('H:i:s', $timestamp);
    }

    return $hasil;
}

function formatBulanIndonesia(string $ym): string {
    $namaBulan = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
    ];

    if (!preg_match('/^\d{4}-\d{2}$/', $ym)) {
        $ym = date('Y-m');
    }

    $timestamp = strtotime($ym . '-01');
    $bulan = $namaBulan[(int) date('n', $timestamp)] ?? date('F', $timestamp);
    $tahun = date('Y', $timestamp);

    return $bulan . ' ' . $tahun;
}

$selectedMonthInput = $_GET['bulan'] ?? date('Y-m');
if (!preg_match('/^\d{4}-\d{2}$/', $selectedMonthInput)) {
    $selectedMonthInput = date('Y-m');
}
$selectedTimestamp = strtotime($selectedMonthInput . '-01');
$filterYear = (int) date('Y', $selectedTimestamp);
$filterMonth = (int) date('n', $selectedTimestamp);
$periodeLabel = formatBulanIndonesia($selectedMonthInput);

$sql = "SELECT j.*, k.nama_kelas AS kelas, i.nama_instruktur AS instruktur 
        FROM jadwal j 
        JOIN kelas k ON j.kelas_id = k.kelas_id
        JOIN instruktur i ON j.instruktur_id = i.instruktur_id
        WHERE YEAR(j.tanggal) = {$filterYear} AND MONTH(j.tanggal) = {$filterMonth}
        ORDER BY j.tanggal DESC";

$result = mysqli_query($conn, $sql);
$data = [];

if($result && mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
}

$timestampSekarang = time();
$tanggalCetak = formatTanggalIndonesia($timestampSekarang, true);
$tanggalTtd = formatTanggalIndonesia($timestampSekarang);

$filename = 'Laporan_Jadwal_' . $selectedMonthInput . '_' . date('His') . '.csv';

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');

$output = fopen('php://output', 'w');
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM UTF-8

// Kop laporan
fputcsv($output, ['Balai Besar Pelatihan Vokasi dan Produktivitas Bekasi'], ';');
fputcsv($output, ['Kementerian Ketenagakerjaan Republik Indonesia'], ';');
fputcsv($output, [], ';');

// Header utama
fputcsv($output, ['Laporan Jadwal Pelatihan'], ';');
fputcsv($output, ['Periode Data: ' . $periodeLabel], ';');
fputcsv($output, ['Tanggal Cetak: ' . $tanggalCetak], ';');
fputcsv($output, [], ';');

// Column headers
fputcsv($output, ['No', 'Kelas', 'Instruktur', 'Tanggal', 'Jam'], ';');

// Data
$no = 1;
foreach($data as $row) {
    fputcsv($output, [
        $no++,
        $row['kelas'],
        $row['instruktur'],
        formatTanggalIndonesia(strtotime($row['tanggal'])),
        $row['jam_mulai'] . ' - ' . $row['jam_selesai']
    ], ';');
}

// Signature placeholder
fputcsv($output, [], ';');
fputcsv($output, ['Bekasi, ' . $tanggalTtd], ';');
fputcsv($output, ['Mengetahui,'], ';');
fputcsv($output, ['Kepala BBPVP Bekasi'], ';');
fputcsv($output, [], ';');
fputcsv($output, ['(........................................)'], ';');

fclose($output);
mysqli_close($conn);
?>
