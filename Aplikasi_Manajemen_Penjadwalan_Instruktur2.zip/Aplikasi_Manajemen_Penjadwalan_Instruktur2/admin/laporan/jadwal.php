<?php
include "../../config/database.php";
include "../../includes/header.php";
include "../../includes/sidebar.php";

function formatBulanIndonesia(string $ym): string {
    $namaBulan = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
    ];

    if (!preg_match('/^\d{4}-\d{2}$/', $ym)) {
        $ym = date('Y-m');
    }

    $timestamp = strtotime($ym . '-01');
    $bulan = $namaBulan[(int) date('n', $timestamp)] ?? date('F', $timestamp);
    $tahun = date('Y', $timestamp);

    return $bulan . ' ' . $tahun;
}

$selectedMonthInput = $_GET['bulan'] ?? date('Y-m');
if (!preg_match('/^\d{4}-\d{2}$/', $selectedMonthInput)) {
    $selectedMonthInput = date('Y-m');
}

$selectedTimestamp = strtotime($selectedMonthInput . '-01');
$filterYear = (int) date('Y', $selectedTimestamp);
$filterMonth = (int) date('n', $selectedTimestamp);
$periodeLabel = formatBulanIndonesia($selectedMonthInput);

$sql = "SELECT j.*, k.nama_kelas AS kelas, i.nama_instruktur AS instruktur 
        FROM jadwal j 
        JOIN kelas k ON j.kelas_id = k.kelas_id
        JOIN instruktur i ON j.instruktur_id = i.instruktur_id
        WHERE YEAR(j.tanggal) = {$filterYear} AND MONTH(j.tanggal) = {$filterMonth}
        ORDER BY j.tanggal DESC";
$result = mysqli_query($conn, $sql);
?>

<div class="content">
    <div class="dashboard-container fade-in">
        <div class="dashboard-header">
            <h2>
                <iconify-icon icon="material-symbols:description-outline"></iconify-icon>
                Laporan Jadwal
            </h2>
            <p class="dashboard-subtitle">Laporan jadwal pelatihan periode <?= htmlspecialchars($periodeLabel); ?></p>
        </div>

        <div class="content-card" style="margin-bottom: 20px; padding: 20px;">
            <form method="get" class="filter-form" style="display: flex; flex-wrap: wrap; gap: 16px; align-items: flex-end;">
                <div style="display: flex; flex-direction: column; gap: 8px;">
                    <label for="bulan" style="font-weight: 600; color: #374151;">Pilih Bulan</label>
                    <input 
                        type="month" 
                        name="bulan" 
                        id="bulan" 
                        max="<?= date('Y-m'); ?>"
                        value="<?= htmlspecialchars($selectedMonthInput); ?>" 
                        style="padding: 10px 14px; border: 1px solid #d1d5db; border-radius: 10px; font-size: 14px; min-width: 220px;"
                        required
                    >
                </div>
                <div style="display: flex; gap: 10px;">
                    <button type="submit" class="btn btn-primary" style="height: 42px;">
                        <iconify-icon icon="material-symbols:filter-alt-outline"></iconify-icon>
                        Terapkan
                    </button>
                    <a href="jadwal.php" class="btn btn-ghost" style="height: 42px;">
                        Reset
                    </a>
                </div>
            </form>
        </div>

        <!-- Export buttons to honor current filter -->
        <div style="margin-bottom: 24px; display: flex; gap: 12px; flex-wrap: wrap;">
            <a href="export_jadwal_pdf.php?bulan=<?= urlencode($selectedMonthInput); ?>" class="btn btn-secondary" title="Export ke PDF" target="_blank">
                <iconify-icon icon="material-symbols:picture-as-pdf-outline"></iconify-icon>
                Unduh PDF
            </a>
            <a href="export_jadwal_excel.php?bulan=<?= urlencode($selectedMonthInput); ?>" class="btn btn-secondary" title="Export ke Excel">
                <iconify-icon icon="material-symbols:description-outline"></iconify-icon>
                Unduh Excel
            </a>
        </div>

        <div class="content-card">
            <table class="modern-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kelas</th>
                        <th>Instruktur</th>
                        <th>Tanggal</th>
                        <th>Jam</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($result && mysqli_num_rows($result) > 0): ?>
                        <?php $no=1; while($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td>
                                <span style="background: #f1f5f9; color: #6b7280; padding: 4px 8px; border-radius: 6px; font-size: 12px; font-weight: 600;">
                                    <?= $no++; ?>
                                </span>
                            </td>
                            <td><?= htmlspecialchars($row['kelas']); ?></td>
                            <td><?= htmlspecialchars($row['instruktur']); ?></td>
                            <td><?= date("d-m-Y", strtotime($row['tanggal'])); ?></td>
                            <td><?= $row['jam_mulai'] . " - " . $row['jam_selesai']; ?></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" style="text-align: center; color: #6b7280; padding: 40px;">
                                <iconify-icon icon="material-symbols:assignment-off-outline" style="font-size: 48px; margin-bottom: 16px;"></iconify-icon>
                                <div>Belum ada data jadwal pada periode <?= htmlspecialchars($periodeLabel); ?></div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include "../../includes/footer.php"; ?>
