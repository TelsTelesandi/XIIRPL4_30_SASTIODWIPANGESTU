<?php
include "../../config/database.php";
include "../../includes/header.php";
include "../../includes/sidebar.php";

function formatBulanIndonesia(string $ym): string {
    $namaBulan = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
    ];

    if (!preg_match('/^\d{4}-\d{2}$/', $ym)) {
        $ym = date('Y-m');
    }

    $timestamp = strtotime($ym . '-01');
    $bulan = $namaBulan[(int) date('n', $timestamp)] ?? date('F', $timestamp);
    $tahun = date('Y', $timestamp);

    return $bulan . ' ' . $tahun;
}

$selectedMonthInput = $_GET['bulan'] ?? date('Y-m');
if (!preg_match('/^\d{4}-\d{2}$/', $selectedMonthInput)) {
    $selectedMonthInput = date('Y-m');
}

$selectedTimestamp = strtotime($selectedMonthInput . '-01');
$filterYear = (int) date('Y', $selectedTimestamp);
$filterMonth = (int) date('n', $selectedTimestamp);
$periodeLabel = formatBulanIndonesia($selectedMonthInput);

$sql = "SELECT a.*, i.nama_instruktur AS instruktur 
        FROM absensi a 
        JOIN instruktur i ON a.instruktur_id = i.instruktur_id 
        WHERE YEAR(a.tanggal) = {$filterYear} AND MONTH(a.tanggal) = {$filterMonth}
        ORDER BY a.tanggal DESC";

$result = mysqli_query($conn, $sql);
?>

<div class="content">
    <div class="dashboard-container fade-in">
        <div class="dashboard-header">
            <h2>
                <iconify-icon icon="material-symbols:analytics-outline"></iconify-icon>
                Laporan Absensi
            </h2>
            <p class="dashboard-subtitle">Laporan kehadiran instruktur periode <?= htmlspecialchars($periodeLabel); ?></p>
        </div>

        <div class="content-card" style="margin-bottom: 20px; padding: 20px;">
            <form method="get" class="filter-form" style="display: flex; flex-wrap: wrap; gap: 16px; align-items: flex-end;">
                <div style="display: flex; flex-direction: column; gap: 8px;">
                    <label for="bulan" style="font-weight: 600; color: #374151;">Pilih Bulan</label>
                    <input 
                        type="month" 
                        name="bulan" 
                        id="bulan" 
                        max="<?= date('Y-m'); ?>"
                        value="<?= htmlspecialchars($selectedMonthInput); ?>" 
                        style="padding: 10px 14px; border: 1px solid #d1d5db; border-radius: 10px; font-size: 14px; min-width: 220px;"
                        required
                    >
                </div>
                <div style="display: flex; gap: 10px;">
                    <button type="submit" class="btn btn-primary" style="height: 42px;">
                        <iconify-icon icon="material-symbols:filter-alt-outline"></iconify-icon>
                        Terapkan
                    </button>
                    <a href="absensi.php" class="btn btn-ghost" style="height: 42px;">
                        Reset
                    </a>
                </div>
            </form>
        </div>

        <!-- Export buttons -->
        <div style="margin-bottom: 24px; display: flex; gap: 12px; flex-wrap: wrap;">
            <a href="export_absensi_pdf.php?bulan=<?= urlencode($selectedMonthInput); ?>" class="btn btn-secondary" title="Export ke PDF" target="_blank">
                <iconify-icon icon="material-symbols:picture-as-pdf-outline"></iconify-icon>
                Unduh PDF
            </a>
            <a href="export_absensi_excel.php?bulan=<?= urlencode($selectedMonthInput); ?>" class="btn btn-secondary" title="Export ke Excel">
                <iconify-icon icon="material-symbols:description-outline"></iconify-icon>
                Unduh Excel
            </a>
        </div>

        <div class="content-card">
            <table class="modern-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Instruktur</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($result && mysqli_num_rows($result) > 0): ?>
                        <?php $no=1; while($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td>
                                <span style="background: #f1f5f9; color: #6b7280; padding: 4px 8px; border-radius: 6px; font-size: 12px; font-weight: 600;">
                                    <?= $no++; ?>
                                </span>
                            </td>
                            <td>
                                <div style="font-weight: 600; color: #1f2937;">
                                    <?= htmlspecialchars($row['instruktur']); ?>
                                </div>
                            </td>
                            <td><?= date("d-m-Y", strtotime($row['tanggal'])); ?></td>
                            <td>
                                <?php 
                                $status = strtolower($row['status']);
                                $badge_color = '';
                                switch($status) {
                                    case 'hadir':
                                        $badge_color = 'background: #dcfce7; color: #16a34a;';
                                        break;
                                    case 'izin':
                                    case 'sakit':
                                        $badge_color = 'background: #fef3c7; color: #d97706;';
                                        break;
                                    case 'alfa':
                                        $badge_color = 'background: #fee2e2; color: #dc2626;';
                                        break;
                                    default:
                                        $badge_color = 'background: #f1f5f9; color: #6b7280;';
                                }
                                ?>
                                <span style="<?= $badge_color ?> padding: 4px 8px; border-radius: 6px; font-size: 12px; font-weight: 600;">
                                    <?= ucfirst($row['status']); ?>
                                </span>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" style="text-align: center; color: #6b7280; padding: 40px;">
                                <iconify-icon icon="material-symbols:assignment-off-outline" style="font-size: 48px; margin-bottom: 16px;"></iconify-icon>
                                <div>Belum ada data absensi pada periode <?= htmlspecialchars($periodeLabel); ?></div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include "../../includes/footer.php"; ?>
