<?php
include "../../config/database.php";

function formatBulanIndonesia(string $ym): string {
    $namaBulan = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
    ];

    if (!preg_match('/^\d{4}-\d{2}$/', $ym)) {
        $ym = date('Y-m');
    }

    $timestamp = strtotime($ym . '-01');
    $bulan = $namaBulan[(int) date('n', $timestamp)] ?? date('F', $timestamp);
    $tahun = date('Y', $timestamp);

    return $bulan . ' ' . $tahun;
}

$selectedMonthInput = $_GET['bulan'] ?? date('Y-m');
if (!preg_match('/^\d{4}-\d{2}$/', $selectedMonthInput)) {
    $selectedMonthInput = date('Y-m');
}
$selectedTimestamp = strtotime($selectedMonthInput . '-01');
$filterYear = (int) date('Y', $selectedTimestamp);
$filterMonth = (int) date('n', $selectedTimestamp);
$periodeLabel = formatBulanIndonesia($selectedMonthInput);

$sql = "SELECT j.*, k.nama_kelas AS kelas, i.nama_instruktur AS instruktur 
        FROM jadwal j 
        JOIN kelas k ON j.kelas_id = k.kelas_id
        JOIN instruktur i ON j.instruktur_id = i.instruktur_id
        WHERE YEAR(j.tanggal) = {$filterYear} AND MONTH(j.tanggal) = {$filterMonth}
        ORDER BY j.tanggal DESC";

$result = mysqli_query($conn, $sql);
$data = [];

if($result && mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
}

$tanggalCetak = date('d-m-Y H:i:s');
$logoPublicPath = '../../assets/images/logo-bbpvp.png';
$logoFilePath = __DIR__ . '/../../assets/images/logo-bbpvp.png';
$logoElement = '<div class="logo-fallback">BBPVP</div>';

if (file_exists($logoFilePath)) {
    $logoElement = '<img src="' . $logoPublicPath . '" alt="Logo BBPVP Bekasi" />';
}

$html = '
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <style>
        @page {
            size: A4;
            margin: 20mm;
        }
        :root {
            --primary: #2563eb;
            --accent: #1d4ed8;
            --text: #1f2937;
            --muted: #6b7280;
            --surface: #ffffff;
            --ring: #c7d2fe;
            --ring-strong: #93c5fd;
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            padding: 0;
            font-family: "Inter", "Segoe UI", Arial, sans-serif;
            background: #fff;
            color: var(--text);
        }
        .report-shell {
            width: 100%;
            background: var(--surface);
            border: 1.5px solid var(--ring);
            border-radius: 12px;
            padding: 24px 26px 18px;
        }
        .report-header {
            display: flex;
            align-items: center;
            gap: 16px;
            padding-bottom: 18px;
            border-bottom: 1px solid var(--ring);
            margin-bottom: 20px;
        }
        .report-header img {
            width: 64px;
            height: 64px;
            border-radius: 16px;
            object-fit: cover;
        }
        .logo-fallback {
            width: 64px;
            height: 64px;
            border-radius: 16px;
            background: linear-gradient(135deg, var(--primary), var(--accent));
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-weight: 800;
            font-size: 14px;
            letter-spacing: 0.8px;
        }
        .brand-text {
            display: grid;
            gap: 4px;
        }
        .brand-text strong {
            font-size: 16px;
            font-weight: 800;
            letter-spacing: .2px;
        }
        .brand-text span {
            font-size: 13px;
            color: var(--muted);
        }
        .report-meta {
            margin-bottom: 16px;
        }
        .report-meta h2 {
            margin: 0;
            font-size: 22px;
            font-weight: 800;
        }
        .report-meta p {
            margin: 6px 0 0;
            color: var(--muted);
            font-size: 13px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            border: 1px solid var(--ring);
        }
        thead {
            background: linear-gradient(135deg, var(--primary), var(--accent));
            color: #fff;
        }
        th, td {
            padding: 10px 12px;
            font-size: 12px;
        }
        th {
            text-align: left;
            font-weight: 700;
            letter-spacing: .2px;
        }
        th.text-center, td.text-center {
            text-align: center;
        }
        tbody tr:nth-child(even) {
            background: #f8fafc;
        }
        .signature-block {
            margin-top: 24px;
            display: flex;
            justify-content: flex-end;
            page-break-inside: avoid;
        }
        .signature-inner {
            width: 280px;
            text-align: center;
            border-top: 1px solid rgba(107,114,128,0.3);
            padding-top: 12px;
        }
        .signature-inner .date {
            font-size: 12px;
            color: var(--muted);
            margin-bottom: 6px;
        }
        .signature-inner .role {
            font-weight: 700;
            margin-bottom: 40px;
        }
        .signature-inner .name {
            font-weight: 800;
            letter-spacing: .4px;
        }
    </style>
</head>
<body>
    <main class="report-shell">
        <header class="report-header">
            ' . $logoElement . '
            <div class="brand-text">
                <strong>Balai Besar Pelatihan Vokasi dan Produktivitas Bekasi</strong>
                <span>Kementerian Ketenagakerjaan Republik Indonesia</span>
            </div>
        </header>

        <section class="report-meta">
            <h2>Laporan Jadwal Pelatihan</h2>
            <p>Tanggal cetak: ' . htmlspecialchars($tanggalCetak, ENT_QUOTES, "UTF-8") . '</p>
            <p>Periode data: ' . htmlspecialchars($periodeLabel, ENT_QUOTES, "UTF-8") . '</p>
        </section>

        <table>
            <thead>
                <tr>
                    <th class="text-center" style="width: 6%;">No</th>
                    <th style="width: 24%;">Kelas</th>
                    <th style="width: 32%;">Instruktur</th>
                    <th class="text-center" style="width: 20%;">Tanggal</th>
                    <th class="text-center" style="width: 18%;">Jam</th>
                </tr>
            </thead>
            <tbody>';

$no = 1;
foreach($data as $row) {
    $html .= '<tr>
        <td class="text-center">' . $no++ . '</td>
        <td>' . $row['kelas'] . '</td>
        <td>' . $row['instruktur'] . '</td>
        <td class="text-center">' . date('d-m-Y', strtotime($row['tanggal'])) . '</td>
        <td class="text-center">' . $row['jam_mulai'] . ' - ' . $row['jam_selesai'] . '</td>
    </tr>';
}

$html .= '
            </tbody>
        </table>
        <div class="signature-block">
            <div class="signature-inner">
                <div class="date">Bekasi, ' . htmlspecialchars(date('d-m-Y'), ENT_QUOTES, "UTF-8") . '</div>
                <div class="role">Mengetahui,<br>Kepala BBPVP Bekasi</div>
                <div class="name">(........................................)</div>
            </div>
        </div>
    </main>
</body>
</html>';

header('Content-Type: text/html; charset=utf-8');
echo $html;

mysqli_close($conn);
?>
