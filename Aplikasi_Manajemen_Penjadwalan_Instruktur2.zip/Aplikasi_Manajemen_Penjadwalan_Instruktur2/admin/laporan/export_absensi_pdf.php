<?php
include "../../config/database.php";

function formatTanggalIndonesia(int $timestamp, bool $denganWaktu = false): string {
    $namaBulan = [
        1 => 'Januari',
        2 => 'Februari',
        3 => 'Maret',
        4 => 'April',
        5 => 'Mei',
        6 => 'Juni',
        7 => 'Juli',
        8 => 'Agustus',
        9 => 'September',
        10 => 'Oktober',
        11 => 'November',
        12 => 'Desember'
    ];

    $tanggal = date('d', $timestamp);
    $bulan = $namaBulan[(int) date('n', $timestamp)] ?? date('F', $timestamp);
    $tahun = date('Y', $timestamp);
    $hasil = $tanggal . ' ' . $bulan . ' ' . $tahun;

    if ($denganWaktu) {
        $hasil .= ' ' . date('H:i:s', $timestamp);
    }

    return $hasil;
}

function formatBulanIndonesia(string $ym): string {
    $namaBulan = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
    ];

    if (!preg_match('/^\d{4}-\d{2}$/', $ym)) {
        $ym = date('Y-m');
    }

    $timestamp = strtotime($ym . '-01');
    $bulan = $namaBulan[(int) date('n', $timestamp)] ?? date('F', $timestamp);
    $tahun = date('Y', $timestamp);

    return $bulan . ' ' . $tahun;
}

$selectedMonthInput = $_GET['bulan'] ?? date('Y-m');
if (!preg_match('/^\d{4}-\d{2}$/', $selectedMonthInput)) {
    $selectedMonthInput = date('Y-m');
}
$selectedTimestamp = strtotime($selectedMonthInput . '-01');
$filterYear = (int) date('Y', $selectedTimestamp);
$filterMonth = (int) date('n', $selectedTimestamp);
$periodeLabel = formatBulanIndonesia($selectedMonthInput);

$sql = "SELECT a.*, i.nama_instruktur AS instruktur 
        FROM absensi a 
        JOIN instruktur i ON a.instruktur_id = i.instruktur_id 
        WHERE YEAR(a.tanggal) = {$filterYear} AND MONTH(a.tanggal) = {$filterMonth}
        ORDER BY a.tanggal DESC";

$result = mysqli_query($conn, $sql);
$data = [];

if($result && mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
}

$timestampSekarang = time();
$tanggalCetak = formatTanggalIndonesia($timestampSekarang, true);
$tanggalTtd = formatTanggalIndonesia($timestampSekarang);
$logoPublicPath = '../../assets/images/logo-bbpvp.png';
$logoFilePath = __DIR__ . '/../../assets/images/logo-bbpvp.png';
$logoElement = '<div class="logo-fallback">BBPVP</div>';

if (file_exists($logoFilePath)) {
    $logoElement = '<img src="' . $logoPublicPath . '" alt="Logo BBPVP Bekasi" />';
}

ob_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Absensi Instruktur</title>
    <style>
        @page {
            size: A4;
            margin: 20mm;
        }
        :root {
            --primary: #059669;
            --accent: #0d9488;
            --text: #1f2937;
            --muted: #6b7280;
            --surface: #ffffff;
            --ring: #d1fae5;
            --ring-strong: #86efac;
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            padding: 0;
            font-family: 'Inter', 'Segoe UI', Arial, sans-serif;
            background: #fff;
            color: var(--text);
        }
        .report-shell {
            width: 100%;
            background: var(--surface);
            border: 1.5px solid var(--ring);
            border-radius: 12px;
            padding: 24px 26px 18px;
        }
        .report-header {
            display: flex;
            align-items: center;
            gap: 16px;
            padding-bottom: 18px;
            border-bottom: 1px solid var(--ring);
            margin-bottom: 20px;
        }
        .report-header img {
            width: 64px;
            height: 64px;
            border-radius: 16px;
            object-fit: cover;
        }
        .logo-fallback {
            width: 64px;
            height: 64px;
            border-radius: 16px;
            background: linear-gradient(135deg, var(--primary), var(--accent));
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-weight: 800;
            font-size: 14px;
            letter-spacing: 0.8px;
        }
        .brand-text {
            display: grid;
            gap: 4px;
        }
        .brand-text strong {
            font-size: 16px;
            font-weight: 800;
            letter-spacing: .2px;
        }
        .brand-text span {
            font-size: 13px;
            color: var(--muted);
        }
        .report-meta {
            margin-bottom: 16px;
        }
        .report-meta h2 {
            margin: 0;
            font-size: 22px;
            font-weight: 800;
        }
        .report-meta p {
            margin: 6px 0 0;
            color: var(--muted);
            font-size: 13px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            border: 1px solid var(--ring);
        }
        thead {
            background: linear-gradient(135deg, var(--primary), var(--accent));
            color: #fff;
        }
        th, td {
            padding: 10px 12px;
            font-size: 12px;
        }
        th {
            text-align: left;
            font-weight: 700;
            letter-spacing: .2px;
        }
        th.text-center, td.text-center {
            text-align: center;
        }
        tbody tr:nth-child(even) {
            background: #f9fafb;
        }
        .status-badge {
            display: inline-flex;
            padding: 3px 9px;
            border-radius: 999px;
            font-weight: 600;
            font-size: 11px;
            border: 1px solid var(--ring-strong);
            background: #f0fdf4;
            color: var(--primary);
        }
        .signature-block {
            margin-top: 24px;
            display: flex;
            justify-content: flex-end;
            page-break-inside: avoid;
        }
        .signature-inner {
            width: 280px;
            text-align: center;
            border-top: 1px solid rgba(107,114,128,0.3);
            padding-top: 12px;
        }
        .signature-inner .date {
            font-size: 12px;
            color: var(--muted);
            margin-bottom: 6px;
        }
        .signature-inner .role {
            font-weight: 700;
            margin-bottom: 40px;
        }
        .signature-inner .name {
            font-weight: 800;
            letter-spacing: .4px;
        }
    </style>
</head>
<body>
    <main class="report-shell">
        <header class="report-header">
            <?php echo $logoElement; ?>
            <div class="brand-text">
                <strong>Balai Besar Pelatihan Vokasi dan Produktivitas Bekasi</strong>
                <span>Kementerian Ketenagakerjaan Republik Indonesia</span>
            </div>
        </header>

        <section class="report-meta">
            <h2>Laporan Absensi Instruktur</h2>
            <p>Tanggal cetak: <?php echo htmlspecialchars($tanggalCetak, ENT_QUOTES, 'UTF-8'); ?></p>
            <p>Periode data: <?php echo htmlspecialchars($periodeLabel, ENT_QUOTES, 'UTF-8'); ?></p>
        </section>

        <table>
            <thead>
                <tr>
                    <th class="text-center" style="width: 6%;">No</th>
                    <th style="width: 38%;">Nama Instruktur</th>
                    <th class="text-center" style="width: 24%;">Tanggal</th>
                    <th class="text-center" style="width: 32%;">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($data) === 0): ?>
                    <tr>
                        <td colspan="4" class="text-center" style="padding: 30px; color: var(--muted);">Belum ada data absensi.</td>
                    </tr>
                <?php else: ?>
                    <?php $no = 1; foreach ($data as $row): ?>
                        <tr>
                            <td class="text-center"><?php echo $no++; ?></td>
                            <td><?php echo htmlspecialchars($row['instruktur'], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td class="text-center"><?php echo formatTanggalIndonesia(strtotime($row['tanggal'])); ?></td>
                            <td class="text-center">
                                <span class="status-badge"><?php echo htmlspecialchars(ucfirst($row['status']), ENT_QUOTES, 'UTF-8'); ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="signature-block">
            <div class="signature-inner">
                <div class="date">Bekasi, <?php echo htmlspecialchars($tanggalTtd, ENT_QUOTES, 'UTF-8'); ?></div>
                <div class="role">Mengetahui,<br>Kepala BBPVP Bekasi</div>
                <div class="name">(........................................)</div>
            </div>
        </div>
    </main>
</body>
</html>
<?php

$html = ob_get_clean();

header('Content-Type: text/html; charset=utf-8');
echo $html;

mysqli_close($conn);
?>
