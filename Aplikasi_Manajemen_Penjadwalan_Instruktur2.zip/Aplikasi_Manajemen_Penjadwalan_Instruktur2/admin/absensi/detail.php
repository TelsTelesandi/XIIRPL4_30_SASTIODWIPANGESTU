<?php
include "../../config/database.php";
include "../../includes/header.php";
include "../../includes/sidebar.php";

$id = $_GET['id'];

// Ambil nama instruktur
$instruktur = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM instruktur WHERE instruktur_id=$id"));

// Ambil absensi instruktur
$result = mysqli_query($conn, "SELECT * FROM absensi WHERE instruktur_id=$id ORDER BY tanggal DESC");

?>

<div class="content">
    <div class="dashboard-container fade-in">
        <!-- Added modern header with breadcrumb navigation -->
        <div class="dashboard-header">
            <div class="breadcrumb-nav">
                <a href="index.php" class="breadcrumb-link">
                    <iconify-icon icon="material-symbols:arrow-back"></iconify-icon>
                    Kelola Absensi
                </a>
                <span class="breadcrumb-separator">/</span>
                <span class="breadcrumb-current">Detail Absensi</span>
            </div>
            <h2>
                <iconify-icon icon="material-symbols:person-outline"></iconify-icon>
                Detail Absensi - <?= htmlspecialchars($instruktur['nama_instruktur']); ?>
            </h2>
            <p class="dashboard-subtitle">Riwayat kehadiran instruktur</p>
        </div>

        <!-- Added instructor info card -->
        <div class="instructor-info-card">
            <div class="instructor-avatar">
                <iconify-icon icon="material-symbols:person"></iconify-icon>
            </div>
            <div class="instructor-details">
                <h3><?= htmlspecialchars($instruktur['nama_instruktur']); ?></h3>
                <p>ID Instruktur: <?= $instruktur['instruktur_id']; ?></p>
            </div>
        </div>

        <!-- Modernized table with better styling -->
        <div class="content-card">
            <div class="table-header">
                <h3>
                    <iconify-icon icon="material-symbols:calendar-month"></iconify-icon>
                    Riwayat Absensi
                </h3>
            </div>
            
            <div class="table-container">
                <table class="modern-table attendance-detail-table">
                    <thead>
                        <tr>
                            <th>
                                <iconify-icon icon="material-symbols:calendar-today"></iconify-icon>
                                Tanggal
                            </th>
                            <th>
                                <iconify-icon icon="material-symbols:check-circle-outline"></iconify-icon>
                                Status Kehadiran
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(mysqli_num_rows($result) > 0): ?>
                            <?php while($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td>
                                    <div class="date-cell">
                                        <span class="date-primary"><?= date('d M Y', strtotime($row['tanggal'])); ?></span>
                                        <span class="date-secondary"><?= date('l', strtotime($row['tanggal'])); ?></span>
                                    </div>
                                </td>
                                <td>
                                    <?php 
                                    $status = $row['status'];
                                    $statusClass = '';
                                    $statusIcon = '';
                                    
                                    switch($status) {
                                        case 'Hadir':
                                            $statusClass = 'status-present';
                                            $statusIcon = 'material-symbols:check-circle';
                                            break;
                                        case 'Izin':
                                            $statusClass = 'status-permission';
                                            $statusIcon = 'material-symbols:info';
                                            break;
                                        case 'Sakit':
                                            $statusClass = 'status-sick';
                                            $statusIcon = 'material-symbols:local-hospital';
                                            break;
                                        case 'Alfa':
                                            $statusClass = 'status-absent';
                                            $statusIcon = 'material-symbols:cancel';
                                            break;
                                    }
                                    ?>
                                    <span class="status-badge <?= $statusClass; ?>">
                                        <iconify-icon icon="<?= $statusIcon; ?>"></iconify-icon>
                                        <?= $status; ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="2" class="empty-state">
                                    <iconify-icon icon="material-symbols:inbox"></iconify-icon>
                                    <p>Belum ada data absensi untuk instruktur ini</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
/* Added comprehensive styling for attendance detail page */
.breadcrumb-nav {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 16px;
    font-size: 14px;
}

.breadcrumb-link {
    display: flex;
    align-items: center;
    gap: 6px;
    color: #15803d;
    text-decoration: none;
    font-weight: 500;
    transition: color 0.2s ease;
}

.breadcrumb-link:hover {
    color: #84cc16;
}

.breadcrumb-separator {
    color: #9ca3af;
}

.breadcrumb-current {
    color: #374151;
    font-weight: 600;
}

.instructor-info-card {
    background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
    border: 1px solid #bbf7d0;
    border-radius: 12px;
    padding: 24px;
    margin-bottom: 24px;
    display: flex;
    align-items: center;
    gap: 20px;
}

.instructor-avatar {
    width: 60px;
    height: 60px;
    background: #15803d;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 28px;
}

.instructor-details h3 {
    margin: 0 0 8px 0;
    color: #15803d;
    font-size: 20px;
    font-weight: 700;
}

.instructor-details p {
    margin: 0;
    color: #6b7280;
    font-size: 14px;
}

.table-header {
    padding: 20px 24px;
    border-bottom: 1px solid #e5e7eb;
    background: #f9fafb;
}

.table-header h3 {
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
    color: #374151;
    font-size: 18px;
    font-weight: 600;
}

.attendance-detail-table {
    margin: 0;
}

.attendance-detail-table th {
    background: #15803d;
    color: white;
    font-weight: 600;
    padding: 16px 20px;
    text-align: left;
}

.attendance-detail-table th iconify-icon {
    margin-right: 8px;
    font-size: 18px;
}

.attendance-detail-table td {
    padding: 16px 20px;
    border-bottom: 1px solid #f3f4f6;
}

.attendance-detail-table tr:hover {
    background: #f9fafb;
}

.date-cell {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.date-primary {
    font-weight: 600;
    color: #374151;
    font-size: 15px;
}

.date-secondary {
    font-size: 13px;
    color: #6b7280;
    text-transform: capitalize;
}

.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 12px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.status-present {
    background: #dcfce7;
    color: #15803d;
    border: 1px solid #bbf7d0;
}

.status-permission {
    background: #fef3c7;
    color: #d97706;
    border: 1px solid #fde68a;
}

.status-sick {
    background: #fef3c7;
    color: #d97706;
    border: 1px solid #fde68a;
}

.status-absent {
    background: #fee2e2;
    color: #dc2626;
    border: 1px solid #fecaca;
}

.empty-state {
    text-align: center;
    padding: 60px 20px;
    color: #6b7280;
}

.empty-state iconify-icon {
    font-size: 48px;
    margin-bottom: 16px;
    opacity: 0.5;
}

.empty-state p {
    margin: 0;
    font-size: 16px;
}

@media (max-width: 768px) {
    .instructor-info-card {
        flex-direction: column;
        text-align: center;
        gap: 16px;
    }
    
    .attendance-detail-table th,
    .attendance-detail-table td {
        padding: 12px 16px;
    }
    
    .date-cell {
        align-items: flex-start;
    }
}
</style>

<?php include "../../includes/footer.php"; ?>
