<?php
include "../../config/database.php";
include "../../includes/header.php";
include "../../includes/sidebar.php";

$result = mysqli_query($conn, "
    SELECT i.instruktur_id, i.nama_instruktur, 
           COUNT(a.instruktur_id) as total_absensi,
           SUM(a.status='Hadir') as hadir,
           SUM(a.status='Izin') as izin,
           SUM(a.status='Sakit') as sakit,
           SUM(a.status='Alfa') as alfa
    FROM instruktur i
    LEFT JOIN absensi a ON i.instruktur_id = a.instruktur_id
    GROUP BY i.instruktur_id
");
?>

<div class="content">
    <div class="dashboard-container fade-in">
        <div class="dashboard-header">
            <h2>
                <iconify-icon icon="material-symbols:assignment-outline"></iconify-icon>
                Rekap Absensi Instruktur Teknologi Informasi dan Komunikasi
            </h2>
            <p class="dashboard-subtitle">Ringkasan Kehadiran Instruktur TIK</p>
        </div>

        <!-- Added summary statistics cards -->
        <div class="stats-grid">
            <?php
            $total_instructors = mysqli_num_rows(mysqli_query($conn, "SELECT DISTINCT instruktur_id FROM instruktur"));
            $total_present = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM absensi WHERE status='Hadir'"))['count'];
            $total_absent = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM absensi WHERE status='Alfa'"))['count'];
            $total_permission = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM absensi WHERE status IN ('Izin', 'Sakit')"))['count'];
            ?>
            
            <div class="stat-card stat-primary">
                <div class="stat-icon">
                    <iconify-icon icon="material-symbols:group"></iconify-icon>
                </div>
                <div class="stat-content">
                    <h3><?= $total_instructors; ?></h3>
                    <p>Total Instruktur</p>
                </div>
            </div>
            
            <div class="stat-card stat-success">
                <div class="stat-icon">
                    <iconify-icon icon="material-symbols:check-circle"></iconify-icon>
                </div>
                <div class="stat-content">
                    <h3><?= $total_present; ?></h3>
                    <p>Total Kehadiran</p>
                </div>
            </div>
            
            <div class="stat-card stat-warning">
                <div class="stat-icon">
                    <iconify-icon icon="material-symbols:info"></iconify-icon>
                </div>
                <div class="stat-content">
                    <h3><?= $total_permission; ?></h3>
                    <p>Izin & Sakit</p>
                </div>
            </div>
            
            <div class="stat-card stat-danger">
                <div class="stat-icon">
                    <iconify-icon icon="material-symbols:cancel"></iconify-icon>
                </div>
                <div class="stat-content">
                    <h3><?= $total_absent; ?></h3>
                    <p>Total Alfa</p>
                </div>
            </div>
        </div>

        <div class="content-card">
            <!-- Enhanced table header with search functionality -->
            <div class="table-header">
                <h3>
                    <iconify-icon icon="material-symbols:table-chart"></iconify-icon>
                    Data Absensi Instruktur
                </h3>
                <div class="table-actions">
                    <div class="search-box">
                        <iconify-icon icon="material-symbols:search"></iconify-icon>
                        <input type="text" id="searchInput" placeholder="Cari instruktur..." onkeyup="searchTable()">
                    </div>
                </div>
            </div>
            
            <div class="table-container">
                <table class="modern-table" id="attendanceTable">
                    <thead>
                        <tr>
                            <th>
                                <iconify-icon icon="material-symbols:person"></iconify-icon>
                                Instruktur
                            </th>
                            <th>
                                <iconify-icon icon="material-symbols:numbers"></iconify-icon>
                                Total
                            </th>
                            <th>
                                <iconify-icon icon="material-symbols:check-circle"></iconify-icon>
                                Hadir
                            </th>
                            <th>
                                <iconify-icon icon="material-symbols:info"></iconify-icon>
                                Izin
                            </th>
                            <th>
                                <iconify-icon icon="material-symbols:local-hospital"></iconify-icon>
                                Sakit
                            </th>
                            <th>
                                <iconify-icon icon="material-symbols:cancel"></iconify-icon>
                                Alfa
                            </th>
                            <th>
                                <iconify-icon icon="material-symbols:settings"></iconify-icon>
                                Aksi
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td>
                                <div class="instructor-cell">
                                    <div class="instructor-avatar-small">
                                        <iconify-icon icon="material-symbols:person"></iconify-icon>
                                    </div>
                                    <div class="instructor-info">
                                        <span class="instructor-name"><?= htmlspecialchars($row['nama_instruktur']); ?></span>
                                        <span class="instructor-id">ID: <?= $row['instruktur_id']; ?></span>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="total-badge"><?= $row['total_absensi']; ?></span>
                            </td>
                            <td>
                                <span class="status-badge status-present">
                                    <iconify-icon icon="material-symbols:check-circle"></iconify-icon>
                                    <?= $row['hadir']; ?>
                                </span>
                            </td>
                            <td>
                                <span class="status-badge status-permission">
                                    <iconify-icon icon="material-symbols:info"></iconify-icon>
                                    <?= $row['izin']; ?>
                                </span>
                            </td>
                            <td>
                                <span class="status-badge status-sick">
                                    <iconify-icon icon="material-symbols:local-hospital"></iconify-icon>
                                    <?= $row['sakit']; ?>
                                </span>
                            </td>
                            <td>
                                <span class="status-badge status-absent">
                                    <iconify-icon icon="material-symbols:cancel"></iconify-icon>
                                    <?= $row['alfa']; ?>
                                </span>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <a href="detail.php?id=<?= $row['instruktur_id']; ?>" class="btn-action btn-primary">
                                        <iconify-icon icon="material-symbols:visibility"></iconify-icon>
                                        Detail
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include "../../includes/footer.php"; ?>

<style>
/* Added comprehensive styling for enhanced attendance management */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-bottom: 32px;
}

.stat-card {
    background: white;
    border-radius: 12px;
    padding: 24px;
    display: flex;
    align-items: center;
    gap: 16px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    border: 1px solid #e5e7eb;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.stat-icon {
    width: 50px;
    height: 50px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    color: white;
}

.stat-primary .stat-icon { background: #15803d; }
.stat-success .stat-icon { background: #16a34a; }
.stat-warning .stat-icon { background: #d97706; }
.stat-danger .stat-icon { background: #dc2626; }

.stat-content h3 {
    margin: 0 0 4px 0;
    font-size: 28px;
    font-weight: 700;
    color: #374151;
}

.stat-content p {
    margin: 0;
    color: #6b7280;
    font-size: 14px;
    font-weight: 500;
}

.table-header {
    padding: 20px 24px;
    border-bottom: 1px solid #e5e7eb;
    background: #f9fafb;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
}

.table-header h3 {
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
    color: #374151;
    font-size: 18px;
    font-weight: 600;
}

.table-actions {
    display: flex;
    gap: 12px;
    align-items: center;
}

.search-box {
    position: relative;
    display: flex;
    align-items: center;
}

.search-box iconify-icon {
    position: absolute;
    left: 12px;
    color: #6b7280;
    font-size: 18px;
}

.search-box input {
    padding: 10px 12px 10px 40px;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    font-size: 14px;
    width: 250px;
    transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.search-box input:focus {
    outline: none;
    border-color: #15803d;
    box-shadow: 0 0 0 3px rgba(21, 128, 61, 0.1);
}

.instructor-cell {
    display: flex;
    align-items: center;
    gap: 12px;
}

.instructor-avatar-small {
    width: 40px;
    height: 40px;
    background: #15803d;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 18px;
}

.instructor-info {
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.instructor-name {
    font-weight: 600;
    color: #374151;
    font-size: 15px;
}

.instructor-id {
    font-size: 12px;
    color: #6b7280;
}

.total-badge {
    background: #f3f4f6;
    color: #374151;
    padding: 6px 12px;
    border-radius: 6px;
    font-weight: 600;
    font-size: 14px;
}

.action-buttons {
    display: flex;
    gap: 8px;
}

.btn-action {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    border-radius: 6px;
    text-decoration: none;
    font-size: 13px;
    font-weight: 600;
    transition: all 0.2s ease;
}

.btn-primary {
    background: #15803d;
    color: white;
}

.btn-primary:hover {
    background: #166534;
    transform: translateY(-1px);
}

@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .table-header {
        flex-direction: column;
        align-items: stretch;
    }
    
    .search-box input {
        width: 100%;
    }
    
    .instructor-cell {
        flex-direction: column;
        align-items: flex-start;
        gap: 8px;
    }
    
    .action-buttons {
        flex-direction: column;
    }
}
</style>

<script>
function searchTable() {
    const input = document.getElementById('searchInput');
    const filter = input.value.toLowerCase();
    const table = document.getElementById('attendanceTable');
    const rows = table.getElementsByTagName('tr');
    
    for (let i = 1; i < rows.length; i++) {
        const instructorName = rows[i].getElementsByClassName('instructor-name')[0];
        if (instructorName) {
            const textValue = instructorName.textContent || instructorName.innerText;
            if (textValue.toLowerCase().indexOf(filter) > -1) {
                rows[i].style.display = '';
            } else {
                rows[i].style.display = 'none';
            }
        }
    }
}
</script>
