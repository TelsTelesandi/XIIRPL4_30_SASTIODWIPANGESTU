<?php
session_start();
include "../config/database.php";

// Pastikan hanya admin yang bisa upload logo
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['logo'])) {
    $uploadDir = '../assets/images/';
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/svg+xml'];
    $maxSize = 2 * 1024 * 1024; // 2MB
    
    $file = $_FILES['logo'];
    
    if ($file['error'] == 0) {
        if (in_array($file['type'], $allowedTypes)) {
            if ($file['size'] <= $maxSize) {
                $fileName = 'logo-bbpvp.png';
                $uploadPath = $uploadDir . $fileName;
                
                if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
                    $message = '<div class="success"><iconify-icon icon="material-symbols:check-circle-outline"></iconify-icon> Logo berhasil diupload!</div>';
                } else {
                    $message = '<div class="error"><iconify-icon icon="material-symbols:error-outline"></iconify-icon> Gagal mengupload logo.</div>';
                }
            } else {
                $message = '<div class="error"><iconify-icon icon="material-symbols:error-outline"></iconify-icon> Ukuran file terlalu besar (max 2MB).</div>';
            }
        } else {
            $message = '<div class="error"><iconify-icon icon="material-symbols:error-outline"></iconify-icon> Format file tidak didukung. Gunakan JPG, PNG, GIF, atau SVG.</div>';
        }
    } else {
        $message = '<div class="error"><iconify-icon icon="material-symbols:error-outline"></iconify-icon> Terjadi kesalahan saat upload.</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Logo - BBPVP Bekasi</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://code.iconify.design/3/3.1.1/iconify.min.js"></script>
    <style>
        /* Updated upload page styling with Kemnaker theme */
        .upload-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 40px;
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(249, 115, 22, 0.2);
            border: 2px solid #fed7aa;
        }
        
        .upload-form {
            text-align: center;
        }
        
        .file-input-wrapper {
            position: relative;
            display: inline-block;
            margin: 20px 0;
        }
        
        .file-input {
            position: absolute;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        
        .file-input-button {
            display: inline-block;
            padding: 15px 30px;
            background: linear-gradient(135deg, #f97316, #ea580c);
            color: white;
            border-radius: 12px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .file-input-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(249, 115, 22, 0.3);
            background: linear-gradient(135deg, #ea580c, #dc2626);
        }
        
        .success {
            background: linear-gradient(135deg, #dcfce7, #bbf7d0);
            color: #16a34a;
            padding: 15px;
            border-radius: 12px;
            margin: 20px 0;
            border: 2px solid #22c55e;
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
        }
        
        .error {
            background: linear-gradient(135deg, #fef2f2, #fee2e2);
            color: #dc2626;
            padding: 15px;
            border-radius: 12px;
            margin: 20px 0;
            border: 2px solid #f87171;
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
        }
        
        .current-logo {
            text-align: center;
            margin: 20px 0;
        }
        
        .current-logo img {
            max-width: 200px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(249, 115, 22, 0.2);
            border: 3px solid #fed7aa;
        }
        
        .upload-title {
            color: #ea580c;
            font-size: 28px;
            font-weight: 800;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }
        
        .requirements-box {
            background: linear-gradient(135deg, #fff7ed, #ffedd5);
            padding: 20px;
            border-radius: 12px;
            margin-top: 20px;
            border: 2px solid #fed7aa;
        }
        
        .requirements-box h4 {
            color: #ea580c;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 700;
        }
        
        .back-link {
            color: #f97316;
            text-decoration: none;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
            background: linear-gradient(135deg, #fff7ed, #ffedd5);
            border: 2px solid #fed7aa;
        }
        
        .back-link:hover {
            background: linear-gradient(135deg, #ffedd5, #fed7aa);
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="upload-container">
        <h2 class="upload-title">
            <iconify-icon icon="material-symbols:image-outline"></iconify-icon>
            Upload Logo Kemnaker
        </h2>
        
        <?php if ($message): ?>
            <?= $message ?>
        <?php endif; ?>
        
        <div class="current-logo">
            <h3 style="color: #6b7280; margin-bottom: 15px;">Logo Saat Ini:</h3>
            <img src="../assets/images/logo-bbpvp.png" alt="Logo BBPVP Bekasi">
        </div>
        
        <form method="post" enctype="multipart/form-data" class="upload-form">
            <div class="file-input-wrapper">
                <input type="file" name="logo" class="file-input" accept="image/*" required>
                <div class="file-input-button">
                    <iconify-icon icon="material-symbols:folder-open-outline"></iconify-icon>
                    Pilih File Logo
                </div>
            </div>
            
            <div style="margin: 20px 0;">
                <button type="submit" style="background: linear-gradient(135deg, #22c55e, #16a34a); color: white; border: none; padding: 12px 25px; border-radius: 12px; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; transition: all 0.3s ease;">
                    <iconify-icon icon="material-symbols:upload-outline"></iconify-icon>
                    Upload Logo
                </button>
            </div>
        </form>
        
        <div class="requirements-box">
            <h4>
                <iconify-icon icon="material-symbols:info-outline"></iconify-icon>
                Persyaratan Logo:
            </h4>
            <ul style="text-align: left; margin: 10px 0; color: #6b7280;">
                <li>Format: JPG, PNG, GIF, atau SVG</li>
                <li>Ukuran maksimal: 2MB</li>
                <li>Rasio aspek: 1:1 (persegi) untuk hasil terbaik</li>
                <li>Resolusi minimal: 200x200 pixel</li>
                <li>Disarankan menggunakan logo resmi Kemnaker</li>
            </ul>
        </div>
        
        <div style="text-align: center; margin-top: 30px;">
            <a href="dashboard.php" class="back-link">
                <iconify-icon icon="material-symbols:arrow-back"></iconify-icon>
                Kembali ke Dashboard
            </a>
        </div>
    </div>
</body>
</html>





