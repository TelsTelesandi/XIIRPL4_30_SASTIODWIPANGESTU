<?php
// Simple test untuk memastikan semua berfungsi
echo "<h1>Test Aplikasi Instruktur</h1>";

// Test basic PHP
echo "<p style='color: green;'>✓ PHP berfungsi</p>";

// Test database
include "config/database.php";
if ($conn) {
    echo "<p style='color: green;'>✓ Database terhubung</p>";
    
    // Test materi table
    $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM materi");
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        echo "<p style='color: green;'>✓ Materi table accessible - " . $row['count'] . " records</p>";
    } else {
        echo "<p style='color: red;'>✗ Materi table error: " . mysqli_error($conn) . "</p>";
    }
} else {
    echo "<p style='color: red;'>✗ Database tidak terhubung</p>";
}

// Test file permissions
if (is_writable('uploads/materi')) {
    echo "<p style='color: green;'>✓ Upload directory writable</p>";
} else {
    echo "<p style='color: red;'>✗ Upload directory not writable</p>";
}

echo "<h2>Test Links:</h2>";
echo "<p><a href='instruktur/dashboard.php' target='_blank'>Dashboard</a></p>";
echo "<p><a href='instruktur/riwayat.php' target='_blank'>Riwayat</a></p>";
echo "<p><a href='instruktur/materi/index.php' target='_blank'>Materi</a></p>";
echo "<p><a href='instruktur/materi/debug.php' target='_blank'>Debug Materi</a></p>";

echo "<h2>System Info:</h2>";
echo "<p>PHP Version: " . phpversion() . "</p>";
echo "<p>Current Time: " . date('Y-m-d H:i:s') . "</p>";
?>
