<?php
include "config/database.php";

echo "<h1>Debug Notifikasi System</h1>";

// Check if notifikasi table exists and has data
echo "<h2>Notifikasi Table Check:</h2>";
$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM notifikasi");
if ($result) {
    $row = mysqli_fetch_assoc($result);
    echo "<p>Total notifikasi: " . $row['count'] . "</p>";
} else {
    echo "<p>Error: " . mysqli_error($conn) . "</p>";
}

// Check absensi table
echo "<h2>Absensi Table Check:</h2>";
$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM absensi");
if ($result) {
    $row = mysqli_fetch_assoc($result);
    echo "<p>Total absensi: " . $row['count'] . "</p>";
} else {
    echo "<p>Error: " . mysqli_error($conn) . "</p>";
}

// Check absensi with different status
echo "<h2>Absensi by Status:</h2>";
$statuses = ['Hadir', 'Izin', 'Sakit', 'Alfa'];
foreach ($statuses as $status) {
    $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM absensi WHERE status = '$status'");
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        echo "<p>$status: " . $row['count'] . "</p>";
    }
}

// Check if notifikasi table has proper structure
echo "<h2>Notifikasi Table Structure:</h2>";
$result = mysqli_query($conn, "DESCRIBE notifikasi");
if ($result) {
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . $row['Default'] . "</td>";
        echo "<td>" . $row['Extra'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>Error: " . mysqli_error($conn) . "</p>";
}

// Check sample data
echo "<h2>Sample Notifikasi Data:</h2>";
$result = mysqli_query($conn, "SELECT * FROM notifikasi LIMIT 5");
if ($result && mysqli_num_rows($result) > 0) {
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr>";
    $fields = mysqli_fetch_fields($result);
    foreach ($fields as $field) {
        echo "<th>" . $field->name . "</th>";
    }
    echo "</tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        foreach ($row as $value) {
            echo "<td>" . htmlspecialchars($value ?? 'NULL') . "</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No notifikasi data found</p>";
}

// Check sample absensi data
echo "<h2>Sample Absensi Data:</h2>";
$result = mysqli_query($conn, "SELECT * FROM absensi LIMIT 5");
if ($result && mysqli_num_rows($result) > 0) {
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr>";
    $fields = mysqli_fetch_fields($result);
    foreach ($fields as $field) {
        echo "<th>" . $field->name . "</th>";
    }
    echo "</tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        foreach ($row as $value) {
            echo "<td>" . htmlspecialchars($value ?? 'NULL') . "</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No absensi data found</p>";
}

// Check join query
echo "<h2>Join Query Test:</h2>";
$sql = "SELECT n.*, a.tanggal, a.status as status_absensi, i.nama_instruktur AS instruktur
        FROM notifikasi n
        LEFT JOIN absensi a ON n.absensi_id = a.absensi_id
        LEFT JOIN instruktur i ON a.instruktur_id = i.instruktur_id
        WHERE n.status_notifikasi IN ('Izin', 'Sakit', 'Alfa')
        ORDER BY n.created_at DESC
        LIMIT 5";

$result = mysqli_query($conn, $sql);
if ($result && mysqli_num_rows($result) > 0) {
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Notifikasi ID</th><th>Status Notifikasi</th><th>Instruktur</th><th>Tanggal</th><th>Status Absensi</th><th>Keterangan</th></tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['notifikasi_id'] . "</td>";
        echo "<td>" . $row['status_notifikasi'] . "</td>";
        echo "<td>" . $row['instruktur'] . "</td>";
        echo "<td>" . $row['tanggal'] . "</td>";
        echo "<td>" . $row['status_absensi'] . "</td>";
        echo "<td>" . $row['keterangan'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No data found in join query</p>";
    echo "<p>Error: " . mysqli_error($conn) . "</p>";
}
?>
