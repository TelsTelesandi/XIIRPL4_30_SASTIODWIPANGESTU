// Sidebar toggle (responsive)
const sidebar = document.querySelector(".sidebar");
const mainContent = document.querySelector(".main-content");

function toggleSidebar() {
  if (sidebar.style.width === "60px") {
    sidebar.style.width = "220px";
    mainContent.style.marginLeft = "220px";
  } else {
    sidebar.style.width = "60px";
    mainContent.style.marginLeft = "60px";
  }
}

// Alert notification auto-hide
function showAlert(message, type = "success") {
  const alertBox = document.createElement("div");
  alertBox.className = `alert alert-${type}`;
  alertBox.textContent = message;
  document.body.appendChild(alertBox);

  setTimeout(() => {
    alertBox.remove();
  }, 3000);
}

// Confirm before delete
function confirmDelete(url) {
  if (confirm("Apakah Anda yakin ingin menghapus data ini?")) {
    window.location.href = url;
  }
}
