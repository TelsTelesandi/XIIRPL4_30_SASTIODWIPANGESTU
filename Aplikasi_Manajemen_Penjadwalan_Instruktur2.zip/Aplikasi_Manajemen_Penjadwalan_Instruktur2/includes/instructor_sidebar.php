<?php
require_once __DIR__ . '/../config/app.php';

$base = rtrim(APP_BASE, '/') . '/instruktur/';
$current_path = $_SERVER['REQUEST_URI'] ?? '';
$current_file = basename($_SERVER['PHP_SELF'] ?? '');
$instruktur_name = $instruktur_data['nama_instruktur'] ?? 'Instruktur';
$instruktur_initial = strtoupper(substr($instruktur_name, 0, 1));

function instructorNavActive(string $target): bool {
    $current_file = basename($_SERVER['PHP_SELF'] ?? '');
    return $current_file === $target;
}

function instructorNavActivePath(string $segment): bool {
    $current_path = $_SERVER['REQUEST_URI'] ?? '';
    return strpos($current_path, '/instruktur/' . $segment . '/') !== false;
}
?>

<aside class="sidebar">
    <div class="sidebar-brand">
        <div class="brand-icon">
            <iconify-icon icon="mdi:school-outline"></iconify-icon>
        </div>
        <div class="brand-text">
            <span class="brand-label">Portal Instruktur</span>
            <span class="brand-subtitle">BBPVP Bekasi</span>
        </div>
    </div>

    <div class="sidebar-content">
        <nav class="sidebar-nav">
            <ul>
                <li>
                    <a href="<?= $base ?>dashboard.php" class="<?= instructorNavActive('dashboard.php') ? 'active' : '' ?>">
                        <iconify-icon icon="material-symbols:dashboard-outline" class="icon"></iconify-icon>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="<?= $base ?>jadwal.php" class="<?= instructorNavActive('jadwal.php') ? 'active' : '' ?>">
                        <iconify-icon icon="material-symbols:calendar-month-outline" class="icon"></iconify-icon>
                        <span>Jadwal Mengajar</span>
                    </a>
                </li>
                <li>
                    <a href="<?= $base ?>history_jadwal.php" class="<?= instructorNavActive('history_jadwal.php') ? 'active' : '' ?>">
                        <iconify-icon icon="material-symbols:history-toggle-off" class="icon"></iconify-icon>
                        <span>History Jadwal</span>
                    </a>
                </li>
                <li>
                    <a href="<?= $base ?>absensi.php" class="<?= instructorNavActive('absensi.php') ? 'active' : '' ?>">
                        <iconify-icon icon="material-symbols:how-to-reg-outline" class="icon"></iconify-icon>
                        <span>Absensi</span>
                    </a>
                </li>
                <li>
                    <a href="<?= $base ?>materi/index.php" class="<?= instructorNavActivePath('materi') ? 'active' : '' ?>">
                        <iconify-icon icon="material-symbols:folder-outline" class="icon"></iconify-icon>
                        <span>Kelola Materi</span>
                    </a>
                </li>
                <li>
                    <a href="<?= $base ?>riwayat.php" class="<?= instructorNavActive('riwayat.php') ? 'active' : '' ?>">
                        <iconify-icon icon="material-symbols:history" class="icon"></iconify-icon>
                        <span>Riwayat Kehadiran</span>
                    </a>
                </li>
                <li>
                    <a href="<?= $base ?>profil.php" class="<?= instructorNavActive('profil.php') ? 'active' : '' ?>">
                        <iconify-icon icon="material-symbols:person-outline" class="icon"></iconify-icon>
                        <span>Profil Saya</span>
                    </a>
                </li>
                <li>
                    <a href="<?= $base ?>ubah_password.php" class="<?= instructorNavActive('ubah_password.php') ? 'active' : '' ?>">
                        <iconify-icon icon="material-symbols:lock-outline" class="icon"></iconify-icon>
                        <span>Ubah Password</span>
                    </a>
                </li>
            </ul>
        </nav>

        <div class="sidebar-user-card">
            <a href="<?= app_url('logout.php') ?>" class="logout-btn sidebar-logout" style="gap: 10px;">
                <iconify-icon icon="material-symbols:logout"></iconify-icon>
                <span>Keluar</span>
            </a>
        </div>
    </div>
</aside>

<button class="mobile-menu-btn" onclick="toggleSidebar()" aria-label="Toggle menu">
    <iconify-icon icon="material-symbols:menu"></iconify-icon>
</button>

<script>
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) sidebar.classList.toggle('open');
}

document.addEventListener('click', function(e) {
    const sidebar = document.querySelector('.sidebar');
    const menuBtn = document.querySelector('.mobile-menu-btn');
    if (!sidebar || !menuBtn) return;
    if (window.innerWidth <= 768 && !sidebar.contains(e.target) && !menuBtn.contains(e.target)) {
        sidebar.classList.remove('open');
    }
});

function checkScreenSize() {
    const menuBtn = document.querySelector('.mobile-menu-btn');
    const sidebar = document.querySelector('.sidebar');
    if (!menuBtn || !sidebar) return;
    if (window.innerWidth <= 768) {
        menuBtn.style.display = 'flex';
    } else {
        menuBtn.style.display = 'none';
        sidebar.classList.remove('open');
    }
}

window.addEventListener('resize', checkScreenSize);
document.addEventListener('DOMContentLoaded', checkScreenSize);
checkScreenSize();
</script>
