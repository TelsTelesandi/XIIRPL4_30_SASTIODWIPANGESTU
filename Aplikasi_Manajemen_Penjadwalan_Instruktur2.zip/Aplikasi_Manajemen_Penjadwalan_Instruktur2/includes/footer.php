    </div> <!-- content -->
    </div> <!-- container -->
    <footer>
        <p>© <?= date("Y"); ?> Manajemen Penjadwalan BBPVP - All Rights Reserved</p>
    </footer>
</body>
</html>
