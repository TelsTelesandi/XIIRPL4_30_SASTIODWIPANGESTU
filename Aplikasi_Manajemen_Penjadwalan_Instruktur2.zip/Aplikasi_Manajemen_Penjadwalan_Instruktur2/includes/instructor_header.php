<?php
// Check if user is logged in and is instructor
require_once __DIR__ . '/../config/app.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'instruktur') {
    header('Location: ' . app_url('login.php'));
    exit;
}

// Get instructor data
$instruktur_id = $_SESSION['instruktur_id'];
$instruktur_query = mysqli_query($conn, "SELECT * FROM instruktur WHERE instruktur_id = '$instruktur_id'");
$instruktur_data = mysqli_fetch_assoc($instruktur_query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal Instruktur - BBPVP Bekasi</title>
    <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
            min-height: 100vh;
            display: flex;
        }

        .sidebar {
            width: 280px;
            background: white;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            z-index: 1000;
            overflow-y: auto;           /* sidebar bisa di-scroll saat menu banyak */
            overflow-x: hidden;
        }

        .sidebar-header {
            padding: 24px 20px;
            background: linear-gradient(135deg, #059669, #0d9488);
            color: white;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .sidebar-header .logo {
            width: 40px;
            height: 40px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .sidebar-header h2 {
            font-size: 18px;
            font-weight: 700;
        }

        .sidebar-nav {
            flex: 1;
            padding: 20px 0;
        }

        .sidebar-nav ul {
            list-style: none;
        }

        .sidebar-nav li {
            margin-bottom: 4px;
        }

        .sidebar-nav a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: #6b7280;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.2s ease;
            border-right: 3px solid transparent;
        }

        .sidebar-nav a:hover {
            background: #f0fdf4;
            color: #059669;
            border-right-color: #059669;
        }

        .sidebar-nav a.active {
            background: #f0fdf4;
            color: #059669;
            border-right-color: #059669;
            font-weight: 600;
        }

        .sidebar-nav .icon {
            font-size: 20px;
            width: 20px;
        }

        .user-info {
            padding: 20px;
            border-top: 1px solid #f3f4f6;
            background: #f9fafb;
            position: sticky;           /* tetap menempel di bawah sidebar */
            bottom: 0;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 16px;
        }

        .user-avatar {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #10b981, #059669);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 18px;
            color: white;
        }

        .user-details h4 {
            font-size: 14px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 2px;
        }

        .user-details p {
            font-size: 12px;
            color: #6b7280;
        }

        .logout-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 16px;
            background: #fee2e2;
            color: #dc2626;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.2s ease;
        }

        .logout-btn:hover {
            background: #fecaca;
            transform: translateY(-1px);
        }

        .main-content {
            margin-left: 280px;
            flex: 1;
            padding: 16px;
            min-height: 100vh;
        }

        /* Ensure inner dashboard containers don't add extra margins that break proportions */
        .main-content .dashboard-container {
            margin: 0;
        }

        .page-header {
            background: white;
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 24px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            border: 1px solid rgba(16, 185, 129, 0.1);
        }

        .page-title {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 24px;
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 8px;
        }

        .page-subtitle {
            color: #6b7280;
            font-size: 14px;
        }

        .breadcrumb {
            margin-bottom: 24px;
        }

        .breadcrumb nav {
            font-size: 14px;
            color: #6b7280;
        }

        .breadcrumb a {
            color: #059669;
            text-decoration: none;
        }

        .breadcrumb a:hover {
            text-decoration: underline;
        }

        .content-card {
            background: white;
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            border: 1px solid rgba(16, 185, 129, 0.1);
            margin-bottom: 16px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 16px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 14px;
            text-decoration: none;
            border: none;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .btn-primary {
            background: #059669;
            color: white;
        }

        .btn-primary:hover {
            background: #047857;
            transform: translateY(-1px);
        }

        .btn-secondary {
            background: #f3f4f6;
            color: #374151;
            border: 1px solid #d1d5db;
        }

        .btn-secondary:hover {
            background: #e5e7eb;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }

            .sidebar.open {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
            }

            .mobile-menu-btn {
                position: fixed;
                top: 20px;
                left: 20px;
                z-index: 1001;
                background: #059669;
                color: white;
                border: none;
                padding: 12px;
                border-radius: 8px;
                cursor: pointer;
            }
        }
    </style>
</head>
<body>
