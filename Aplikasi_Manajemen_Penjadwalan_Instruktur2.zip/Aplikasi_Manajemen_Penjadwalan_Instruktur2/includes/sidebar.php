<?php
// Include config untuk base_url otomatis
require_once __DIR__ . '/../config/app.php';

$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];
$base_url = $protocol . '://' . $host . app_url();

$current_path = $_SERVER['REQUEST_URI'];

// Helper function untuk URL lengkap
function full_url($path) {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    return $protocol . '://' . $host . app_url($path);
}

function isActive($path_segment) {
    $current_path = $_SERVER['REQUEST_URI'];
    return strpos($current_path, '/admin/' . $path_segment . '/') !== false;
}

function isActiveFile($filename) {
    return basename($_SERVER['PHP_SELF']) == $filename;
}
?>

<aside class="sidebar">
    <div class="sidebar-brand">
        <div class="brand-icon">
            <iconify-icon icon="material-symbols:admin-panel-settings-outline"></iconify-icon>
        </div>
        <div class="brand-text">
            <span class="brand-label">Portal Admin</span>
            <span class="brand-subtitle">BBPVP Bekasi</span>
        </div>
    </div>

    <div class="sidebar-content">
        <nav class="sidebar-nav">
            <ul>
                <li>
                    <a href="<?= app_url('/admin/dashboard.php') ?>" class="<?= isActiveFile('dashboard.php') ? 'active' : '' ?>">
                        <iconify-icon icon="material-symbols:dashboard-outline" class="icon"></iconify-icon>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="<?= app_url('/admin/instruktur/index.php') ?>" class="<?= isActive('instruktur') ? 'active' : '' ?>">
                        <iconify-icon icon="material-symbols:group-outline" class="icon"></iconify-icon>
                        <span>Kelola Instruktur</span>
                    </a>
                </li>
                <li>
                    <a href="<?= app_url('/admin/kelas/index.php') ?>" class="<?= isActive('kelas') ? 'active' : '' ?>">
                        <iconify-icon icon="material-symbols:school-outline" class="icon"></iconify-icon>
                        <span>Kelola Kelas</span>
                    </a>
                </li>
                <li>
                    <a href="<?= app_url('/admin/jadwal/index.php') ?>" class="<?= isActive('jadwal') ? 'active' : '' ?>">
                        <iconify-icon icon="material-symbols:calendar-month-outline" class="icon"></iconify-icon>
                        <span>Kelola Jadwal</span>
                    </a>
                </li>
                <li>
                    <a href="<?= app_url('/admin/absensi/index.php') ?>" class="<?= isActive('absensi') ? 'active' : '' ?>">
                        <iconify-icon icon="material-symbols:assignment-outline" class="icon"></iconify-icon>
                        <span>Rekap Absensi</span>
                    </a>
                </li>
                <li>
                    <a href="<?= app_url('/admin/notifikasi.php') ?>" class="<?= isActiveFile('notifikasi.php') ? 'active' : '' ?>">
                        <iconify-icon icon="material-symbols:notifications-outline" class="icon"></iconify-icon>
                        <span>Notifikasi</span>
                    </a>
                </li>
                <li>
                    <a href="<?= app_url('/admin/laporan/absensi.php') ?>" class="<?= strpos($current_path, '/laporan/absensi.php') !== false ? 'active' : '' ?>">
                        <iconify-icon icon="material-symbols:analytics-outline" class="icon"></iconify-icon>
                        <span>Laporan Kehadiran</span>
                    </a>
                </li>
                <li>
                    <a href="<?= app_url('/admin/laporan/jadwal.php') ?>" class="<?= strpos($current_path, '/laporan/jadwal.php') !== false ? 'active' : '' ?>">
                        <iconify-icon icon="material-symbols:description-outline" class="icon"></iconify-icon>
                        <span>Laporan Jadwal</span>
                    </a>
                </li>
                <li>
                    <a href="<?= app_url('/admin/upload_logo.php') ?>" class="<?= isActiveFile('upload_logo.php') ? 'active' : '' ?>">
                        <iconify-icon icon="material-symbols:image-outline" class="icon"></iconify-icon>
                        <span>Upload Logo</span>
                    </a>
                </li>
                <li>
                    <a href="<?= app_url('/admin/akun/index.php') ?>" class="<?= isActive('akun') ? 'active' : '' ?>">
                        <iconify-icon icon="material-symbols:settings-outline" class="icon"></iconify-icon>
                        <span>Manajemen Akun</span>
                    </a>
                </li>
            </ul>
        </nav>

        <div class="sidebar-user-card">
            <a href="<?= app_url('/logout.php') ?>" class="logout-btn sidebar-logout">
                <iconify-icon icon="material-symbols:logout"></iconify-icon>
                <span>Keluar</span>
            </a>
        </div>
    </div>
</aside>

<button class="mobile-menu-btn" onclick="toggleSidebar()" aria-label="Toggle menu">
    <iconify-icon icon="material-symbols:menu"></iconify-icon>
</button>

<script>
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) sidebar.classList.toggle('open');
}

document.addEventListener('click', function(e) {
    const sidebar = document.querySelector('.sidebar');
    const menuBtn = document.querySelector('.mobile-menu-btn');
    if (!sidebar || !menuBtn) return;
    if (window.innerWidth <= 768 && !sidebar.contains(e.target) && !menuBtn.contains(e.target)) {
        sidebar.classList.remove('open');
    }
});

function checkScreenSize() {
    const menuBtn = document.querySelector('.mobile-menu-btn');
    const sidebar = document.querySelector('.sidebar');
    if (!menuBtn || !sidebar) return;
    if (window.innerWidth <= 768) {
        menuBtn.style.display = 'flex';
    } else {
        menuBtn.style.display = 'none';
        sidebar.classList.remove('open');
    }
}

window.addEventListener('resize', checkScreenSize);
document.addEventListener('DOMContentLoaded', checkScreenSize);
checkScreenSize();
</script>
