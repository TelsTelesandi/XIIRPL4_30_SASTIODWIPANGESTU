</div> <!-- End main-content -->
<footer>
    <p>© <?= date("Y"); ?> Manajemen Penjadwalan BBPVP - All Rights Reserved</p>
</footer>
</body>
</html>
