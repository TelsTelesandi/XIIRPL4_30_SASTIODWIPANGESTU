<?php
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include config untuk base_url otomatis
require_once __DIR__ . '/../config/app.php';

$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];
$base_url = $protocol . '://' . $host . app_url();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Added cache-busting meta tags -->
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title>Manajemen Penjadwalan BBPVP</title>
    <!-- Using correct relative path to CSS with version cache buster -->
    <link rel="stylesheet" href="<?= app_url('/assets/css/style.css') ?>?v=<?= time() ?>">
    <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="header-logo">
            <!-- Using correct path for logo -->
            <img src="<?= app_url('/assets/images/logo-bbpvp.png') ?>" alt="BBPVP Bekasi" class="logo-img">
            <div class="header-text">
                <h1>Balai Besar Pelatihan Vokasi dan Produktivitas - Bekasi </h1>
                <span>Kementerian Ketenagakerjaan Republik Indonesia </span>
            </div>
        </div>
        <div class="header-user">
            <span class="user-info">
                <iconify-icon icon="material-symbols:work-outline" style="margin-right: 6px;"></iconify-icon>
                Bagian Kepegawaian/SDM
            </span>
            <a href="<?= app_url('/logout.php') ?>" class="logout-btn">
                <iconify-icon icon="material-symbols:logout"></iconify-icon>
                Logout
            </a>
        </div>
    </header>
    <div class="container">
